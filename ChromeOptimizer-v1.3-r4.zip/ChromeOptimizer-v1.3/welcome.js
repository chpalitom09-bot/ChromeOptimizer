import { initTheme } from './theme.js';
import { startOnboarding } from './onboarding.js';

initTheme();
startOnboarding();
