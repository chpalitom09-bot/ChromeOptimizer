export class AO1Engine {
    constructor() {
        this.config = { enabled: false, level: 'normal' };

        this.blacklistDomains = [
            "malware.com", "virus-test.com", "shady-downloads.net", "free-cracks.biz"
        ];
        this.suspiciousTlds = ['.zip', '.mov', '.xyz', '.top', '.rest', '.gq', '.tk', '.cam'];

        this.magicBytes = {
            exe: [[0x4D, 0x5A]], dll: [[0x4D, 0x5A]], sys: [[0x4D, 0x5A]], scr: [[0x4D, 0x5A]],
            pdf: [[0x25, 0x50, 0x44, 0x46]],
            zip: [[0x50, 0x4B, 0x03, 0x04]], jar: [[0x50, 0x4B, 0x03, 0x04]],
            docx: [[0x50, 0x4B, 0x03, 0x04]], xlsx: [[0x50, 0x4B, 0x03, 0x04]], pptx: [[0x50, 0x4B, 0x03, 0x04]],
            rar: [[0x52, 0x61, 0x72, 0x21]],
            '7z': [[0x37, 0x7A, 0xBC, 0xAF]],
            gz: [[0x1F, 0x8B]],
            bz2: [[0x42, 0x5A, 0x68]],
            png: [[0x89, 0x50, 0x4E, 0x47]],
            gif: [[0x47, 0x49, 0x46, 0x38]],
            jpg: [[0xFF, 0xD8, 0xFF]], jpeg: [[0xFF, 0xD8, 0xFF]],
            bmp: [[0x42, 0x4D]],
            webp: [[0x52, 0x49, 0x46, 0x46]],
            ico: [[0x00, 0x00, 0x01, 0x00]],
            mp3: [[0x49, 0x44, 0x33], [0xFF, 0xFB]],
            doc: [[0xD0, 0xCF, 0x11, 0xE0]], xls: [[0xD0, 0xCF, 0x11, 0xE0]], ppt: [[0xD0, 0xCF, 0x11, 0xE0]],
            rtf: [[0x7B, 0x5C, 0x72, 0x74, 0x66]],
            elf: [[0x7F, 0x45, 0x4C, 0x46]],
            class: [[0xCA, 0xFE, 0xBA, 0xBE]],
            sqlite: [[0x53, 0x51, 0x4C, 0x69]],
            '7zip-sfx': [[0x4D, 0x5A]]
        };

        this.nativeExeExts = new Set(['exe', 'dll', 'sys', 'scr', 'com', 'drv', 'cpl', 'ocx']);

        this.scriptyExts = new Set(['vbs', 'js', 'jse', 'wsf', 'wsh', 'hta', 'ps1', 'bat', 'cmd', 'msi', 'msp', 'reg', 'lnk', 'scf', 'pif', 'vbe', 'jar', 'apk', 'iso', 'img']);

        this.thresholds = { light: 85, normal: 60, aggressive: 40 };

        this.grades = [
            { max: 9, grade: 'A+', label: 'Sain' },
            { max: 24, grade: 'A', label: 'Très probablement sain' },
            { max: 39, grade: 'B', label: 'Faible risque' },
            { max: 59, grade: 'C', label: 'Risque modéré' },
            { max: 74, grade: 'D', label: 'Risque élevé' },
            { max: 89, grade: 'E', label: 'Dangereux' },
            { max: 100, grade: 'F', label: 'Menace critique' }
        ];

        this.init();
    }

    async init() {
        const data = await chrome.storage.local.get(['ao1On', 'ao1Level']);
        this.config.enabled = data.ao1On || false;
        this.config.level = data.ao1Level || 'normal';

        chrome.storage.onChanged.addListener((changes) => {
            if (changes.ao1On) this.config.enabled = changes.ao1On.newValue;
            if (changes.ao1Level) this.config.level = changes.ao1Level.newValue;
        });

        chrome.downloads.onCreated.addListener((downloadItem) => this.scanDownload(downloadItem));
    }

    gradeFor(score) {
        return this.grades.find((g) => score <= g.max) || this.grades[this.grades.length - 1];
    }

    calculateEntropy(uint8Array) {
        if (uint8Array.length === 0) return 0;
        const frequencies = new Array(256).fill(0);
        for (let i = 0; i < uint8Array.length; i++) frequencies[uint8Array[i]]++;
        let entropy = 0;
        for (let i = 0; i < 256; i++) {
            const p = frequencies[i] / uint8Array.length;
            if (p > 0) entropy -= p * Math.log2(p);
        }
        return entropy;
    }

    maxWindowEntropy(bytes, windowSize = 4096) {
        if (bytes.length <= windowSize) return { max: this.calculateEntropy(bytes), offset: 0 };
        let max = 0, offset = 0;
        for (let i = 0; i + windowSize <= bytes.length; i += windowSize) {
            const e = this.calculateEntropy(bytes.subarray(i, i + windowSize));
            if (e > max) { max = e; offset = i; }
        }
        return { max, offset };
    }

    matchesSignature(bytes, sig) {
        if (bytes.length < sig.length) return false;
        for (let i = 0; i < sig.length; i++) if (bytes[i] !== sig[i]) return false;
        return true;
    }

    async sha256Hex(bytes) {
        try {
            const digest = await crypto.subtle.digest('SHA-256', bytes);
            return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('');
        } catch { return null; }
    }

    inspectFilename(filename) {
        const hits = [];
        if (/\u202E/.test(filename)) hits.push({ label: 'Caractère Unicode trompeur (RTLO) dans le nom', weight: 40 });
        const parts = filename.split('.');
        if (parts.length > 2) {
            const last = parts[parts.length - 1].toLowerCase();
            const prev = parts[parts.length - 2].toLowerCase();
            const docLike = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'jpg', 'png', 'txt', 'zip'];
            if (this.scriptyExts.has(last) && docLike.includes(prev)) {
                hits.push({ label: `Double extension suspecte (.${prev}.${last})`, weight: 45 });
            }
        }
        if (/\s{3,}\.\w+$/.test(filename)) hits.push({ label: 'Extension masquée par des espaces', weight: 25 });
        return hits;
    }

    inspectPE(bytes, textChunk) {
        const hits = [];
        if (bytes.length > 0x40 && bytes[0] === 0x4D && bytes[1] === 0x5A) {
            const peOffset = bytes[0x3C] | (bytes[0x3D] << 8) | (bytes[0x3E] << 16) | (bytes[0x3F] << 24);
            const validPE = peOffset > 0 && peOffset + 4 <= bytes.length &&
                bytes[peOffset] === 0x50 && bytes[peOffset + 1] === 0x45 && bytes[peOffset + 2] === 0 && bytes[peOffset + 3] === 0;
            if (!validPE) hits.push({ label: 'En-tête PE incohérent (fichier potentiellement corrompu/trafiqué)', weight: 20 });
        }
        const dangerousApis = ['VirtualAlloc', 'VirtualProtect', 'WriteProcessMemory', 'CreateRemoteThread',
            'SetWindowsHookEx', 'URLDownloadToFile', 'WinExec', 'ShellExecute', 'GetProcAddress', 'LoadLibrary'];
        const found = dangerousApis.filter((a) => textChunk.includes(a));
        if (found.length >= 3) hits.push({ label: `Combinaison d'API sensibles (${found.slice(0, 4).join(', ')})`, weight: 30 });
        else if (found.length > 0) hits.push({ label: `API système sensible détectée (${found.join(', ')})`, weight: 10 });
        return hits;
    }

    inspectOfficeMacro(bytes, textChunk, extension) {
        const hits = [];
        const isOle = bytes.length > 4 && bytes[0] === 0xD0 && bytes[1] === 0xCF && bytes[2] === 0x11 && bytes[3] === 0xE0;
        if (isOle && ['doc', 'xls', 'ppt'].includes(extension) && (textChunk.includes('VBA') || textChunk.includes('Macro'))) {
            hits.push({ label: 'Document Office avec macro intégrée', weight: 25 });
        }
        return hits;
    }

    inspectPolyglot(textChunk, extension) {
        const hits = [];
        const imageLike = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'ico'];
        if (imageLike.includes(extension) && /<script[\s>]|powershell|cmd\.exe/i.test(textChunk)) {
            hits.push({ label: 'Contenu exécutable caché dans une image (fichier polyglotte)', weight: 50 });
        }
        return hits;
    }

    inspectUrl(urlObj) {
        const hits = [];
        const host = urlObj.hostname.toLowerCase();
        if (this.blacklistDomains.some((d) => host.includes(d))) {
            hits.push({ label: 'Domaine sur liste noire', weight: 50 });
        }
        if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) {
            hits.push({ label: 'Téléchargement depuis une adresse IP brute', weight: 20 });
        }
        if (this.suspiciousTlds.some((t) => host.endsWith(t))) {
            hits.push({ label: `Domaine à extension à risque (${host.slice(host.lastIndexOf('.'))})`, weight: 10 });
        }
        if (/%2e%2e|%252e|\.\.%2f/i.test(urlObj.pathname)) {
            hits.push({ label: "Manipulation d'URL suspecte (encodage/traversée de chemin)", weight: 15 });
        }
        return hits;
    }

    async scanDownload(downloadItem) {
        if (!this.config.enabled || !downloadItem.url.startsWith('http')) return;

        let signals = [];
        const extension = (downloadItem.filename.split('.').pop() || '').toLowerCase();
        let sha256 = null;
        let entropyInfo = { max: 0, offset: 0 };

        try {
            const urlObj = new URL(downloadItem.url);
            signals.push(...this.inspectUrl(urlObj));

            if (this.scriptyExts.has(extension) || this.nativeExeExts.has(extension)) {
                signals.push({ label: 'Format intrinsèquement risqué', weight: 15 });
            }
            signals.push(...this.inspectFilename(downloadItem.filename));

            const response = await fetch(downloadItem.url, {
                headers: { Range: 'bytes=0-262143' },
                signal: AbortSignal.timeout(4000)
            });

            if (response.ok || response.status === 206) {
                const buffer = await response.arrayBuffer();
                const bytes = new Uint8Array(buffer);
                sha256 = await this.sha256Hex(bytes);

                if (bytes.length > 4) {
                    const candidates = this.magicBytes[extension];
                    if (candidates) {
                        const ok = candidates.some((sig) => this.matchesSignature(bytes, sig));
                        if (!ok) signals.push({ label: `Fausse extension (le contenu ne correspond pas à .${extension})`, weight: 70 });
                    } else if (bytes[0] === 0x4D && bytes[1] === 0x5A && !this.nativeExeExts.has(extension)) {
                        signals.push({ label: 'Exécutable (MZ) caché sous une autre extension', weight: 70 });
                    }

                    entropyInfo = this.maxWindowEntropy(bytes);
                    if (entropyInfo.max > 7.5) signals.push({ label: `Section fortement compressée/chiffrée (entropie ${entropyInfo.max.toFixed(2)})`, weight: 25 });
                    else if (entropyInfo.max > 7.0) signals.push({ label: `Entropie élevée (${entropyInfo.max.toFixed(2)})`, weight: 10 });

                    const textChunk = new TextDecoder('ascii', { fatal: false }).decode(bytes);
                    const badWords = ['powershell', 'cmd.exe', 'VirtualAlloc', 'WScript.Shell', 'certutil', 'mshta', 'regsvr32', 'Invoke-Expression', 'rundll32'];
                    const foundWords = badWords.filter((w) => textChunk.toLowerCase().includes(w.toLowerCase()));
                    if (foundWords.length > 0) signals.push({ label: `Chaînes suspectes : ${foundWords.join(', ')}`, weight: 30 });

                    signals.push(...this.inspectPE(bytes, textChunk));
                    signals.push(...this.inspectOfficeMacro(bytes, textChunk, extension));
                    signals.push(...this.inspectPolyglot(textChunk, extension));
                }
            }
        } catch (e) {
            console.warn('AO1: analyse partielle échouée', e);
        }

        const score = Math.min(signals.reduce((sum, s) => sum + s.weight, 0), 100);
        const threshold = this.thresholds[this.config.level];
        const blocked = score >= threshold;
        const status = blocked ? 'BLOQUÉ' : 'SAIN';
        const grade = this.gradeFor(score);

        if (blocked) {
            chrome.downloads.cancel(downloadItem.id);
            chrome.notifications.create({
                type: 'basic',
                iconUrl: 'icons/icon128.png',
                title: 'ChromeOptimizer - Menace bloquée !',
                message: `Le moteur AO1 a neutralisé un fichier (Score: ${score}/100, note ${grade.grade}).\nFichier: ${downloadItem.filename}`
            });
        }

        this.saveHistory({
            filename: downloadItem.filename,
            score, status, grade: grade.grade, gradeLabel: grade.label,
            threats: signals.map((s) => s.label),
            sha256, entropy: entropyInfo.max
        });
    }

    async saveHistory(entry) {
        const data = await chrome.storage.local.get('ao1History');
        const history = data.ao1History || [];
        history.unshift({
            date: new Date().toLocaleString(),
            filename: entry.filename,
            score: entry.score,
            status: entry.status,
            grade: entry.grade,
            gradeLabel: entry.gradeLabel,
            threats: entry.threats.join(' | ') || 'Aucune anomalie détectée',
            sha256: entry.sha256,
            entropy: Number.isFinite(entry.entropy) ? Number(entry.entropy.toFixed(2)) : null
        });
        if (history.length > 30) history.length = 30;
        chrome.storage.local.set({ ao1History: history });
    }
}
