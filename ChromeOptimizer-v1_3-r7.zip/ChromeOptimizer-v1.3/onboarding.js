const ICONS = {
  globe: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20 15 15 0 0 1 0-20z"/></svg>',
  shield: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l8 4v6c0 5-3.4 8.6-8 10-4.6-1.4-8-5-8-10V6z"/></svg>',
  gauge: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 15l3.5-5.5"/><circle cx="12" cy="13" r="8"/><path d="M8 5.5A8 8 0 0 1 12 5"/></svg>',
  zap: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2 4 14h7l-1 8 9-12h-7z"/></svg>',
  moon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8z"/></svg>',
  wave: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/></svg>',
  layers: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5M2 12l10 5 10-5"/></svg>',
  image: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="9" cy="9" r="1.6"/><path d="M21 15l-5-5L5 21"/></svg>',
  shieldCheck: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l8 4v6c0 5-3.4 8.6-8 10-4.6-1.4-8-5-8-10V6z"/><path d="M9 12l2 2 4-4"/></svg>',
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
  checkBig: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
  info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/></svg>',
  arrow: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
  back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M11 18l-6-6 6-6"/></svg>',
  copies: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/></svg>',
  brain: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="5" cy="6" r="2"/><circle cx="5" cy="18" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/><path d="M7 7l3.2 3.6M7 17l3.2-3.6M14 12h3"/></svg>',
  offline: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 8.8a15 15 0 0 1 20 0M5 12.5a10 10 0 0 1 14 0M8.5 16a5 5 0 0 1 7 0"/><path d="M12 20h.01"/></svg>'
};

import { getSettings, saveSettings } from './lib.js';
import { LANGS, FLAGS } from './i18n.js';

const ORDER = ['lang', 'how', 'profile', 'engine', 'features', 'extras', 'recap'];

const HEAD = {
  lang: { icon: 'globe', nav: 'Langue', title: 'Bienvenue !', sub: 'Avant tout, choisis ta langue.' },
  how: { icon: 'zap', nav: 'Principe', title: 'Comment ça marche', sub: 'PULSA prédit quand tu reviens sur un onglet.' },
  profile: { icon: 'gauge', nav: 'Profil', title: 'Choisis ton profil', sub: 'Un réglage global, modifiable ensuite.' },
  engine: { icon: 'zap', nav: 'PULSA', title: 'Choisis ton PULSA', sub: 'Le moteur de prédiction. Modifiable dans les paramètres.' },
  features: { icon: 'layers', nav: 'Modules', title: 'Ce que ça change', sub: 'Trois modules travaillent déjà pour toi.' },
  extras: { icon: 'image', nav: 'Options', title: 'Deux options en plus', sub: 'Désactivées par défaut, à toi de voir.' },
  recap: { icon: 'shieldCheck', nav: 'Terminé', title: 'Tout est prêt', sub: 'Voici ta configuration.' }
};

const PROFILES = [
  { id: 'prudent', icon: 'moon', tag: 'Doux', name: 'Prudent',
    desc: 'Les onglets restent ouverts plus longtemps avant d\u2019être mis en veille. Pour qui garde beaucoup d\u2019onglets au cas où.',
    settings: { sensitivity: 'prudent', ecoOptimizer: true, safe: true } },
  { id: 'balanced', icon: 'wave', tag: 'Recommandé', name: 'Équilibré',
    desc: 'Le réglage par défaut : un bon compromis entre RAM libérée et onglets prêts à l\u2019usage.',
    settings: { sensitivity: 'balanced', ecoOptimizer: false, safe: true } },
  { id: 'aggressive', icon: 'zap', tag: 'Rapide', name: 'Performance',
    desc: 'Libère la mémoire plus tôt et plus souvent. Pour un PC avec peu de RAM ou beaucoup d\u2019onglets.',
    settings: { sensitivity: 'aggressive', ecoOptimizer: false, safe: true } }
];

const ENGINES = [
  { id: 'pulsa2', icon: 'brain', tag: 'Nouveau', name: 'PULSA 2.1',
    desc: 'Prédit dans combien de temps tu reviens sur un onglet, le met en veille, puis le recharge juste avant ton retour. Un mini cerveau apprend tes habitudes.' },
  { id: 'pulsa', icon: 'gauge', tag: 'Ancien', name: 'PULSA 1.5',
    desc: 'Estime seulement si tu vas rouvrir l\u2019onglet bientôt. Simple et éprouvé : l\u2019onglet se recharge au clic.' }
];

const FEATURES = [
  { icon: 'gauge', name: 'PULSA', text: 'Observe quels onglets tu réutilises et met les autres en veille pour libérer de la RAM. Ils se rechargent dès que tu cliques dessus.' },
  { icon: 'shield', name: 'Safe', text: 'Un onglet avec un appel en cours ou du son n\u2019est jamais mis en veille.' },
  { icon: 'copies', name: 'Doublons', text: 'Repère les onglets identiques ouverts plusieurs fois pour les fermer en un clic.' }
];

const state = { step: 0, lang: 'fr', profile: 'balanced', engine: 'pulsa2' };
const svg = (n) => ICONS[n];
const el = (html) => { const d = document.createElement('div'); d.innerHTML = html.trim(); return d.firstElementChild; };

function card(cls, i, inner, attrs = '') {
  return `<div class="ob-card ${cls}" style="--i:${i}" ${attrs}>${inner}</div>`;
}

const RENDER = {
  lang() {
    return `<div class="ob-grid g3 langs" id="obLangs">${Object.entries(LANGS).map(([c, l], i) =>
      card('lang-btn' + (c === state.lang ? ' sel' : ''), i, `<span class="fl">${FLAGS[c]}</span><b>${l.name}</b><span class="pc">${svg('check')}</span>`, `data-v="${c}"`)).join('')}</div>`;
  },
  how() {
    return `<div class="how">
      <div class="how-bar"><i class="s1"><em>Tu l\u2019utilises</em></i><i class="s2"><em>En veille, RAM libérée</em></i><i class="s3"><em>Rechargé</em></i><i class="s4"><em>Tu reviens</em></i><b class="cursor"></b></div>
      <div class="how-chips"><span class="c c1">Onglet actif</span><span class="c c2">Mis en veille, de la RAM est libérée</span><span class="c c3">Rechargé juste avant ton retour</span><span class="c c4">Déjà chargé, aucune attente</span></div>
    </div>
    <div class="brain-box">
      <svg class="brain" viewBox="0 0 220 90" aria-hidden="true">
        <g class="links"><path d="M30 15L90 22M30 15L90 45M30 15L90 68M30 45L90 22M30 45L90 45M30 45L90 68M30 75L90 22M30 75L90 45M30 75L90 68M90 22L150 30M90 22L150 60M90 45L150 30M90 45L150 60M90 68L150 30M90 68L150 60M150 30L195 45M150 60L195 45"/></g>
        <g class="nodes"><circle cx="30" cy="15" r="5"/><circle cx="30" cy="45" r="5"/><circle cx="30" cy="75" r="5"/><circle cx="90" cy="22" r="5"/><circle cx="90" cy="45" r="5"/><circle cx="90" cy="68" r="5"/><circle cx="150" cy="30" r="5"/><circle cx="150" cy="60" r="5"/><circle class="out" cx="195" cy="45" r="7"/></g>
      </svg>
      <p><b>Le cerveau</b> apprend ton heure, tes enchaînements d\u2019onglets et tes habitudes, uniquement sur cet ordinateur, pour viser le bon moment de rechargement.</p>
    </div>`;
  },
  profile() {
    return `<div class="ob-grid g3 tall" id="obProfiles">${PROFILES.map((p, i) => card('opt' + (p.id === state.profile ? ' sel' : ''), i,
      `<div class="pi">${svg(p.icon)}</div><span class="tag">${p.tag}</span><b>${p.name}</b><p>${p.desc}</p><span class="pc">${svg('check')}</span>`, `data-v="${p.id}"`)).join('')}</div>`;
  },
  engine() {
    return `<div class="ob-grid g2 tall" id="obEngines">${ENGINES.map((p, i) => card('opt' + (p.id === state.engine ? ' sel' : ''), i,
      `<div class="pi">${svg(p.icon)}</div><span class="tag">${p.tag}</span><b>${p.name}</b><p>${p.desc}</p><span class="pc">${svg('check')}</span>`, `data-v="${p.id}"`)).join('')}</div>`;
  },
  features() {
    return `<div class="ob-grid g3 tall">${FEATURES.map((f, i) => card('feat', i, `<div class="pi">${svg(f.icon)}</div><b>${f.name}</b><p>${f.text}</p>`)).join('')}</div>`;
  },
  extras() {
    return `<div class="ob-grid g2 tall">
      ${card('toggle', 0, `<div class="pi">${svg('image')}</div><b>BSWP</b><p>Charge les images et vidéos situées loin sous la zone visible seulement quand tu arrives dessus. Nécessite l\u2019accès aux sites, Chrome te le demandera en l\u2019activant.</p><label class="switch"><input type="checkbox" id="obBswp"><span></span></label>`)}
      ${card('toggle', 1, `<div class="pi">${svg('shieldCheck')}</div><b>AO1 <small>BÊTA</small></b><p>Analyse les fichiers téléchargés pour repérer les signaux suspects.</p><label class="switch"><input type="checkbox" id="obAo1"><span></span></label>`)}
    </div>`;
  },
  recap() {
    return `<div class="recap-top"><svg class="bigcheck" viewBox="0 0 52 52" aria-hidden="true"><circle cx="26" cy="26" r="23"/><path d="M15 27l8 8 15-17"/></svg><p>Tout est modifiable depuis la popup ou les options.</p></div><div class="ob-grid g3 tiles" id="obRecap"></div>`;
  }
};

function build() {
  const root = el(`
  <div id="onboard">
    <aside class="ob-side">
      <div class="ob-brand"><img src="icons/icon48.png" width="30" height="30" alt=""><b>ChromeOptimizer</b></div>
      <ol class="ob-steps">${ORDER.map((id, i) => `<li data-i="${i}"><span class="n"><em>${i + 1}</em>${svg('check')}</span><span class="t">${HEAD[id].nav}</span></li>`).join('')}</ol>
      <p class="ob-foot">Tout reste sur cet ordinateur. Aucun compte, aucun envoi de données.</p>
    </aside>
    <section class="ob-main">
      <div class="ob-head"><div class="ob-icon" id="obHeadIcon"></div><div><h1 id="obTitle"></h1><p class="sub" id="obSub"></p></div></div>
      <div class="ob-viewport"><div class="ob-track" id="obTrack">${ORDER.map((id) => `<div class="ob-step" data-id="${id}">${RENDER[id]()}</div>`).join('')}</div></div>
      <footer>
        <button id="obBack" type="button" hidden>${svg('back')}<span>Retour</span></button>
        <span class="grow"></span>
        <button id="obSkip" type="button">Passer</button>
        <button id="obNext" class="btn primary" type="button"></button>
      </footer>
    </section>
  </div>`);
  document.body.prepend(root);
  return root;
}

async function fillRecap(root) {
  const s = await getSettings();
  const ao1On = (await chrome.storage.local.get('ao1On')).ao1On;
  const on = (v) => (v ? 'Activé' : 'Désactivé');
  const items = [
    ['Profil', { prudent: 'Prudent', balanced: 'Équilibré', aggressive: 'Performance' }[s.sensitivity], true],
    ['PULSA', { pulsa2: '2.1', pulsa: '1.5', classic: 'Désactivé' }[s.algorithm], s.algorithm !== 'classic'],
    ['Cerveau', on(s.brain && s.algorithm === 'pulsa2'), s.brain && s.algorithm === 'pulsa2'],
    ['Safe', on(s.safe), s.safe],
    ['BSWP', on(s.bswp), s.bswp],
    ['AO1 bêta', on(ao1On), !!ao1On]
  ];
  root.querySelector('#obRecap').innerHTML = items.map(([k, v, o], i) =>
    `<div class="ob-card tile ${o ? 'on' : 'off'}" style="--i:${i}"><span class="dot"></span><em>${k}</em><b>${v}</b></div>`).join('');
}

function paint(root) {
  const id = ORDER[state.step], last = state.step === ORDER.length - 1;
  root.querySelector('#obTrack').style.transform = `translateX(-${state.step * 100}%)`;
  root.querySelectorAll('.ob-step').forEach((s, i) => s.classList.toggle('on', i === state.step));
  root.querySelectorAll('.ob-steps li').forEach((li, i) => {
    li.classList.toggle('done', i < state.step);
    li.classList.toggle('cur', i === state.step);
  });
  root.style.setProperty('--p', `${((state.step + 1) / ORDER.length) * 100}%`);
  const h = HEAD[id];
  const head = root.querySelector('.ob-head');
  head.classList.remove('swap'); void head.offsetWidth; head.classList.add('swap');
  root.querySelector('#obHeadIcon').innerHTML = svg(h.icon);
  root.querySelector('#obTitle').textContent = h.title;
  root.querySelector('#obSub').textContent = h.sub;
  root.querySelector('#obBack').hidden = state.step === 0;
  root.querySelector('#obNext').innerHTML = last ? `<span>Terminer</span>${svg('check')}` : `<span>Suivant</span>${svg('arrow')}`;
  root.querySelector('#obSkip').style.display = last ? 'none' : '';
  if (last) fillRecap(root);
}

async function finish(root) {
  await chrome.storage.local.set({ onboarded: true });
  root.classList.add('leaving');
  setTimeout(async () => {
    try { const tab = await chrome.tabs.getCurrent(); await chrome.tabs.remove(tab.id); } catch { window.close(); }
  }, 350);
}

function bindPick(root, boxId, key) {
  const box = root.querySelector('#' + boxId);
  box.addEventListener('click', (e) => {
    const c = e.target.closest('[data-v]');
    if (!c) return;
    box.querySelectorAll('[data-v]').forEach((x) => x.classList.remove('sel'));
    c.classList.add('sel');
    state[key] = c.dataset.v;
  });
}

export async function startOnboarding() {
  const root = build();
  const detected = (chrome.i18n.getUILanguage() || 'fr').slice(0, 2);
  state.lang = detected in LANGS ? detected : 'fr';
  root.querySelectorAll('#obLangs [data-v]').forEach((c) => c.classList.toggle('sel', c.dataset.v === state.lang));
  bindPick(root, 'obLangs', 'lang');
  bindPick(root, 'obProfiles', 'profile');
  bindPick(root, 'obEngines', 'engine');

  root.querySelector('#obSkip').addEventListener('click', () => finish(root));
  root.querySelector('#obBack').addEventListener('click', () => { state.step -= 1; paint(root); });
  root.querySelector('#obNext').addEventListener('click', async () => {
    const id = ORDER[state.step];
    if (id === 'lang') await saveSettings({ lang: state.lang });
    else if (id === 'profile') await saveSettings(PROFILES.find((p) => p.id === state.profile).settings);
    else if (id === 'engine') await saveSettings({ algorithm: state.engine, pulsaLast: state.engine });
    else if (id === 'extras') {
      if (root.querySelector('#obBswp').checked) {
        const ok = await chrome.permissions.request({ origins: ['http://*/*', 'https://*/*'] });
        await saveSettings({ bswp: ok });
      }
      await chrome.storage.local.set({ ao1On: root.querySelector('#obAo1').checked });
    }
    if (state.step === ORDER.length - 1) { await finish(root); return; }
    state.step += 1;
    paint(root);
  });
  paint(root);
}

export async function openWelcomeIfNeeded() {
  const { onboarded } = await chrome.storage.local.get('onboarded');
  if (onboarded) return;
  await chrome.tabs.create({ url: chrome.runtime.getURL('welcome.html') });
  window.close();
}
