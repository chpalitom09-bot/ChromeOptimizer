// node bench/ao1-test.mjs : vérifie le moteur AO1 (sans Chrome)
import { analyze, scoreOf, THRESHOLDS } from '../ao1-core.js';
import { webcrypto } from 'node:crypto';
import assert from 'node:assert/strict';
if (!globalThis.crypto) globalThis.crypto = webcrypto;

const enc = (s) => new TextEncoder().encode(s);
const rnd = (n) => { const a = new Uint8Array(n); for (let i = 0; i < n; i++) a[i] = Math.floor(Math.random() * 256); return a; };
const cat = (...p) => { const o = new Uint8Array(p.reduce((s, x) => s + x.length, 0)); let k = 0; for (const x of p) { o.set(x, k); k += x.length; } return o; };
const run = (c) => { const r = analyze(c); return { ...r, score: scoreOf(r.signals) }; };

function pe({ sections = ['.text', '.data'], rwx = false, body = rnd(8000), extra = '' } = {}) {
  const b = new Uint8Array(0x400); b[0] = 0x4D; b[1] = 0x5A; b[0x3C] = 0x80;
  const p = 0x80; b[p] = 0x50; b[p + 1] = 0x45; b[p + 4] = 0x4C; b[p + 5] = 0x01;
  b[p + 6] = sections.length; b[p + 20] = 0xE0;
  const tbl = p + 24 + 0xE0;
  sections.forEach((s, i) => { for (let k = 0; k < s.length; k++) b[tbl + i * 40 + k] = s.charCodeAt(k); const ch = rwx ? 0xE0000020 : 0x60000020; new DataView(b.buffer).setUint32(tbl + i * 40 + 36, ch >>> 0, true); });
  return cat(b, body, enc(extra));
}
function zip(names, { encrypted = false } = {}) {
  const parts = [enc('PK\x03\x04' + 'x'.repeat(26))];
  const cd = [];
  for (const n of names) {
    const h = new Uint8Array(46); h.set([0x50, 0x4B, 1, 2]); const dv = new DataView(h.buffer);
    dv.setUint16(8, encrypted ? 1 : 0, true); dv.setUint32(20, 100, true); dv.setUint32(24, 200, true); dv.setUint16(28, n.length, true);
    cd.push(cat(h, enc(n)));
  }
  return cat(...parts, rnd(300), ...cd, enc('PK\x05\x06' + '\0'.repeat(18)));
}

const T = [];
const t = (name, fn) => T.push([name, fn]);
const U = 'https://example.org/dl/';

t('EICAR détecté même en .txt', () => {
  const r = run({ url: U + 'e.txt', filename: 'e.txt', bytes: enc('X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*') });
  assert.equal(r.score, 100);
});
t('PDF légitime = sain', () => {
  const r = run({ url: U + 'a.pdf', filename: 'a.pdf', bytes: cat(enc('%PDF-1.7\n'), rnd(5000)) });
  assert.ok(r.score < 10, String(r.score));
});
t('Page HTML de connexion servie à la place du PDF = PAS bloqué (ancien faux positif)', () => {
  const r = run({ url: U + 'a.pdf', filename: 'a.pdf', ctype: 'text/html; charset=utf-8', bytes: enc('<!DOCTYPE html><html><body>Connexion</body></html>' + ' '.repeat(100)) });
  assert.ok(r.score < THRESHOLDS.aggressive, String(r.score));
});
t('HTML sans content-type sous .pdf = soupçon léger seulement', () => {
  const r = run({ url: U + 'a.pdf', filename: 'a.pdf', bytes: enc('<!DOCTYPE html><html><body>x</body></html>' + ' '.repeat(100)) });
  assert.ok(r.score < THRESHOLDS.normal, String(r.score));
});
t('EXE déguisé en PDF = bloqué (normal)', () => {
  const r = run({ url: U + 'facture.pdf', filename: 'facture.pdf', bytes: pe() });
  assert.ok(r.score >= THRESHOLDS.normal, String(r.score));
});
t('Installeur exe légitime (entropie haute, API courantes) ne dépasse pas Normal', () => {
  const r = run({ url: U + 'setup.exe', filename: 'setup.exe', bytes: pe({ body: rnd(200000), extra: 'GetProcAddress LoadLibraryA ShellExecuteW VirtualAlloc CreateProcessW' }) });
  assert.ok(r.score < THRESHOLDS.normal, `score ${r.score}`);
});
t('Installeur exe packé reste < Léger et < Normal', () => {
  const r = run({ url: U + 'tool.exe', filename: 'tool.exe', bytes: pe({ sections: ['UPX0', 'UPX1', '.rsrc'], body: rnd(200000) }) });
  assert.ok(r.score < THRESHOLDS.normal, `score ${r.score}`);
});
t('Même installeur depuis un site de confiance : score bas', () => {
  const r = run({ url: 'https://download.mozilla.org/setup.exe', filename: 'setup.exe', trusted: true, bytes: pe({ sections: ['UPX0', 'UPX1'], rwx: true, body: rnd(200000) }) });
  assert.ok(r.score <= 5, `score ${r.score}`);
});
t('Injection de code + packer + IP brute + HTTP = signalé en Poussé', () => {
  const r = run({ url: 'http://185.10.10.10/x.exe', filename: 'x.exe', bytes: pe({ sections: ['UPX0', 'UPX1'], rwx: true, body: rnd(100000), extra: 'VirtualAllocEx WriteProcessMemory CreateRemoteThread' }) });
  assert.ok(r.score >= THRESHOLDS.aggressive, `score ${r.score}`);
});
t('Dropper PowerShell encodé = bloqué', () => {
  const r = run({ url: U + 'u.ps1', filename: 'u.ps1', bytes: enc('powershell -nop -w hidden -enc ' + 'QQBBAEEAQQBBAEEAQQBBAEEAQQBB'.repeat(3)) });
  assert.ok(r.score >= THRESHOLDS.normal, String(r.score));
});
t('Rançongiciel (vssadmin) = bloqué même dans un .bat', () => {
  const r = run({ url: U + 'r.bat', filename: 'r.bat', bytes: enc('@echo off\nvssadmin delete shadows /all /quiet\nbcdedit /set {default} recoveryenabled no') });
  assert.ok(r.score >= THRESHOLDS.normal, String(r.score));
});
t('Script bat banal = sain-ish', () => {
  const r = run({ url: U + 'ok.bat', filename: 'ok.bat', bytes: enc('@echo off\necho bonjour\npause\n') });
  assert.ok(r.score < THRESHOLDS.normal, String(r.score));
});
t('ZIP avec facture.pdf.exe = bloqué', () => {
  const r = run({ url: U + 'a.zip', filename: 'a.zip', bytes: zip(['facture.pdf.exe']), total: 700 });
  assert.ok(r.score >= THRESHOLDS.normal, String(r.score));
});
t('ZIP chiffré + exe = signalé en Normal', () => {
  const r = run({ url: U + 'a.zip', filename: 'a.zip', bytes: zip(['setup.exe'], { encrypted: true }), total: 700 });
  assert.ok(r.score >= THRESHOLDS.normal && r.score < THRESHOLDS.light, String(r.score));
});
t('ZIP de photos = sain', () => {
  const r = run({ url: U + 'p.zip', filename: 'p.zip', bytes: zip(['a.jpg', 'b.png']), total: 700 });
  assert.ok(r.score < 10, String(r.score));
});
t('Zip slip = bloqué', () => {
  const r = run({ url: U + 'a.zip', filename: 'a.zip', bytes: zip(['../../Windows/x.dll']), total: 700 });
  assert.ok(r.score >= 40, String(r.score));
});
t('docx avec vbaProject.bin = signalé fort', () => {
  const r = run({ url: U + 'c.docx', filename: 'c.docx', bytes: zip(['word/document.xml', 'word/vbaProject.bin']), total: 700 });
  assert.ok(r.score >= 35, String(r.score));
});
t('Image polyglotte = bloquée', () => {
  const r = run({ url: U + 'x.png', filename: 'x.png', bytes: cat(Uint8Array.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]), enc('<script>alert(1)</script>'.padEnd(200))) });
  assert.ok(r.score >= THRESHOLDS.normal, String(r.score));
});
t('jpg qui est en fait un png = quasi sain', () => {
  const r = run({ url: U + 'x.jpg', filename: 'x.jpg', bytes: cat(Uint8Array.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]), rnd(500)) });
  assert.ok(r.score < 10, String(r.score));
});
t('mp4 aléatoire (haute entropie) = sain', () => {
  const r = run({ url: U + 'v.mp4', filename: 'v.mp4', bytes: cat(Uint8Array.from([0, 0, 0, 0x20, 0x66, 0x74, 0x79, 0x70]), rnd(200000)) });
  assert.ok(r.score < 10, String(r.score));
});
t('Double extension dans le nom', () => {
  const r = run({ url: U + 'a.pdf.exe', filename: 'a.pdf.exe' });
  assert.ok(r.score >= 45, String(r.score));
});
t('Sans contenu (fetch impossible) un exe normal reste sous Normal', () => {
  const r = run({ url: U + 'setup.exe', filename: 'setup.exe' });
  assert.ok(r.score < THRESHOLDS.normal, String(r.score));
});
t('Nom vide + exe renvoyé : pas de faux positif dur', () => {
  const r = run({ url: U + 'download?id=3', filename: 'download', bytes: pe({ body: rnd(5000) }) });
  assert.ok(r.score < THRESHOLDS.normal, String(r.score));
});
t('Domaine liste noire', () => {
  const r = run({ url: 'https://malware.com/a.exe', filename: 'a.exe' });
  assert.ok(r.score >= 60, String(r.score));
});

let fail = 0;
for (const [n, f] of T) { try { f(); console.log('✔', n); } catch (e) { fail++; console.log('✘', n, '\n   ', e.message); } }
console.log(fail ? `\n${fail} échec(s)` : `\n${T.length}/${T.length} OK`);
process.exit(fail ? 1 : 0);
