// PULSA 2.0 : rechargement anticipé. Une seule alarme à usage unique, armée sur le prochain
// rechargement prévu ; aucune alarme tant qu'aucun onglet n'attend. Rien ne tourne en continu.
import { nextWake, takeDue, unmarkPre } from './pulsa-store.js';
import { offline } from './net.js';

export const PRELOAD_ALARM = 'chromeoptimizer-preload';

export async function armPreload() {
  const w = await nextWake();
  if (!w) { await chrome.alarms.clear(PRELOAD_ALARM); return; }
  await chrome.alarms.create(PRELOAD_ALARM, { when: Math.max(Date.now() + 30000, w) });   // Chrome n'accepte pas moins de 30 s
}

// Recharge (en arrière-plan, sans l'activer) les onglets en veille dont l'heure est venue.
export async function runPreload() {
  const { settings } = await chrome.storage.local.get('settings');
  if (offline() && !(settings && settings.offlineGuard === false)) {   // recharger sans réseau donnerait une page d'erreur : on réessaie dans 1 min
    await chrome.alarms.create(PRELOAD_ALARM, { delayInMinutes: 1 });
    return;
  }
  const ids = await takeDue();
  let ram = 0;
  try { const m = await chrome.system.memory.getInfo(); ram = 1 - m.availableCapacity / m.capacity; } catch { /* ignoré */ }
  const skipped = [];
  for (const id of ids) {
    try {
      const tab = await chrome.tabs.get(id);
      if (!tab.discarded || tab.active || ram > 0.92) { skipped.push(id); continue; }   // déjà rechargé, ou RAM saturée : on laisse dormir
      await chrome.tabs.reload(id);
    } catch { skipped.push(id); }
  }
  if (skipped.length) await unmarkPre(skipped);
  await armPreload();
}
