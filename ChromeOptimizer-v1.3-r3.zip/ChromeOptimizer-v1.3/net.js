// Sécurité hors connexion : détecte l'absence de réseau (ou une connexion quasi inutilisable).
// Un onglet en veille se recharge au retour ; sans réseau il afficherait une page d'erreur, donc on n'en met aucun en veille.
export function offline() {
  try {
    const c = navigator.connection;
    return navigator.onLine === false || !!(c && (c.effectiveType === 'slow-2g' || c.effectiveType === '2g'));
  } catch { return false; }
}
