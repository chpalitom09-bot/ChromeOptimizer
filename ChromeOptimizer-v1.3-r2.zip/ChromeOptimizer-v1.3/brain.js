// PULSA 2.1 — « cerveau » : mini-réseau de neurones qui apprend EN DIRECT chez l'utilisateur (296 paramètres, ~10 Ko).
// Module pur. Il prédit le délai de retour en tenant compte du CONTEXTE que PULSA 2.0 ignore :
// heure, jour, nombre d'onglets, et surtout l'onglet vers lequel tu es parti (« après Docs, je rouvre Mail vite »).
//
// Modèle : régression par quantiles (perte « pinball »), une tête par risque de rater (10, 20, 30 %).
//   cible = ln(délai de retour) − ln(délai habituel du site)   → le modèle ne corrige que l'écart à l'habitude
//   entrée = 24 variables ; apprentissage : un pas de gradient à chaque retour + 4 rejeux d'anciens retours.
// Garde-fous : mélange borné avec la méthode empirique de 2.0, confiance qui monte avec l'expérience,
// et chute si la tête 20 % rate trop souvent (calibration mesurée en continu).
// Vie privée : seulement des noms de domaine, l'heure et des durées.

export const HEADS = [0.1, 0.2, 0.3];
export const NF = 24, NH = 8, VER = 2;
export const BRAIN = { ready: 30, maxConf: 0.85, confN: 250, lr: 0.06, l2: 1e-3, clipY: 3, pairCap: 8, pairMem: 12, rbCap: 150, replay: 8 };
const BIAS0 = [-0.6, -0.4, -0.25];   // départ : un peu avant le délai habituel
const clip = (x, a, b) => Math.min(b, Math.max(a, x));
export const paramCount = () => NF * NH + NH + HEADS.length * (NF + NH);   // 296 poids

// Générateur pseudo-aléatoire déterministe (initialisation et rejeu reproductibles).
const lcg = (x) => (Math.imul(x, 1664525) + 1013904223) >>> 0;

// Réseau : 24 entrées → 8 neurones (tanh) → 3 sorties (quantiles), plus un chemin linéaire direct
// (le réseau n'ajoute que ce que le linéaire ne sait pas faire ; sorties du réseau à 0 au départ).
export function emptyBrain() {
  let r = 12345;
  const W1 = Array.from({ length: NH }, () => Array.from({ length: NF }, () => { r = lcg(r); return ((r / 4294967296) - 0.5) * 0.6; }));
  const lin = HEADS.map((_, k) => { const a = new Array(NF).fill(0); a[0] = BIAS0[k]; return a; });
  return { ver: VER, W1, b1: new Array(NH).fill(0), lin, v: HEADS.map(() => new Array(NH).fill(0)), n: 0, cov: 0.2, seed: 99 };
}
export const isCurrent = (m) => !!m && m.ver === VER;

function sorted(iv) { return iv.filter((x) => x > 0).map(Math.log).sort((a, b) => a - b); }
function medLn(iv) { const p = sorted(iv); return p.length >= 3 ? p[p.length >> 1] : null; }
// Délai « habituel » (ln minutes) : médiane du site, sinon globale, sinon 20 min.
export function baseLn(rec, glob) {
  const a = rec && medLn(rec.iv); if (a != null) return a;
  const g = glob && medLn(glob.iv); return g != null ? g : Math.log(20);
}

// Empreinte d'un nom de domaine en 3 valeurs ±0,5 (projection aléatoire : le réseau peut ainsi
// apprendre des effets propres à un site ou à une destination, sans table de mots).
function hash3(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) h = Math.imul(h ^ str.charCodeAt(i), 16777619) >>> 0;
  h = Math.imul(h ^ (h >>> 15), 2246822507) >>> 0; h = Math.imul(h ^ (h >>> 13), 3266489909) >>> 0;
  return [0, 1, 2].map((k) => (((h >>> (k * 5)) & 1) ? 0.5 : -0.5));
}

// Contexte au départ de l'onglet : { h: heure 0–24, d: jour 0–6, n: nb d'onglets, B: destination, A: ce site }.
export function feat(c, rec, glob) {
  const lb = baseLn(rec, glob);
  const tr = rec && rec.tr && rec.tr[c.B];
  const conf = tr ? tr[0] / (tr[0] + 3) : 0;
  const dd = tr ? clip(tr[1] - lb, -2, 2) : 0;
  const lns = rec ? sorted(rec.iv) : [];
  const pos = rec ? rec.iv.filter((x) => x > 0) : [];
  const res = (x) => clip(Math.log(x) - lb, -2, 2);
  const last = pos.length ? res(pos[pos.length - 1]) : 0;
  const trend = pos.length ? pos.slice(-3).reduce((a, x) => a + res(x), 0) / Math.min(3, pos.length) : 0;
  const spread = lns.length >= 4 ? clip(lns[Math.floor(lns.length * 0.75)] - lns[Math.floor(lns.length * 0.25)], 0, 2) - 1 : 0;
  const a = (2 * Math.PI * c.h) / 24, w = (2 * Math.PI * c.d) / 7;
  const f = [1, Math.sin(a), Math.cos(a), Math.sin(2 * a), Math.cos(2 * a), Math.sin(3 * a), Math.cos(3 * a),
    c.d === 0 || c.d === 6 ? 1 : 0, Math.sin(w), Math.cos(w), Math.log(Math.max(1, c.n)) - 2,
    dd, conf, dd * conf, last, trend, Math.log(1 + pos.length) / 3 - 1,
    ...hash3(c.B || ''), ...hash3(c.A || ''), spread];
  return { f, lb };
}

function forward(m, f) {
  const h = new Array(NH);
  for (let j = 0; j < NH; j++) { let s = m.b1[j]; const w = m.W1[j]; for (let i = 0; i < NF; i++) s += w[i] * f[i]; h[j] = Math.tanh(s); }
  const out = HEADS.map((_, k) => { let s = 0; const l = m.lin[k], v = m.v[k]; for (let i = 0; i < NF; i++) s += l[i] * f[i]; for (let j = 0; j < NH; j++) s += v[j] * h[j]; return s; });
  return { h, out };
}

// Résidu prédit au risque q (interpolé entre les têtes).
export function residual(model, f, q) {
  const p = forward(model, f).out;
  if (q <= HEADS[0]) return p[0];
  if (q >= HEADS[2]) return p[2];
  const k = q < HEADS[1] ? 0 : 1, u = (q - HEADS[k]) / (HEADS[k + 1] - HEADS[k]);
  return p[k] + u * (p[k + 1] - p[k]);
}

// Un pas de gradient (perte pinball) ; retourne les prédictions d'avant le pas.
function step(m, f, y, lr) {
  const { h, out } = forward(m, f);
  const g = HEADS.map((q, k) => (y < out[k] ? 1 - q : -q));       // dérivée de la perte pinball
  const delta = new Array(NH).fill(0);
  for (let k = 0; k < HEADS.length; k++) {
    const l = m.lin[k], v = m.v[k];
    for (let j = 0; j < NH; j++) { delta[j] += g[k] * v[j] * (1 - h[j] * h[j]); v[j] = clip(v[j] - lr * g[k] * h[j], -4, 4); }
    for (let i = 0; i < NF; i++) { l[i] = clip(l[i] - lr * g[k] * f[i], -4, 4); if (i) l[i] *= 1 - BRAIN.l2; }
  }
  for (let j = 0; j < NH; j++) {
    const w = m.W1[j];
    for (let i = 0; i < NF; i++) { w[i] = clip(w[i] - lr * delta[j] * f[i], -4, 4); w[i] *= 1 - BRAIN.l2; }
    m.b1[j] -= lr * delta[j];
  }
  return out;
}

// Apprend un exemple, plus quelques exemples rejoués (rb = mémoire des derniers retours) : bien plus efficace avec peu de données.
export function train(model, f, yRes, rb) {
  const y = clip(yRes, -BRAIN.clipY, BRAIN.clipY);
  const lr = BRAIN.lr / Math.sqrt(1 + model.n / 150);
  const out = step(model, f, y, lr);
  model.cov = 0.95 * model.cov + 0.05 * (y < out[1] ? 1 : 0);   // la tête 20 % doit rater ~20 % du temps
  if (rb) {
    for (let r = 0; r < BRAIN.replay && rb.length > 8; r++) {
      model.seed = lcg(model.seed);
      const s = rb[model.seed % rb.length];
      step(model, s[0], s[1], lr * 0.5);
    }
    rb.push([f.map((x) => Math.round(x * 1000) / 1000), Math.round(y * 1000) / 1000]);
    if (rb.length > BRAIN.rbCap) rb.shift();
  }
  model.n++;
  return model;
}

// Mémorise « depuis ce site, en partant vers B, retour en ~x min » (moyenne glissante en ln).
export function notePair(rec, B, minutes) {
  if (!B) return;
  rec.tr = rec.tr || {};
  const y = Math.log(Math.max(0.1, minutes)), e = rec.tr[B] || [0, y];
  e[0]++; e[1] += (y - e[1]) / Math.min(e[0], BRAIN.pairMem);
  rec.tr[B] = e;
  const ks = Object.keys(rec.tr);
  if (ks.length > BRAIN.pairCap) { ks.sort((a, b) => rec.tr[a][0] - rec.tr[b][0]); delete rec.tr[ks[0]]; }
}

// Un retour observé : apprend, puis met à jour les stats de destination. À appeler AVANT recordReturn.
export function learn(model, c, rec, glob, minutes, rb) {
  const { f, lb } = feat(c, rec, glob);
  train(model, f, Math.log(Math.max(0.1, minutes)) - lb, rb);
  if (rec) notePair(rec, c.B, minutes);
  return model;
}

// Confiance dans le cerveau (0 → 0,6) : expérience × calibration.
export function confidence(model) {
  if (!model || model.n < BRAIN.ready) return 0;
  const exp = Math.min(BRAIN.maxConf, (model.n / BRAIN.confN) * BRAIN.maxConf);
  const cal = model.cov > 0.2 ? Math.max(0, 1 - (model.cov - 0.2) * 4) : 1;   // trop de retours avant la prédiction : on s'efface
  return exp * cal;
}

// Corrige l'attente (minutes) de PULSA 2.0 avec l'avis du cerveau. Borné : jamais < 0,5× ni > 3×.
export function blendWait(wait, idleMin, q, b) {
  const c = confidence(b.model);
  if (!c) return wait;
  const total = Math.exp(b.lb + residual(b.model, b.f, q));   // délai de retour total prédit
  const waitB = total - idleMin;
  if (!(waitB > 0)) return wait;                                // le cerveau pense que c'est déjà dépassé : on garde 2.0
  const mix = Math.exp((1 - c) * Math.log(wait) + c * Math.log(waitB));
  return clip(mix, wait * 0.5, wait * 3);
}

// Pour la page IA des réglages.
export function brainStats(model) {
  return { params: paramCount(), n: model ? model.n : 0, conf: confidence(model), cov: model ? model.cov : 0.2, ready: !!model && model.n >= BRAIN.ready };
}
// Rythme appris par heure : > 1 = tu reviens plus lentement que d'habitude à cette heure, < 1 = plus vite.
export function hourProfile(model) {
  const v = Array.from({ length: 24 }, (_, h) => Math.exp(residual(model, feat({ h: h + 0.5, d: 2, n: 8, B: '', A: '' }, null, null).f, 0.2)));
  const mean = v.reduce((a, x) => a + x, 0) / 24;
  return v.map((x) => x / mean);
}
