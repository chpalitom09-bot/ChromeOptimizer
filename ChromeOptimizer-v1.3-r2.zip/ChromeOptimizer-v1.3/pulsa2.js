// PULSA 2.0 — prédiction du DÉLAI de retour (module pur, aucune API Chrome).
//
// PULSA 1.5 répond à « l'onglet sera-t-il rouvert bientôt ? ». PULSA 2.0 répond à
// « dans combien de temps ? », donc :
//   - retour très probable dans < ~10 min  → on ne touche à rien (le gain serait nul) ;
//   - retour prévu dans 15 min             → veille MAINTENANT, rechargement à ~14 min :
//                                            l'utilisateur revient, l'onglet est déjà chargé ;
//   - retour improbable                    → veille, sans rechargement.
//
// Méthode : distribution empirique du temps restant avant retour, sachant l'inactivité t.
//   échantillons = intervalles du domaine (poids récence) + intervalles globaux (poids réduit)
//   + a priori (pseudo-observations, repris de PULSA 1.5) ; les onglets fermés sans retour
//   comptent comme « pas de retour » (queue). On lit le quantile « risque de rater » q :
//   « il y a q % de chances que l'utilisateur soit déjà revenu à ce moment-là ».
//   Rechargement = ce quantile − marge. Le risque q est réglé par la sensibilité, la prudence
//   apprise (faux positifs) et le taux réel de ratés mesuré (hit / miss).
import { priorP, PULSA_DEFAULTS } from './pulsa.js';
import { blendWait } from './brain.js';

export const P2 = {
  minGain:  { prudent: 15, balanced: 10, aggressive: 6 },       // minutes de veille minimales pour que ça vaille le coup
  miss:     { prudent: 0.10, balanced: 0.20, aggressive: 0.30 }, // risque accepté que l'utilisateur revienne avant le rechargement
  floorMin: 3,        // inactivité minimale (min) avant d'évaluer un onglet (remplace le délai de 30 min de 1.5)
  margin: 1,          // rechargement avec 1 min d'avance
  maxPreload: 120,    // au-delà, la veille est « longue » : pas de rechargement
  preloadMinP: 0.35,  // probabilité de retour (6 h) minimale pour recharger à l'avance
  hold: 12,           // après un rechargement, pas de nouvelle veille pendant 12 min
  minObs: 6,          // observations minimales (domaine + 0,35 × global) ; en dessous : comportement 1.5
  globW: 0.35,        // poids de l'historique global face à celui du domaine
  H: 360              // horizon (min)
};

const GRID = [2, 5, 10, 15, 30, 60, 120, 360];

// Échantillons pondérés [temps restant, poids] ; la queue (pas de retour) = poids restant.
function samples(rec, glob, t, cfg) {
  const out = []; let nObs = 0;
  const add = (iv, mult) => {
    const n = iv.length;
    for (let i = 0; i < n; i++) {
      const w = mult * Math.pow(cfg.recency, n - 1 - i), x = iv[i];
      nObs += mult;                                          // chaque observation compte, retour ou non
      if (x > 0) { if (x > t) out.push([x - t, w]); }
      else if (-x - t >= P2.H) out.push([Infinity, w]);   // survécu à tout l'horizon sans retour
    }
  };
  if (rec && rec.iv.length) add(rec.iv, 1);
  if (glob && glob.iv.length) add(glob.iv, P2.globW);
  // A priori de PULSA 1.5, découpé sur la grille : masse de chaque tranche.
  // Son poids fond à mesure que les données arrivent : l'a priori ne doit pas brouiller un habitué.
  const a = cfg.priorWeight * 6 / (6 + nObs);
  let prev = 0, lo = 0;
  for (const h of GRID) {
    const F = priorP(t, h, cfg);
    out.push([(lo + h) / 2, a * (F - prev)]);
    prev = F; lo = h;
  }
  out.push([Infinity, a * (1 - prev)]);
  return { out, nObs };
}

// Prévision : { pRet, wait, nObs } — wait = minutes avant le quantile « risque de rater » (null si jamais).
export function forecast(rec, glob, t, qMiss, cfg = PULSA_DEFAULTS) {
  const { out, nObs } = samples(rec, glob, t, cfg);
  out.sort((a, b) => a[0] - b[0]);
  let W = 0; for (const s of out) W += s[1];
  let cum = 0, wait = null, pRet = 0;
  for (const [r, w] of out) {
    if (r > P2.H) break;
    cum += w;
    pRet = cum / W;
    if (wait === null && pRet >= qMiss) wait = r;
  }
  return { pRet, wait, nObs };
}

// Prudence apprise des faux positifs (même formule que 1.5, valeur 0–0,6).
function caution(rec, t, cfg) {
  if (!rec) return 0;
  const fpRate = rec.fp / (rec.fp + rec.ok + 3);
  return Math.min(cfg.fpCap, fpRate * cfg.fpStrength) * Math.exp((-Math.LN2 * t) / (2 * cfg.halfLifeMin));
}

// Ajuste le risque selon les retours réels : trop de ratés → plus prudent, aucun → un peu plus de veille.
export function missFactor(p2, q) {
  if (!p2 || p2.hit + p2.miss < 6) return 1;
  const r = p2.miss / (p2.hit + p2.miss);
  return Math.min(1.3, Math.max(0.5, q / Math.max(r, 0.02)));
}

/**
 * Décision pour un onglet inactif depuis idleMin minutes.
 * @returns {{act:'keep'|'sleep'|'legacy', wake?:number, pRet:number, wait:number|null}}
 *   wake = minutes avant rechargement (absent = pas de rechargement).
 */
export function decide(rec, glob, idleMin, o) {
  const cfg = PULSA_DEFAULTS;
  const f = forecast(rec, glob, idleMin, 0.5, cfg);            // pour nObs seulement
  if (f.nObs < P2.minObs) return { act: 'legacy', pRet: f.pRet, wait: null };   // pas assez de données : PULSA 1.5
  const q = Math.min(0.5, P2.miss[o.sens] * (1 - caution(rec, idleMin, cfg)) * missFactor(o.p2, P2.miss[o.sens]));
  const minGain = Math.min(30, Math.max(3, P2.minGain[o.sens] / (o.factor || 1)));
  const r = forecast(rec, glob, idleMin, q, cfg);
  if (r.wait === null) return { act: 'sleep', pRet: r.pRet, wait: null };   // retour improbable : veille sans rechargement
  const wait = o.brain ? blendWait(r.wait, idleMin, q, o.brain) : r.wait;   // 2.1 : le cerveau affine le délai
  const gain = wait - P2.margin;
  if (gain < minGain) return { act: 'keep', pRet: r.pRet, wait };   // retour trop proche : ça ne vaut pas le coup
  const reload = o.canPreload && !o.preloaded && r.pRet >= P2.preloadMinP && gain <= P2.maxPreload;
  return reload ? { act: 'sleep', wake: gain, pRet: r.pRet, wait } : { act: 'sleep', pRet: r.pRet, wait };
}
