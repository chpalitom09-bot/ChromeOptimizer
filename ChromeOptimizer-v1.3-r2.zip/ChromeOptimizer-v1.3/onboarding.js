// Écran de premier démarrage : affiché une seule fois (flag "onboarded" en storage.local).
import { getSettings, saveSettings } from './lib.js';
import { LANGS, FLAGS } from './i18n.js';

const ICONS = {
  globe: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20 15 15 0 0 1 0-20z"/></svg>',
  shield: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l8 4v6c0 5-3.4 8.6-8 10-4.6-1.4-8-5-8-10V6z"/></svg>',
  gauge: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 15l3.5-5.5"/><circle cx="12" cy="13" r="8"/><path d="M8 5.5A8 8 0 0 1 12 5"/></svg>',
  zap: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2 4 14h7l-1 8 9-12h-7z"/></svg>',
  moon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8z"/></svg>',
  wave: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/></svg>',
  layers: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5M2 12l10 5 10-5"/></svg>',
  image: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="9" cy="9" r="1.6"/><path d="M21 15l-5-5L5 21"/></svg>',
  shieldCheck: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l8 4v6c0 5-3.4 8.6-8 10-4.6-1.4-8-5-8-10V6z"/><path d="M9 12l2 2 4-4"/></svg>',
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
  checkBig: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
  info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/></svg>',
  arrow: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
  back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M11 18l-6-6 6-6"/></svg>',
  copies: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/></svg>'
};

const HEAD = [
  { icon: 'globe',  title: 'Bienvenue !',             sub: 'Avant tout, une langue.' },
  { icon: 'gauge',  title: 'Choisis ton profil',      sub: 'On règle tout d\u2019un coup, modifiable ensuite.' },
  { icon: 'zap',    title: 'Choisis ton PULSA',       sub: 'Le moteur de prédiction. Modifiable dans les paramètres.' },
  { icon: 'layers', title: 'Ce que ça change',        sub: 'Trois modules travaillent déjà pour toi.' },
  { icon: 'image',  title: 'Deux options en plus',    sub: 'Désactivées par défaut, à toi de voir.' },
  { icon: 'shieldCheck', title: 'C\u2019est prêt',     sub: 'Récapitulatif de ta configuration.' }
];

const PROFILES = [
  { id: 'prudent',    icon: 'moon', tag: 'Doux',   name: 'Prudent',
    desc: 'Les onglets restent ouverts plus longtemps avant d\u2019être mis en veille. Pour qui garde beaucoup d\u2019onglets \u00ab au cas où \u00bb.',
    settings: { sensitivity: 'prudent', ecoOptimizer: true, safe: true } },
  { id: 'balanced',   icon: 'wave', tag: 'Recommandé', name: 'Équilibré',
    desc: 'Le réglage par défaut : un bon compromis entre RAM libérée et onglets gardés prêts à l\u2019usage.',
    settings: { sensitivity: 'balanced', ecoOptimizer: false, safe: true } },
  { id: 'aggressive', icon: 'zap',  tag: 'Rapide', name: 'Performance',
    desc: 'Libère la mémoire plus tôt et plus souvent. Pour un PC avec peu de RAM ou beaucoup d\u2019onglets ouverts.',
    settings: { sensitivity: 'aggressive', ecoOptimizer: false, safe: true } }
];

const ENGINES = [
  { id: 'pulsa2', icon: 'zap', tag: 'Nouveau', name: 'PULSA 2.1',
    desc: 'Prédit dans combien de temps tu reviens sur un onglet : il le met en veille, puis le recharge juste avant ton retour. Un mini-cerveau apprend tes habitudes (heure, enchaînements d\u2019onglets).' },
  { id: 'pulsa', icon: 'gauge', tag: 'Ancien', name: 'PULSA 1.5',
    desc: 'Estime seulement si tu vas rouvrir l\u2019onglet bientôt. Simple et éprouvé : l\u2019onglet se recharge au clic.' }
];
let engine = 'pulsa2';

const FEATURES = [
  { icon: 'gauge',  name: 'PULSA', text: 'Observe quels onglets tu réutilises et met les autres en veille pour libérer de la RAM — ils se rechargent dès que tu cliques dessus.' },
  { icon: 'shield', name: 'Safe',  text: 'Un onglet avec un appel en cours ou du son ne sera jamais mis en veille.' },
  { icon: 'copies', name: 'Doublons', text: 'Détecte les onglets identiques ouverts plusieurs fois, pour les fermer en un clic.' }
];

const STEPS = HEAD.length;
let step = 0;
let profile = 'balanced';

function el(html) { const d = document.createElement('div'); d.innerHTML = html.trim(); return d.firstElementChild; }
const svg = (name) => ICONS[name];

function stepLang() {
  const opts = Object.entries(LANGS).map(([c, l]) => `<option value="${c}">${l.name}</option>`).join('');
  return `
  <div class="ob-in">
    <div class="ob-lang-row">
      <span class="ll" id="obLangFlag">${FLAGS.fr}<span>Langue de l\u2019interface</span></span>
      <select id="obLang">${opts}</select>
    </div>
    <div class="ob-note">${svg('info')}<span>Détectée automatiquement à partir de ton navigateur — change-la si besoin, elle s\u2019applique partout dans l\u2019extension.</span></div>
  </div>`;
}

function stepProfile() {
  return `<div class="ob-in"><div class="ob-profiles" id="obProfiles">${PROFILES.map((p) => `
    <div class="ob-profile${p.id === profile ? ' sel' : ''}" data-p="${p.id}">
      <div class="pi">${svg(p.icon)}</div>
      <div class="pt"><b>${p.name}<span class="tag">${p.tag}</span></b><p>${p.desc}</p></div>
      <div class="pc">${svg('check')}</div>
    </div>`).join('')}</div></div>`;
}

function stepEngine() {
  return `<div class="ob-in"><div class="ob-profiles" id="obEngines">${ENGINES.map((p) => `
    <div class="ob-profile${p.id === engine ? ' sel' : ''}" data-e="${p.id}">
      <div class="pi">${svg(p.icon)}</div>
      <div class="pt"><b>${p.name}<span class="tag">${p.tag}</span></b><p>${p.desc}</p></div>
      <div class="pc">${svg('check')}</div>
    </div>`).join('')}</div></div>`;
}

function stepFeatures() {
  return `<div class="ob-in"><div class="ob-features">${FEATURES.map((f) => `
    <div class="ob-feature"><div class="fi">${svg(f.icon)}</div><div><b>${f.name}</b><span>${f.text}</span></div></div>`).join('')}</div></div>`;
}

function stepExtras() {
  return `<div class="ob-in">
    <div class="ob-toggle-card">
      <div class="row">
        <span class="ti"><span class="fi">${svg('image')}</span><b>BSWP</b></span>
        <label class="switch"><input type="checkbox" id="obBswp"><span></span></label>
      </div>
      <p>Charge les images/vidéos loin sous la zone visible seulement quand tu arrives dessus. Nécessite l\u2019accès aux sites — Chrome te le demandera en l\u2019activant.</p>
    </div>
    <div class="ob-toggle-card">
      <div class="row">
        <span class="ti"><span class="fi">${svg('shieldCheck')}</span><b>AO1 <small>BÊTA</small></b></span>
        <label class="switch"><input type="checkbox" id="obAo1"><span></span></label>
      </div>
      <p>Analyse les fichiers téléchargés pour repérer les signaux suspects.</p>
    </div>
  </div>`;
}

function stepRecap() {
  return `<div class="ob-in">
    <div class="ob-recap-head"><div class="ok">${svg('checkBig')}</div><b>Configuration terminée</b><span>Tout est modifiable depuis la popup ou les options</span></div>
    <ul class="ob-recap" id="obRecap"></ul>
  </div>`;
}

const RENDER = [stepLang, stepProfile, stepEngine, stepFeatures, stepExtras, stepRecap];

function build() {
  const root = el(`
  <div id="onboard">
    <div class="ob-head">
      <div class="ob-icon" id="obHeadIcon"></div>
      <div><h1 id="obTitle"></h1><p class="sub" id="obSub"></p></div>
    </div>
    <div class="ob-bar" id="obBar">${Array.from({ length: STEPS }, () => '<i><b></b></i>').join('')}</div>
    <div class="ob-viewport"><div class="ob-track" id="obTrack">
      ${RENDER.map((fn) => `<div class="ob-step">${fn()}</div>`).join('')}
    </div></div>
    <footer>
      <button id="obBack" type="button" hidden>${svg('back')}<span>Retour</span></button>
      <button id="obSkip" type="button">Passer</button>
      <button id="obNext" class="btn primary" type="button"><span>Suivant</span>${svg('arrow')}</button>
    </footer>
  </div>`);
  document.body.prepend(root);
  return root;
}

function paint(root) {
  root.querySelector('#obTrack').style.transform = `translateX(-${step * 100}%)`;
  root.querySelectorAll('.ob-bar i').forEach((b, i) => {
    b.classList.toggle('done', i < step);
    b.classList.toggle('cur', i === step);
  });
  const h = HEAD[step];
  root.querySelector('#obHeadIcon').innerHTML = svg(h.icon);
  root.querySelector('#obTitle').textContent = h.title;
  root.querySelector('#obSub').textContent = h.sub;
  root.querySelector('#obBack').hidden = step === 0;
  const next = root.querySelector('#obNext');
  next.innerHTML = step === STEPS - 1 ? `<span>Terminer</span>${svg('check')}` : `<span>Suivant</span>${svg('arrow')}`;
  root.querySelector('#obSkip').style.display = step === STEPS - 1 ? 'none' : '';
  if (step === STEPS - 1) fillRecap(root);
  const inAnim = root.querySelectorAll('.ob-step')[step].querySelector('.ob-in');
  if (inAnim) { inAnim.style.animation = 'none'; void inAnim.offsetWidth; inAnim.style.animation = ''; }
}

async function fillRecap(root) {
  const s = await getSettings();
  const ao1On = (await chrome.storage.local.get('ao1On')).ao1On;
  const items = [
    ['Profil', { prudent: 'Prudent', balanced: 'Équilibré', aggressive: 'Performance' }[s.sensitivity], true],
    ['PULSA', { pulsa2: '2.1', pulsa: '1.5', classic: 'désactivé' }[s.algorithm], s.algorithm !== 'classic'],
    ['Safe', s.safe ? 'activé' : 'désactivé', s.safe],
    ['BSWP', s.bswp ? 'activé' : 'désactivé', s.bswp],
    ['AO1 (bêta)', ao1On ? 'activé' : 'désactivé', !!ao1On]
  ];
  root.querySelector('#obRecap').innerHTML = items.map(([k, v, on]) =>
    `<li><span class="dot ${on ? 'on' : 'off'}"></span><b>${k}</b><em>${v}</em></li>`).join('');
}

async function finish(root) {
  await chrome.storage.local.set({ onboarded: true });
  root.style.animation = 'obFade .22s ease reverse forwards';
  setTimeout(() => location.reload(), 190);
}

export async function maybeShowOnboarding() {
  const { onboarded } = await chrome.storage.local.get('onboarded');
  if (onboarded) return;

  const root = build();
  const detected = (chrome.i18n.getUILanguage() || 'fr').slice(0, 2);
  const langCode = detected in LANGS ? detected : 'fr';
  root.querySelector('#obLang').value = langCode;
  root.querySelector('#obLangFlag').innerHTML = `${FLAGS[langCode]}<span>Langue de l\u2019interface</span>`;
  root.querySelector('#obLang').addEventListener('change', (e) => {
    root.querySelector('#obLangFlag').innerHTML = `${FLAGS[e.target.value]}<span>Langue de l\u2019interface</span>`;
  });

  const pick = (box, key, set) => root.querySelectorAll(`#${box} .ob-profile`).forEach((p) => p.addEventListener('click', () => {
    root.querySelectorAll(`#${box} .ob-profile`).forEach((x) => x.classList.remove('sel'));
    p.classList.add('sel');
    set(p.dataset[key]);
  }));
  pick('obProfiles', 'p', (v) => { profile = v; });
  pick('obEngines', 'e', (v) => { engine = v; });

  root.querySelector('#obSkip').addEventListener('click', () => finish(root));
  root.querySelector('#obBack').addEventListener('click', () => { step -= 1; paint(root); });

  root.querySelector('#obNext').addEventListener('click', async () => {
    if (step === 0) {
      await saveSettings({ lang: root.querySelector('#obLang').value });
    } else if (step === 1) {
      await saveSettings(PROFILES.find((p) => p.id === profile).settings);
    } else if (step === 2) {
      await saveSettings({ algorithm: engine, pulsaLast: engine });
    } else if (step === 4) {
      const wantBswp = root.querySelector('#obBswp').checked;
      if (wantBswp) {
        const ok = await chrome.permissions.request({ origins: ['http://*/*', 'https://*/*'] });
        await saveSettings({ bswp: ok });
      }
      await chrome.storage.local.set({ ao1On: root.querySelector('#obAo1').checked });
    }
    if (step === STEPS - 1) { await finish(root); return; }
    step += 1;
    paint(root);
  });

  paint(root);
}
