import { getSettings, saveSettings, getStats, analyze, optimize, hostOf, isProtectedSite, getContext } from './lib.js';
import { getUpdateInfo, isNewer, PAGE_URL, currentLabel } from './update.js';
import { loadModel } from './pulsa-store.js';
import { initLang, mountLangSwitcher, t, tn, num } from './i18n.js';
import { ecoProfile } from './eco.js';
import { getOnePw } from './onepw.js';
import { safeReason, loadAudioSeen } from './safe.js';

const $ = (id) => document.getElementById(id);
const gb = (bytes) => num(bytes / 1073741824, 1);

/* ---------- Performances du système (lues uniquement popup ouverte) ---------- */

let prevCpu = null;

function setGauge(id, pct, sub) {
  const ring = $(id + 'Ring');
  ring.style.strokeDasharray = `${pct} 100`;
  ring.classList.toggle('warn', pct >= 70 && pct < 90);
  ring.classList.toggle('hot', pct >= 90);
  $(id + 'Pct').textContent = pct + ' %';
  if (sub !== undefined) $(id + 'Sub').textContent = sub;
}

async function readMemory() {
  const m = await chrome.system.memory.getInfo();
  const used = m.capacity - m.availableCapacity;
  setGauge('mem', Math.round((used / m.capacity) * 100), `${gb(used)} / ${gb(m.capacity)} ${t('p.gb')}`);
}

async function readCpu() {
  const info = await chrome.system.cpu.getInfo();
  const total = info.processors.reduce((a, p) => ({ idle: a.idle + p.usage.idle, total: a.total + p.usage.total }), { idle: 0, total: 0 });
  if (prevCpu && total.total > prevCpu.total) {
    setGauge('cpu', Math.round((1 - (total.idle - prevCpu.idle) / (total.total - prevCpu.total)) * 100), tn('p.cores', info.numOfProcessors));
  }
  prevCpu = total;
}

function tick() { readMemory().catch(() => {}); readCpu().catch(() => {}); }

/* ---------- Onglets ---------- */

async function refreshTabs() {
  const [settings, tabs] = await Promise.all([getSettings(), chrome.tabs.query({})]);
  const model = settings.algorithm === 'pulsa' ? await loadModel() : null;
  const plan = analyze(tabs, settings, Date.now(), model, await getContext(settings));
  $('open').textContent = tabs.length;
  $('sleeping').textContent = tabs.filter((t) => t.discarded).length;
  $('todo').textContent = plan.sleep.length + plan.close.length;
  const dup = settings.duplicates === 'off' ? t('p.dupOff') : tn('n.dup', plan.close.length);
  $('hint').textContent = settings.algorithm === 'pulsa'
    ? tn('p.hintPulsa', plan.sleep.length, { dup })
    : tn('p.hintClassic', plan.sleep.length, { dup, min: settings.idleMinutes });
}

/* ---------- BSWP on/off ---------- */

async function showBswp(s) {
  $('bswpOn').checked = s.bswp;
  const hint = $('bswpHint');
  if (!s.bswp) { hint.textContent = t('p.bswpOff'); return; }
  hint.textContent = t('p.bswpOn');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const r = await chrome.tabs.sendMessage(tab.id, { type: 'bswp-stats' });
    const n = r.img + r.frame + r.video;
    hint.textContent = n ? t('p.bswpPage', { img: tn('n.img', r.img), frame: tn('n.frame', r.frame), video: tn('n.video', r.video) }) : t('p.bswpNone');
  } catch { /* page interne, ou page ouverte avant l'activation : rechargez-la */ }
}

$('bswpOn').addEventListener('change', async (e) => {
  const on = e.target.checked;
  if (on) {   // Chrome demande l'accès aux sites à ce moment seulement (geste de l'utilisateur)
    const ok = await chrome.permissions.request({ origins: ['http://*/*', 'https://*/*'] });
    if (!ok) { e.target.checked = false; return; }
  } else {
    await chrome.permissions.remove({ origins: ['http://*/*', 'https://*/*'] }).catch(() => {});
  }
  const s = await saveSettings({ bswp: on });
  await showBswp(s);
  if (on) $('bswpHint').textContent += t('p.bswpReload');
});

/* ---------- Safe on/off : appels et son jamais mis en veille ---------- */

async function showSafe(s) {
  $('safeOn').checked = s.safe;
  if (!s.safe) { $('safeHint').textContent = t('p.safeOff'); return; }
  const [seen, tabs] = await Promise.all([loadAudioSeen(), chrome.tabs.query({})]);
  const n = tabs.filter((x) => !x.discarded && safeReason(x, seen)).length;
  $('safeHint').textContent = t('p.safeOn', { n });
}

$('safeOn').addEventListener('change', async (e) => {
  await showSafe(await saveSettings({ safe: e.target.checked }));
  refreshTabs();
});

/* ---------- 1PW (bêta) on/off : l'action est menée par le service worker ---------- */

async function showOnePw() {
  const st = await getOnePw();
  $('opwOn').checked = !!st;
  if (!st) { $('opwHint').textContent = t('p.opwOff'); return; }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const n = (await chrome.tabs.query({})).filter((x) => x.discarded).length;
  $('opwHint').textContent = t(tab && tab.id === st.tabId ? 'p.opwOn' : 'p.opwElse', { n });
}

$('opwOn').addEventListener('change', async (e) => {
  try {
    if (e.target.checked) {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const r = tab ? await chrome.runtime.sendMessage({ type: '1pw', on: true, tabId: tab.id }) : null;
      if (!r || !r.ok) { e.target.checked = false; $('opwHint').textContent = t('p.opwPage'); return; }
    } else {
      await chrome.runtime.sendMessage({ type: '1pw', on: false });
    }
  } catch { e.target.checked = !e.target.checked; return; }
  await Promise.all([showOnePw(), refreshTabs()]);
  setTimeout(tick, 1200);
});

/* ---------- PULSA on/off ---------- */

function showPulsa(s) {
  $('pulsaOn').checked = s.algorithm === 'pulsa';
  $('pulsaHint').textContent = s.algorithm === 'pulsa' ? t('p.pulsaOn') : t('p.pulsaOff', { min: s.idleMinutes });
}

async function showUpdate() {
  const [s, u] = await Promise.all([getSettings(), getUpdateInfo()]);
  const b = $('updBanner');
  const cur = chrome.runtime.getManifest().version;
  const show = s.updateCheck && u && (u.status === 'store' || (u.status === 'available' && isNewer(u.latest, cur)));
  b.hidden = !show;
  if (!show) return;
  if (u.status === 'store') {
    b.textContent = t('p.updReady');
    b.href = '#';
    b.onclick = (e) => { e.preventDefault(); chrome.runtime.reload(); };
  } else {
    b.textContent = t('p.updAvail', { latest: u.label || u.latest, cur: currentLabel() });
    b.href = u.page || PAGE_URL; b.onclick = null;
  }
}

async function refreshTotals() {
  const st = await getStats();
  $('totals').textContent = st.runs
    ? t('p.totals', { a: tn('n.slept', st.slept), b: tn('n.closed', st.closed) })
    : t('p.totalsNone');
}

async function refreshProtect() {
  const btn = $('protect');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const host = tab && /^https?:/i.test(tab.url || '') ? hostOf(tab.url) : '';
  if (!host) { btn.disabled = true; btn.textContent = t('p.protect'); return; }
  const settings = await getSettings();
  const on = isProtectedSite(tab.url, settings.protectedSites);
  btn.disabled = false;
  btn.dataset.host = host;
  btn.dataset.on = on ? '1' : '';
  btn.textContent = on ? t('p.unprotectHost', { host }) : t('p.protectHost', { host });
  btn.title = btn.textContent;
}

/* ---------- Actions ---------- */

$('run').addEventListener('click', async () => {
  const btn = $('run');
  btn.disabled = true; btn.textContent = t('p.running'); $('result').textContent = '';
  try {
    const { slept, closed } = await optimize({ manual: true });
    $('result').textContent = slept || closed
      ? t('p.result', { a: tn('n.slept', slept), b: tn('n.closed', closed) })
      : t('p.nothing');
  } catch {
    $('result').textContent = t('p.failed');
  }
  btn.disabled = false; btn.textContent = t('p.run');
  await Promise.all([refreshTabs(), refreshTotals()]);
  setTimeout(tick, 1200);
});

$('pulsaOn').addEventListener('change', async (e) => {
  const s = await saveSettings({ algorithm: e.target.checked ? 'pulsa' : 'classic' });
  showPulsa(s);
  await refreshTabs();
});

$('auto').addEventListener('change', async (e) => {
  await saveSettings({ mode: e.target.checked ? 'auto' : 'manual' });
});

$('protect').addEventListener('click', async () => {
  const btn = $('protect'), host = btn.dataset.host;
  if (!host) return;
  const s = await getSettings();
  const list = btn.dataset.on ? s.protectedSites.filter((d) => host !== d && !host.endsWith('.' + d)) : [...new Set([...s.protectedSites, host])];
  await saveSettings({ protectedSites: list });
  await Promise.all([refreshProtect(), refreshTabs()]);
});

$('openOptions').addEventListener('click', () => chrome.runtime.openOptionsPage());

/* ---------- EcoOptimizer : message quand la batterie ralentit l'extension ---------- */

async function showEco() {
  const box = $('ecoMsg');
  box.hidden = true;
  try {
    const s = await getSettings();
    if (!s.ecoOptimizer) return;
    const b = await navigator.getBattery();
    const level = Math.round(b.level * 100), p = ecoProfile(level, b.charging);
    if (!p.slow) return;
    $('ecoMsgText').textContent = t('eco.popup', { level, slow: Math.round(p.slow * 100) }) + (p.shed ? ' ' + t('eco.shed' + p.shed) : '');
    box.hidden = false;
  } catch { /* batterie indisponible */ }
}

/* ---------- Démarrage ---------- */

async function renderAll() {
  const s = await getSettings();
  showPulsa(s);
  showBswp(s);
  showOnePw();
  showSafe(s);
  await Promise.all([refreshTabs(), refreshTotals(), refreshProtect(), showUpdate(), showEco()]);
  tick();
}

(async () => {
  await initLang();
  mountLangSwitcher($('langHost'), renderAll);
  const s = await getSettings();
  $('auto').checked = s.mode === 'auto';
  await renderAll();
  setInterval(tick, 1500);   // s'arrête avec la fermeture du popup
})();
