// 1PW (One Page Web), bêta : concentre le navigateur sur un seul onglet (un jeu qui rame, par exemple).
// Les autres onglets sont mis en veille (tabs.discard) pour libérer mémoire et processeur.
// Chrome ne permet pas d'attribuer plus de puissance à un onglet : on ne fait que retirer de la charge ailleurs.
// Rien ne tourne en continu : l'état est gardé en session, et le service worker n'agit que sur
// quelques événements (activation, fermeture de l'onglet, fin de chargement d'un autre onglet).
import { getSettings, isProtectedSite } from './lib.js';
import { getUpdateInfo } from './update.js';

const KEY = 'onePw';

export async function getOnePw() {
  const { onePw } = await chrome.storage.session.get(KEY);
  return onePw || null;
}

// Un onglet peut être mis en veille s'il n'est pas le jeu, pas visible, pas épinglé, sans son, pas protégé.
export function eligible(t, st, settings) {
  if (!st || t.id === st.tabId || t.discarded || t.active || t.pinned || t.audible) return false;
  if (t.autoDiscardable === false || !/^https?:/i.test(t.url || '')) return false;
  if (isProtectedSite(t.url, settings.protectedSites)) return false;
  if (settings.onePwWindowOnly && t.windowId !== st.windowId) return false;
  return true;
}

export async function refreshBadge() {
  if (await getOnePw()) {
    chrome.action.setBadgeText({ text: '1PW' });
    chrome.action.setBadgeBackgroundColor({ color: '#1a9d5a' });
    return;
  }
  const u = await getUpdateInfo();
  const up = u && (u.status === 'store' || u.status === 'available');
  chrome.action.setBadgeText({ text: up ? '↑' : '' });
  if (up) chrome.action.setBadgeBackgroundColor({ color: '#2f6fed' });
}

export async function sweep() {
  const st = await getOnePw();
  if (!st) return 0;
  const settings = await getSettings();
  const tabs = await chrome.tabs.query({});
  let n = 0;
  for (const t of tabs) {
    if (t.status === 'loading' || !eligible(t, st, settings)) continue;   // les pages en chargement passent par onUpdated
    try { if (await chrome.tabs.discard(t.id)) n++; } catch { /* onglet fermé ou non éligible */ }
  }
  return n;
}

// Un autre onglet vient de finir de charger : on l'endort s'il est en arrière-plan.
export async function discardIfEligible(tab) {
  const st = await getOnePw();
  if (!st) return;
  if (!eligible(tab, st, await getSettings())) return;
  try { await chrome.tabs.discard(tab.id); } catch { /* ignoré */ }
}

export async function startOnePw(tabId) {
  let tab;
  try { tab = await chrome.tabs.get(tabId); } catch { return { ok: false, reason: 'tab' }; }
  if (!/^https?:/i.test(tab.url || '')) return { ok: false, reason: 'page' };
  await chrome.storage.session.set({ [KEY]: { tabId, windowId: tab.windowId, since: Date.now() } });
  await refreshBadge();
  return { ok: true, n: await sweep() };
}

export async function stopOnePw() {
  await chrome.storage.session.remove(KEY);
  await refreshBadge();
}
