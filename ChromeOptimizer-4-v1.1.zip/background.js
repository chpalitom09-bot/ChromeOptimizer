// Service worker : il ne fait rien tant que Chrome ne le réveille pas.
// Mode automatique : une alarme à la fois, dont le délai s'allonge (1, 2, 5, 10 min)
// tant qu'il n'y a rien à faire, et repart à 1 min dès qu'un onglet change.
// Mode manuel : aucune alarme.
import { getSettings, saveSettings, optimize } from './lib.js';
import { trackActivated, trackRemoved, seedActive } from './pulsa-store.js';
import { CYCLE_STEPS, nextStage } from './pulsa.js';
import { checkForUpdate, clearBadgeIfCurrent } from './update.js';
import { getEco, ECO_NONE } from './eco.js';
import { getOnePw, startOnePw, stopOnePw, discardIfEligible, refreshBadge } from './onepw.js';

const ALARM = 'chromeoptimizer-cycle';
const BSWP_ID = 'bswp';

// BSWP : le script n'est enregistré que si l'interrupteur est actif ET que Chrome a accordé l'accès.
async function syncBswp() {
  const { bswp: wanted, ecoOptimizer } = await getSettings();
  const bswp = wanted && !(ecoOptimizer && (await getEco()).shed >= 2);   // EcoOptimizer : BSWP en pause sous 10 %
  const registered = (await chrome.scripting.getRegisteredContentScripts({ ids: [BSWP_ID] })).length > 0;
  const granted = await chrome.permissions.contains({ origins: ['http://*/*', 'https://*/*'] });
  if (bswp && granted && !registered) {
    await chrome.scripting.registerContentScripts([{ id: BSWP_ID, matches: ['http://*/*', 'https://*/*'], js: ['bswp.js'], runAt: 'document_idle', persistAcrossSessions: true }]);
  } else if ((!bswp || !granted) && registered) {
    await chrome.scripting.unregisterContentScripts({ ids: [BSWP_ID] });
  }
}

// EcoOptimizer : un document invisible lit la batterie (impossible depuis un service worker).
async function syncEco() {
  const { ecoOptimizer } = await getSettings();
  const has = (await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] })).length > 0;
  if (ecoOptimizer && !has) {
    await chrome.offscreen.createDocument({ url: 'offscreen.html', reasons: ['BATTERY_STATUS'], justification: 'Lire le niveau de batterie pour ralentir les cycles quand elle est faible.' });
  } else if (!ecoOptimizer) {
    if (has) await chrome.offscreen.closeDocument();
    await chrome.storage.session.remove('eco');
    await syncBswp();
  }
}

// Le palier de batterie change : on le garde, il s'applique au prochain cycle.
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (sender.id !== chrome.runtime.id || !msg || msg.type !== 'eco-battery') return;
  (async () => {
    const { ecoOptimizer } = await getSettings();
    if (!ecoOptimizer) return;
    const before = await getEco();
    const eco = { level: Number(msg.level) || 0, charging: !!msg.charging, slow: Number(msg.slow) || 0, shed: Number(msg.shed) || 0 };
    await chrome.storage.session.set({ eco });
    if ((await getEco()).shed !== before.shed) await syncBswp();
  })().catch(() => {});
});

const UPDATE_ALARM = 'chromeoptimizer-update';

// Une alarme par jour, indépendante du mode : elle ne fait qu'un GET vers GitHub.
async function syncUpdateAlarm() {
  const { updateCheck } = await getSettings();
  if (!updateCheck) { await chrome.alarms.clear(UPDATE_ALARM); return; }
  if (!(await chrome.alarms.get(UPDATE_ALARM))) await chrome.alarms.create(UPDATE_ALARM, { delayInMinutes: 1, periodInMinutes: 1440 });
}

async function getStage() {
  const { cycleStage } = await chrome.storage.session.get('cycleStage');
  return cycleStage || 0;
}

async function schedule(stage) {
  const s = await getSettings();
  if (s.mode !== 'auto') { await chrome.alarms.clear(ALARM); return; }
  const base = s.adaptiveInterval ? CYCLE_STEPS[stage] : CYCLE_STEPS[0];
  const eco = s.ecoOptimizer ? await getEco() : ECO_NONE;
  // EcoOptimizer : cycle plus lent selon la batterie (Chrome n'accepte pas moins de 30 s).
  await chrome.alarms.create(ALARM, { delayInMinutes: Math.max(0.5, base * (1 + eco.slow)) });
  await chrome.storage.session.set({ cycleStage: s.adaptiveInterval ? stage : 0 });
}

async function syncAlarm() {
  const { mode } = await getSettings();
  if (mode !== 'auto') { await chrome.alarms.clear(ALARM); return; }
  if (!(await chrome.alarms.get(ALARM))) await schedule(0);
}

// Un onglet créé, fermé ou activé change la donne : on revient à un cycle par minute.
async function wake() {
  if ((await getStage()) > 0) await schedule(0);
}

chrome.runtime.onInstalled.addListener(() => { syncEco().catch(() => {}); syncAlarm(); syncUpdateAlarm(); syncBswp().catch(() => {}); seedActive(); clearBadgeIfCurrent(); refreshBadge(); });
chrome.runtime.onStartup.addListener(() => { syncEco().catch(() => {}); syncAlarm(); syncUpdateAlarm(); syncBswp().catch(() => {}); seedActive(); refreshBadge(); });

// Apprentissage PULSA : un événement par changement d'onglet, rien en continu.
chrome.tabs.onActivated.addListener((info) => { trackActivated(info); wake(); });
chrome.tabs.onRemoved.addListener((id) => { trackRemoved(id); wake(); });
chrome.tabs.onCreated.addListener(wake);

// 1PW (bêta) : l'état vit en session ; le panneau et le raccourci passent par ces quelques événements.
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (sender.id !== chrome.runtime.id || !msg || msg.type !== '1pw') return;
  (async () => {
    if (msg.on) reply(await startOnePw(msg.tabId));
    else { await stopOnePw(); reply({ ok: true }); }
  })().catch(() => reply({ ok: false }));
  return true;
});
chrome.tabs.onRemoved.addListener(async (id) => {
  const st = await getOnePw();
  if (st && st.tabId === id) await stopOnePw();   // l'onglet du jeu est fermé : fin du mode
});
chrome.tabs.onUpdated.addListener((id, info, tab) => {
  if (info.status === 'complete') discardIfEligible(tab).catch(() => {});
});

chrome.permissions.onRemoved.addListener(() => syncBswp().catch(() => {}));

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !changes.settings) return;
  const a = changes.settings.oldValue || {}, b = changes.settings.newValue || {};
  if (a.updateCheck !== b.updateCheck) syncUpdateAlarm();
  if (a.bswp !== b.bswp) syncBswp().catch(() => {});
  if (!!a.ecoOptimizer !== !!b.ecoOptimizer) syncEco().catch(() => {});
  if (a.adaptiveInterval !== b.adaptiveInterval) schedule(0); else syncAlarm();
});

// Raccourci clavier : activer ou désactiver PULSA (modifiable dans chrome://extensions/shortcuts).
chrome.commands.onCommand.addListener(async (cmd) => {
  if (cmd === 'optimize-now') { optimize({ manual: true }); return; }
  if (cmd === 'toggle-1pw') {
    if (await getOnePw()) { await stopOnePw(); return; }
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (tab) await startOnePw(tab.id);
    return;
  }
  if (cmd !== 'toggle-pulsa') return;
  const { algorithm } = await getSettings();
  await saveSettings({ algorithm: algorithm === 'pulsa' ? 'classic' : 'pulsa' });
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === UPDATE_ALARM) { checkForUpdate().catch(() => {}); return; }
  if (alarm.name !== ALARM) return;
  let stage = await getStage();
  try {
    const { slept, closed } = await optimize();
    stage = nextStage(stage, slept + closed > 0);
  } finally {
    await schedule(stage);
  }
});
