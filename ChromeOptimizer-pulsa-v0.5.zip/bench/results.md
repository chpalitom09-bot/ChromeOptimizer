
PULSA — banc d'essai synthétique (20 semaines simulées × 40 onglets, 5 jours)

| Stratégie | Économie vs oracle | Rechargements/sem. | Faux positifs (<1 h)/sem. | Précision des mises en veille | Brier P(<1 h) |
|---|---|---|---|---|---|
| Aucune optimisation | 0 % | 0.0 | 0.0 | — | — |
| Délai 30 min | 98 % | 623.1 | 461.1 | 29 % | — |
| Délai 1 h | 90 % | 255.4 | 126.8 | 54 % | — |
| Délai 1.5 h | 85 % | 160.7 | 46.0 | 74 % | — |
| Délai 2 h | 82 % | 128.0 | 22.3 | 85 % | — |
| Délai 3 h | 77 % | 105.5 | 9.5 | 92 % | — |
| Plafond 20 onglets | 35 % | 32.5 | 8.3 | 80 % | — |
| PULSA prudent (seuil 15) | 81 % | 121.8 | 19.2 | 86 % | 0.087 |
| PULSA seuil 20 | 83 % | 131.4 | 25.0 | 83 % | 0.087 |
| PULSA équilibré (seuil 30) | 85 % | 152.2 | 38.6 | 77 % | 0.087 |
| PULSA agressif (seuil 50) | 90 % | 202.8 | 74.1 | 67 % | 0.088 |
| PULSA équilibré + réglage auto | 85 % | 147.5 | 36.4 | 78 % | 0.087 |
| PULSA équilibré + mémoire | 82 % | 130.1 | 24.3 | 84 % | 0.087 |
| PULSA équilibré + mémoire + réglage auto | 82 % | 129.1 | 23.6 | 84 % | 0.086 |
| PULSA agressif + mémoire + réglage auto | 84 % | 149.2 | 36.8 | 78 % | 0.087 |
