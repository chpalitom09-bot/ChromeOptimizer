// Historique des sites visités : noms de domaine, nombre de visites, dernière visite.
// Jamais d'adresse complète ni de titre. Stocké uniquement dans chrome.storage.local.
// Désactivable et effaçable depuis les réglages.
const PREFIX = 'h:';
const MAX_SITES = 150;

export async function historyEnabled() {
  const { settings } = await chrome.storage.local.get('settings');
  return !settings || settings.history !== false;
}

export async function recordVisit(host, now = Date.now()) {
  if (!host || !(await historyEnabled())) return;
  const key = PREFIX + host;
  const cur = (await chrome.storage.local.get(key))[key] || { n: 0, first: now, last: now };
  cur.n++; cur.last = now;
  await chrome.storage.local.set({ [key]: cur });
  if (cur.n === 1) await pruneHistory();   // nouveau site : on vérifie la taille de la liste
}

export async function loadHistory() {
  const all = await chrome.storage.local.get(null);
  return Object.entries(all)
    .filter(([k]) => k.startsWith(PREFIX))
    .map(([k, v]) => ({ host: k.slice(PREFIX.length), n: v.n, last: v.last }))
    .sort((a, b) => b.last - a.last);
}

export async function clearHistory() {
  const all = await chrome.storage.local.get(null);
  const keys = Object.keys(all).filter((k) => k.startsWith(PREFIX));
  if (keys.length) await chrome.storage.local.remove(keys);
}

// Garde les sites les plus récents quand la liste devient trop longue.
export async function pruneHistory() {
  const list = await loadHistory();
  if (list.length <= MAX_SITES) return;
  await chrome.storage.local.remove(list.slice(MAX_SITES - 20).map((x) => PREFIX + x.host));
}
