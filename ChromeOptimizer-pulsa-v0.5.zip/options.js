import { getSettings, saveSettings, getStats, resetStats, normalizeSites, MIN_IDLE, loadTune } from './lib.js';
import { tuneFactor } from './pulsa.js';
import { modelSize, resetModel } from './pulsa-store.js';
import { loadHistory, clearHistory } from './history.js';
import { checkForUpdate, getUpdateInfo, isNewer } from './update.js';

const $ = (id) => document.getElementById(id);
const plural = (n, one, many) => `${n} ${n > 1 ? many : one}`;
let toastTimer;

function toast() {
  const t = $('toast');
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 1400);
}

async function showStats() {
  const st = await getStats();
  $('stats').textContent = st.runs
    ? `${plural(st.slept, 'onglet mis en veille', 'onglets mis en veille')} et ${plural(st.closed, 'doublon fermé', 'doublons fermés')} depuis le début.`
    : 'Aucune optimisation pour le moment.';
}

async function showModel() {
  const { hosts, intervals } = await modelSize();
  $('pulsaInfo').textContent = hosts
    ? `PULSA connaît vos habitudes sur ${hosts} domaine${hosts > 1 ? 's' : ''} (${intervals} retours observés).`
    : "PULSA n'a encore rien appris : il utilise une estimation prudente par défaut.";
  const t = await loadTune();
  const f = tuneFactor(t);
  if (t.n >= 5 && Math.abs(f - 1) > 0.02) {
    $('pulsaInfo').textContent += ` Réglage automatique : seuil ×${f.toFixed(2).replace('.', ',')} (${f < 1 ? 'plus prudent' : 'plus ferme'}).`;
  }
}

async function showHist() {
  const n = (await loadHistory()).length;
  $('histInfo').textContent = n ? `${plural(n, 'site gardé', 'sites gardés')} dans l'historique.` : "L'historique est vide.";
}

async function showUpd() {
  const u = await getUpdateInfo(), cur = chrome.runtime.getManifest().version;
  $('updInfo').textContent = !u ? `Version installée : ${cur}. Pas encore vérifié.`
    : u.status === 'store' ? 'Une mise à jour est prête : rechargez l\'extension.'
    : u.status === 'available' && isNewer(u.latest, cur) ? `Version ${u.latest} disponible (installée : ${cur}).`
    : u.status === 'current' ? `À jour (version ${cur}).`
    : `Vérification impossible pour le moment (version installée : ${cur}).`;
}

function syncPulsaBox(algo) { $('pulsaBox').style.display = algo === 'pulsa' ? '' : 'none'; }

async function init() {
  $('ver').textContent = chrome.runtime.getManifest().version;
  const s = await getSettings();
  document.querySelector(`input[name=mode][value=${s.mode}]`).checked = true;
  $('idle').value = s.idleMinutes;
  $('algo').value = s.algorithm;
  $('hist').value = s.history ? 'on' : 'off';
  $('adMem').value = s.adaptMemory ? 'on' : 'off';
  $('adTune').value = s.autoTune ? 'on' : 'off';
  $('adInt').value = s.adaptiveInterval ? 'on' : 'off';
  await showHist();
  $('upd').value = s.updateCheck ? 'on' : 'off';
  await showUpd();
  $('sens').value = s.sensitivity;
  syncPulsaBox(s.algorithm);
  await showModel();
  $('dups').value = s.duplicates;
  $('sites').value = s.protectedSites.join('\n');
  await showStats();
}

document.querySelectorAll('input[name=mode]').forEach((r) =>
  r.addEventListener('change', async () => { await saveSettings({ mode: r.value }); toast(); }));

$('idle').addEventListener('change', async () => {
  const v = Math.min(1440, Math.max(MIN_IDLE, Math.round(Number($('idle').value) || 30)));
  $('idle').value = v;
  await saveSettings({ idleMinutes: v });
  toast();
});

$('algo').addEventListener('change', async () => { await saveSettings({ algorithm: $('algo').value }); syncPulsaBox($('algo').value); toast(); });
$('sens').addEventListener('change', async () => { await saveSettings({ sensitivity: $('sens').value }); toast(); });
$('resetModel').addEventListener('click', async () => { await resetModel(); await showModel(); toast(); });

$('adMem').addEventListener('change', async () => { await saveSettings({ adaptMemory: $('adMem').value === 'on' }); toast(); });
$('adTune').addEventListener('change', async () => { await saveSettings({ autoTune: $('adTune').value === 'on' }); toast(); });
$('adInt').addEventListener('change', async () => { await saveSettings({ adaptiveInterval: $('adInt').value === 'on' }); toast(); });

$('upd').addEventListener('change', async () => { await saveSettings({ updateCheck: $('upd').value === 'on' }); toast(); });
$('updNow').addEventListener('click', async () => {
  $('updNow').disabled = true; $('updInfo').textContent = 'Vérification…';
  await checkForUpdate({ force: true }); await showUpd(); $('updNow').disabled = false;
});

$('hist').addEventListener('change', async () => { await saveSettings({ history: $('hist').value === 'on' }); toast(); });
$('clearHist').addEventListener('click', async () => { await clearHistory(); await showHist(); toast(); });

$('dups').addEventListener('change', async () => { await saveSettings({ duplicates: $('dups').value }); toast(); });

$('sites').addEventListener('change', async () => {
  const list = normalizeSites($('sites').value);
  $('sites').value = list.join('\n');
  await saveSettings({ protectedSites: list });
  toast();
});

$('reset').addEventListener('click', async () => { await resetStats(); await showStats(); toast(); });

init();
