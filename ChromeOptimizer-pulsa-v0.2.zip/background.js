// Service worker : il ne fait rien tant que Chrome ne le réveille pas.
// Mode automatique : une seule alarme par minute. Mode manuel : aucune alarme.
import { getSettings, optimize } from './lib.js';
import { trackActivated, trackRemoved, seedActive } from './pulsa-store.js';

const ALARM = 'chromeoptimizer-cycle';

async function syncAlarm() {
  const { mode } = await getSettings();
  if (mode === 'auto') {
    if (!(await chrome.alarms.get(ALARM))) chrome.alarms.create(ALARM, { delayInMinutes: 1, periodInMinutes: 1 });
  } else {
    chrome.alarms.clear(ALARM);
  }
}

chrome.runtime.onInstalled.addListener(() => { syncAlarm(); seedActive(); });
chrome.runtime.onStartup.addListener(() => { syncAlarm(); seedActive(); });

// Apprentissage PULSA : un événement par changement d'onglet, rien en continu.
chrome.tabs.onActivated.addListener(trackActivated);
chrome.tabs.onRemoved.addListener(trackRemoved);
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.settings) syncAlarm();
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM) optimize();
});
