# Banc d'essai PULSA

    node bench/simulate.mjs

Rejoue 20 semaines d'usage **synthétiques** (40 onglets : périodiques, en rafale,
quotidiens, épars, jetables) et compare PULSA à des délais fixes.
Même code `pulsa.js` que l'extension.

Métriques : économie de mémoire relative à un oracle, rechargements,
faux positifs (retour < 1 h après la veille), précision, score de Brier de P(retour < 1 h).

Limite : ces résultats valident la mécanique, pas l'efficacité réelle.
Il faut des traces d'usage réelles (extension de collecte) pour conclure.
