// Banc d'essai PULSA : rejoue des journées d'onglets SYNTHÉTIQUES et compare
// PULSA à des stratégies simples. Lancer : node bench/simulate.mjs
// ATTENTION : données simulées. Les chiffres valident la mécanique et montrent
// des ordres de grandeur ; ils ne remplacent pas une mesure sur de vrais usages.
import {
  PULSA_DEFAULTS, SENSITIVITY, emptyRecord, recordReturn, recordCensored,
  recordSleepOutcome, pulsaScore, reuseProbability
} from '../pulsa.js';

/* ---------- RNG déterministe ---------- */
function rng(seed) { let s = seed >>> 0; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); }
const logn = (r, med, sigma) => { const u = Math.sqrt(-2 * Math.log(r() + 1e-12)) * Math.cos(2 * Math.PI * r()); return med * Math.exp(sigma * u); };
const expo = (r, mean) => -mean * Math.log(r() + 1e-12);

/* ---------- Génération d'une semaine d'usage ---------- */
const DAYS = 5, MIN_DAY = 1440, TOTAL = DAYS * MIN_DAY;
const awake = (t) => { const h = (t % MIN_DAY) / 60; return h >= 8 && h < 23.5; };

function makeTabs(r, n = 40) {
  const types = ['periodic', 'periodic', 'burst', 'burst', 'burst', 'daily', 'sparse', 'oneshot', 'oneshot', 'oneshot'];
  const tabs = [];
  for (let i = 0; i < n; i++) {
    const type = types[Math.floor(r() * types.length)];
    const host = type + '-' + (i % 24);
    const visits = [];
    let t = 480 + r() * 600; // première visite dans la 1re journée
    const mem = 60 + r() * 340; // MB
    if (type === 'periodic') {
      const med = 15 + r() * 40;
      while (t < TOTAL) { if (awake(t)) visits.push(t); t += logn(r, med, 0.5); }
    } else if (type === 'burst') {
      let rate = 8 + r() * 10, decay = 1.6 + r() * 0.6; // intervalles qui s'allongent
      while (t < TOTAL && rate < 3000) { if (awake(t)) visits.push(t); t += expo(r, rate); rate *= decay; }
    } else if (type === 'daily') {
      while (t < TOTAL) { visits.push(t); t += MIN_DAY + (r() - 0.5) * 120; }
    } else if (type === 'sparse') {
      while (t < TOTAL) { if (awake(t)) visits.push(t); t += expo(r, 180 + r() * 120); }
    } else { // oneshot : 1 à 2 visites puis abandon
      visits.push(t); if (r() < 0.4) visits.push(t + expo(r, 10));
    }
    visits.sort((a, b) => a - b);
    const dedup = visits.filter((v, i) => i === 0 || v - visits[i - 1] >= 1);
    tabs.push({ host, visits: dedup, mem, type });
  }
  return tabs;
}

/* ---------- Politiques ---------- */
const classic = (idleMin) => ({ name: `Délai ${idleMin >= 60 ? idleMin / 60 + ' h' : idleMin + ' min'}`, decide: (t) => t.idle >= idleMin });
const none = { name: 'Aucune optimisation', decide: () => false };
const maxTabs = (cap) => ({
  name: `Plafond ${cap} onglets`,
  decideAll: (tabs) => { // endort les plus anciens inutilisés au-delà du plafond (≥ 5 min d'inactivité)
    const live = tabs.filter((t) => !t.asleep).sort((a, b) => a.idle - b.idle);
    return new Set(live.slice(cap).filter((t) => t.idle >= 5).map((t) => t.id));
  }
});
function pulsa(label, { floor = 5, sens = 'balanced', cfg = PULSA_DEFAULTS } = {}) {
  return { name: `PULSA ${label}`, pulsa: true, floor, sens, cfg };
}

/* ---------- Simulation ---------- */
function run(tabsSpec, policy) {
  const cfg = policy.cfg || PULSA_DEFAULTS;
  const hosts = new Map(); let glob = emptyRecord();
  const rec = (h) => { if (!hosts.has(h)) hosts.set(h, emptyRecord()); return hosts.get(h); };
  const st = tabsSpec.map((s, id) => ({ id, host: s.host, mem: s.mem, v: s.visits, vi: 0, last: s.visits[0] ?? Infinity,
    asleep: false, sleptAt: 0, idle: 0, opened: false, closedAt: s.type === 'oneshot' ? s.visits[s.visits.length - 1] + 30 + Math.random() * 0 : Infinity }));
  let saved = 0, discards = 0, restores = 0, fps = 0, goodDiscards = 0, brierSum = 0, brierN = 0;
  const wake = { };

  for (let t = 0; t < TOTAL; t++) {
    // 1) visites à cet instant
    for (const x of st) {
      while (x.vi < x.v.length && x.v[x.vi] <= t) {
        const prevLeave = x.opened ? x.last : null;
        if (prevLeave !== null) {
          const gap = x.v[x.vi] - prevLeave;
          if (policy.pulsa) { recordReturn(rec(x.host), gap, t, cfg); recordReturn(glob, gap, t, cfg); }
        }
        if (x.asleep) {
          restores++;
          const asleepFor = t - x.sleptAt;
          if (asleepFor < cfg.fpWindowMin) fps++; else goodDiscards++;
          if (policy.pulsa) { recordSleepOutcome(rec(x.host), asleepFor, t, cfg); recordSleepOutcome(glob, asleepFor, t, cfg); }
          x.asleep = false;
        }
        x.opened = true; x.last = x.v[x.vi] + 1; x.vi++;
      }
    }
    // 2) fermeture des onglets « one-shot » (censure)
    for (const x of st) {
      if (x.opened && t === Math.round(x.closedAt) && x.closedAt < Infinity) {
        if (policy.pulsa) { recordCensored(rec(x.host), t - x.last, t, cfg); recordCensored(glob, t - x.last, t, cfg); }
        if (x.asleep) goodDiscards++;
        x.dead = true; x.asleep = false;
      }
    }
    // 3) décisions (un cycle par minute, comme l'extension)
    const live = st.filter((x) => x.opened && !x.dead);
    live.forEach((x) => { x.idle = t - x.last; });
    let toSleep = new Set();
    if (policy.decideAll) toSleep = policy.decideAll(live);
    else for (const x of live) {
      if (x.asleep) continue;
      if (policy.pulsa) {
        if (x.idle < policy.floor) continue;
        const { score } = pulsaScore(rec(x.host), glob, x.idle, cfg);
        if (score < (typeof policy.sens === 'number' ? policy.sens : SENSITIVITY[policy.sens])) toSleep.add(x.id);
      } else if (policy.decide(x)) toSleep.add(x.id);
    }
    for (const x of live) {
      if (!x.asleep && toSleep.has(x.id)) { x.asleep = true; x.sleptAt = t; discards++; }
      if (x.asleep) saved += x.mem / 60;           // Mo·heure économisés cette minute
    }
    // 4) calibration (PULSA) : tous les 10 min, P(retour <60 min) vs réalité
    if (policy.pulsa && t % 10 === 0) {
      for (const x of live) {
        if (x.idle < 5) continue;
        const p = reuseProbability(rec(x.host), glob, x.idle, 60, cfg);
        const next = x.v.find((v) => v > t);
        const hit = next !== undefined && next <= t + 60 && !(x.closedAt < next) ? 1 : 0;
        brierSum += (p - hit) ** 2; brierN++;
      }
    }
  }
  return { saved, discards, restores, fps, goodDiscards, brier: brierN ? brierSum / brierN : NaN };
}

// Oracle : endort chaque période d'absence ≥ 60 min dès 5 min d'inactivité.
function oracle(spec) {
  let s = 0;
  spec.forEach((x) => {
    const v = x.visits; if (!v.length) return;
    for (let i = 0; i < v.length; i++) {
      const end = i + 1 < v.length ? v[i + 1] : (x.type === 'oneshot' ? v[i] + 30 : TOTAL);
      const gap = end - v[i];
      if (gap >= 60) s += ((gap - 5) * x.mem) / 60;
    }
  });
  return s;
}

/* ---------- Expérience ---------- */
const policies = [
  none, classic(30), classic(60), classic(90), classic(120), classic(180), maxTabs(20),
  pulsa('prudent (seuil 15)', { sens: 'prudent' }),
  pulsa('seuil 20', { sens: 20 }),
  pulsa('équilibré (seuil 30)', { sens: 'balanced' }),
  pulsa('agressif (seuil 50)', { sens: 'aggressive' })
];
const SEEDS = 20;
const agg = policies.map(() => ({ saved: 0, discards: 0, restores: 0, fps: 0, good: 0, brier: 0, bn: 0, orc: 0 }));
for (let s = 1; s <= SEEDS; s++) {
  const r = rng(s * 7919);
  const spec = makeTabs(r);
  const orc = oracle(spec);
  policies.forEach((p, i) => {
    const o = run(spec, p);
    const a = agg[i];
    a.saved += o.saved; a.discards += o.discards; a.restores += o.restores; a.fps += o.fps; a.good += o.goodDiscards;
    if (!Number.isNaN(o.brier)) { a.brier += o.brier; a.bn++; }
    a.orc += orc;
  });
}
const f = (x, d = 0) => x.toFixed(d);
console.log(`\nPULSA — banc d'essai synthétique (${SEEDS} semaines simulées × 40 onglets, ${DAYS} jours)\n`);
console.log('| Stratégie | Économie vs oracle | Rechargements/sem. | Faux positifs (<1 h)/sem. | Précision des mises en veille | Brier P(<1 h) |');
console.log('|---|---|---|---|---|---|');
policies.forEach((p, i) => {
  const a = agg[i];
  const prec = a.discards ? 100 * (1 - a.fps / a.discards) : NaN;
  console.log(`| ${p.name} | ${f(100 * a.saved / a.orc)} % | ${f(a.restores / SEEDS, 1)} | ${f(a.fps / SEEDS, 1)} | ${Number.isNaN(prec) ? '—' : f(prec) + ' %'} | ${a.bn ? f(a.brier / a.bn, 3) : '—'} |`);
});
