// PULSA — Predictive Usage Scoring and Lifecycle Algorithm (v0.2)
//
// Module pur : aucune API Chrome, aucun effet de bord. Il est utilisé tel quel
// par l'extension ET par le simulateur (bench/simulate.mjs).
//
// Idée : estimer P(l'onglet sera réutilisé dans les H prochaines minutes | il est
// inactif depuis t minutes), puis en faire un score de 0 à 100.
//
//  1. A priori   : décroissance exponentielle  R(t) = exp(-λt), demi-vie réglable.
//                  Sert quand on ne sait encore rien (démarrage à froid).
//  2. Données    : intervalles de réutilisation observés (minutes entre le moment
//                  où l'on quitte un onglet et celui où l'on y revient).
//                  Les onglets fermés sans retour sont des observations CENSURÉES
//                  (stockées en négatif) : sans elles le modèle serait trop optimiste.
//  3. Estimation : probabilité conditionnelle empirique (type Kaplan-Meier) :
//                      p = (m + a·p0) / (k + a)
//                  k = poids des intervalles survivant au-delà de t,
//                  m = poids de ceux qui se terminent dans (t, t+H],
//                  p0 = a priori, a = nombre de pseudo-observations de l'a priori.
//                  Les poids décroissent avec l'âge (historique récent favorisé).
//                  Hiérarchie : a priori → profil global → profil du domaine.
//  4. Feedback   : chaque mise en veille suivie d'un retour rapide (faux positif)
//                  augmente la prudence pour ce domaine (oubli progressif, effet
//                  qui s'estompe avec l'inactivité : jamais de blocage définitif).
//
// Vie privée : seuls le nom de domaine et des durées sont utilisés. Jamais le
// contenu, ni le chemin, ni le titre des pages.

export const PULSA_DEFAULTS = {
  halfLifeMin: 45,     // demi-vie de l'a priori (minutes)
  priorWeight: 4,      // poids de l'a priori, en pseudo-observations
  recency: 0.92,       // poids multiplié par cette valeur à chaque intervalle plus ancien
  maxIntervals: 24,    // taille maximale de l'historique par domaine
  horizonMin: 60,      // horizon de décision (minutes)
  fpWindowMin: 60,     // retour avant ce délai après une mise en veille = faux positif
  fpStrength: 1.5,     // influence du taux de faux positifs sur la prudence
  fpCap: 0.6,          // prudence maximale ajoutée par les faux positifs
  fbDecay: 0.85        // facteur d'oubli du feedback à chaque nouvelle issue
};

// Seuil de score (0–100) en dessous duquel un onglet devient candidat à la veille.
export const SENSITIVITY = { prudent: 15, balanced: 30, aggressive: 50 };

export function emptyRecord() {
  return { iv: [], fp: 0, ok: 0, last: 0 };
}

// Intervalle positif : retour de l'utilisateur après `minutes` minutes.
export function recordReturn(rec, minutes, now = Date.now(), cfg = PULSA_DEFAULTS) {
  return push(rec, Math.max(0.1, minutes), now, cfg);
}

// Onglet fermé après `minutes` minutes d'inactivité sans être revenu : censure.
export function recordCensored(rec, minutes, now = Date.now(), cfg = PULSA_DEFAULTS) {
  return push(rec, -Math.max(0.1, minutes), now, cfg);
}

function push(rec, v, now, cfg) {
  rec.iv.push(Math.round(v * 10) / 10);
  if (rec.iv.length > cfg.maxIntervals) rec.iv.splice(0, rec.iv.length - cfg.maxIntervals);
  rec.last = now;
  return rec;
}

// Retour après mise en veille : faux positif si le retour est rapide.
export function recordSleepOutcome(rec, minutesAsleep, now = Date.now(), cfg = PULSA_DEFAULTS) {
  rec.fp *= cfg.fbDecay; rec.ok *= cfg.fbDecay;      // oubli progressif : le feedback ancien compte moins
  if (minutesAsleep < cfg.fpWindowMin) rec.fp++; else rec.ok++;
  rec.last = now;
  return rec;
}

// Mise en veille jamais regrettée (onglet fermé sans retour) : succès.
export function recordSleepKept(rec, now = Date.now(), cfg = PULSA_DEFAULTS) {
  rec.fp *= cfg.fbDecay; rec.ok *= cfg.fbDecay;
  rec.ok++;
  rec.last = now;
  return rec;
}

/* ---------- Estimation ---------- */

// A priori : probabilité de retour dans H minutes après t minutes d'inactivité.
// Défini pour H = 60 puis étendu par un risque constant sur l'horizon.
export function priorP(t, H, cfg = PULSA_DEFAULTS) {
  const p60 = Math.exp((-Math.LN2 * t) / cfg.halfLifeMin);
  return 1 - Math.pow(1 - p60, H / 60);
}

function empirical(iv, t, H, cfg) {
  let k = 0, m = 0;
  const n = iv.length;
  for (let i = 0; i < n; i++) {
    const w = Math.pow(cfg.recency, n - 1 - i);
    const x = iv[i];
    if (x > 0) {
      if (x > t) { k += w; if (x <= t + H) m += w; }
    } else if (-x >= t + H) {
      k += w;                      // censure : a survécu à toute la fenêtre
    }
  }
  return { k, m };
}

function shrink(iv, t, H, base, cfg) {
  const { k, m } = empirical(iv, t, H, cfg);
  return (m + cfg.priorWeight * base) / (k + cfg.priorWeight);
}

// P(retour dans H minutes | inactif depuis t minutes)
export function reuseProbability(rec, glob, t, H, cfg = PULSA_DEFAULTS) {
  const p0 = priorP(t, H, cfg);
  const pG = glob && glob.iv.length ? shrink(glob.iv, t, H, p0, cfg) : p0;
  let p = rec && rec.iv.length ? shrink(rec.iv, t, H, pG, cfg) : pG;
  if (rec) {
    const fpRate = rec.fp / (rec.fp + rec.ok + 3);
    // La prudence s'estompe avec l'inactivité : elle retarde la veille, elle ne l'interdit jamais.
    const fade = Math.exp((-Math.LN2 * t) / (2 * cfg.halfLifeMin));
    const caution = Math.min(cfg.fpCap, fpRate * cfg.fpStrength) * fade;
    p = 1 - (1 - p) * (1 - caution);
  }
  return Math.min(1, Math.max(0, p));
}

// Score 0–100 + probabilités multi-horizons (lisible, explicable).
export function pulsaScore(rec, glob, idleMin, cfg = PULSA_DEFAULTS) {
  const p10 = reuseProbability(rec, glob, idleMin, 10, cfg);
  const p60 = reuseProbability(rec, glob, idleMin, cfg.horizonMin, cfg);
  const p360 = reuseProbability(rec, glob, idleMin, 360, cfg);
  return { score: Math.round(p60 * 100), p10, p60, p360 };
}

// Décision de scoring seulement. Les protections (actif, épinglé, audio…)
// restent dans lib.js : PULSA note, un autre composant décide.
export function priority(score) {
  if (score > 80) return 'keep';
  if (score > 60) return 'monitor';
  if (score > 40) return 'low';
  if (score > 20) return 'high';
  return 'strong';
}
