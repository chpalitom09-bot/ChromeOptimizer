// Stockage local du modèle PULSA et suivi des changements d'onglet.
// Seuls le domaine et des durées sont conservés. Aucune URL complète, aucun titre.
import {
  emptyRecord, recordReturn, recordCensored, recordSleepOutcome, recordSleepKept
} from './pulsa.js';

const PREFIX = 'p:';
const GLOBAL_KEY = PREFIX + '*';
const MAX_HOSTS = 300;

function hostOf(url) {
  try { return new URL(url).hostname.toLowerCase().replace(/^www\./, ''); }
  catch { return ''; }
}
const isWeb = (url) => /^https?:/i.test(url || '');

/* ---------- Modèle ---------- */

export async function loadModel() {
  const all = await chrome.storage.local.get(null);
  const hosts = {};
  for (const [k, v] of Object.entries(all)) {
    if (k.startsWith(PREFIX) && k !== GLOBAL_KEY) hosts[k.slice(PREFIX.length)] = v;
  }
  return { hosts, glob: all[GLOBAL_KEY] || emptyRecord() };
}

export async function modelSize() {
  const m = await loadModel();
  return { hosts: Object.keys(m.hosts).length, intervals: Object.values(m.hosts).reduce((a, r) => a + r.iv.length, 0) };
}

export async function resetModel() {
  const all = await chrome.storage.local.get(null);
  const keys = Object.keys(all).filter((k) => k.startsWith(PREFIX));
  if (keys.length) await chrome.storage.local.remove(keys);
  await chrome.storage.session.remove('pulsaTabs');
}

// Garde les domaines les plus récents quand il y en a trop.
export async function pruneModel() {
  const m = await loadModel();
  const names = Object.keys(m.hosts);
  if (names.length <= MAX_HOSTS) return;
  names.sort((a, b) => (m.hosts[a].last || 0) - (m.hosts[b].last || 0));
  const drop = names.slice(0, names.length - MAX_HOSTS + 50).map((h) => PREFIX + h);
  await chrome.storage.local.remove(drop);
}

async function update(host, fn) {
  const keys = host ? [PREFIX + host, GLOBAL_KEY] : [GLOBAL_KEY];
  const cur = await chrome.storage.local.get(keys);
  const out = {};
  if (host) { const r = cur[PREFIX + host] || emptyRecord(); fn(r, false); out[PREFIX + host] = r; }
  const g = cur[GLOBAL_KEY] || emptyRecord();
  fn(g, true);
  out[GLOBAL_KEY] = g;
  await chrome.storage.local.set(out);
}

/* ---------- État éphémère (service worker non persistant) ---------- */

async function getState() {
  const { pulsaTabs } = await chrome.storage.session.get('pulsaTabs');
  return pulsaTabs || { left: {}, host: {}, active: {}, slept: {} };
}
const setState = (s) => chrome.storage.session.set({ pulsaTabs: s });

// Les événements sont traités l'un après l'autre pour éviter les écritures concurrentes.
let chain = Promise.resolve();
const queue = (fn) => { chain = chain.then(fn).catch(() => {}); return chain; };

/* ---------- Événements ---------- */

export function trackActivated({ tabId, windowId }) {
  return queue(async () => {
    const now = Date.now();
    const st = await getState();
    const prev = st.active[windowId];

    if (prev !== undefined && prev !== tabId) st.left[prev] = now;

    let host = st.host[tabId] || '';
    try {
      const tab = await chrome.tabs.get(tabId);
      host = isWeb(tab.url) ? hostOf(tab.url) : '';
      st.host[tabId] = host;
    } catch { /* onglet disparu */ }

    if (host && st.left[tabId]) {
      const minutes = (now - st.left[tabId]) / 60000;
      if (minutes >= 0.25) await update(host, (r) => recordReturn(r, minutes, now));
    }
    if (host && st.slept[tabId]) {
      const asleep = (now - st.slept[tabId]) / 60000;
      await update(host, (r) => recordSleepOutcome(r, asleep, now));
    }
    delete st.slept[tabId];
    delete st.left[tabId];
    st.active[windowId] = tabId;
    await setState(st);
  });
}

export function trackRemoved(tabId) {
  return queue(async () => {
    const now = Date.now();
    const st = await getState();
    const host = st.host[tabId];
    if (host && st.left[tabId]) {
      const minutes = (now - st.left[tabId]) / 60000;
      if (minutes >= 1) await update(host, (r) => recordCensored(r, minutes, now));
    }
    if (host && st.slept[tabId]) await update(host, (r) => recordSleepKept(r, now));
    delete st.left[tabId]; delete st.host[tabId]; delete st.slept[tabId];
    for (const w of Object.keys(st.active)) if (st.active[w] === tabId) delete st.active[w];
    await setState(st);
  });
}

// Appelé par optimize() juste après une mise en veille.
export function markSlept(ids) {
  return queue(async () => {
    const st = await getState();
    const now = Date.now();
    ids.forEach((id) => { st.slept[id] = now; });
    await setState(st);
  });
}

// Amorce l'état au démarrage : on sait quel onglet est actif, rien d'autre.
export function seedActive() {
  return queue(async () => {
    const st = await getState();
    const tabs = await chrome.tabs.query({});
    for (const t of tabs) {
      if (isWeb(t.url)) st.host[t.id] = hostOf(t.url);
      if (t.active) st.active[t.windowId] = t.id;
      else if (st.left[t.id] === undefined && t.lastAccessed) st.left[t.id] = t.lastAccessed;
    }
    await setState(st);
  });
}
