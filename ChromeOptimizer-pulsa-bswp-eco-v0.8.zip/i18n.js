// Langues de l'extension : choix de l'utilisateur (réglage « lang »), sinon langue du navigateur.
// Les drapeaux sont des images vectorielles : les drapeaux emoji ne s'affichent pas sous Windows.
import { getSettings, saveSettings } from './lib.js';
import { STRINGS } from './i18n-strings.js';

export const LANGS = {
  fr: { name: 'Français', short: 'FR' },
  en: { name: 'English', short: 'EN' }
};

const FLAGS = {
  fr: '<svg class="flag" viewBox="0 0 3 2" preserveAspectRatio="none" aria-hidden="true"><rect width="1" height="2" fill="#0055A4"/><rect x="1" width="1" height="2" fill="#fff"/><rect x="2" width="1" height="2" fill="#EF4135"/></svg>',
  en: '<svg class="flag" viewBox="0 0 60 40" preserveAspectRatio="none" aria-hidden="true"><rect width="60" height="40" fill="#012169"/><path d="M0 0L60 40M60 0L0 40" stroke="#fff" stroke-width="8"/><path d="M0 0L60 40M60 0L0 40" stroke="#C8102E" stroke-width="3"/><path d="M30 0V40M0 20H60" stroke="#fff" stroke-width="13"/><path d="M30 0V40M0 20H60" stroke="#C8102E" stroke-width="8"/></svg>'
};
const CHEVRON = '<svg class="chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>';
const CHECK = '<svg class="ck" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';

export let LANG = 'fr';

function detect() {
  try { return (chrome.i18n.getUILanguage() || '').toLowerCase().startsWith('fr') ? 'fr' : 'en'; } catch { return 'fr'; }
}

export function t(key, vars = {}) {
  const s = (STRINGS[LANG] && STRINGS[LANG][key]) ?? STRINGS.fr[key] ?? key;
  return s.replace(/\{(\w+)\}/g, (_, k) => (k in vars ? vars[k] : `{${k}}`));
}

// Pluriel : français → 0 et 1 au singulier ; anglais → seulement 1.
export function tn(key, n, vars = {}) {
  const one = LANG === 'fr' ? n <= 1 : n === 1;
  return t(`${key}.${one ? 'one' : 'other'}`, { n, ...vars });
}

export const num = (x, dec = 1) => (LANG === 'fr' ? x.toFixed(dec).replace('.', ',') : x.toFixed(dec));

export function applyI18n(root = document) {
  document.documentElement.lang = LANG;
  root.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
  root.querySelectorAll('[data-i18n-html]').forEach((el) => { el.innerHTML = t(el.dataset.i18nHtml); });   // textes internes uniquement
  root.querySelectorAll('[data-i18n-attr]').forEach((el) => {
    el.dataset.i18nAttr.split(';').forEach((pair) => {
      const [attr, key] = pair.split(':');
      if (attr && key) el.setAttribute(attr.trim(), t(key.trim()));
    });
  });
}

export async function initLang() {
  const s = await getSettings();
  LANG = s.lang in LANGS ? s.lang : detect();
  applyI18n();
  document.body.classList.add('i18n-ready');
}

export async function setLang(code) {
  if (!(code in LANGS)) return;
  LANG = code;
  await saveSettings({ lang: code });
  applyI18n();
}

// Sélecteur : bouton avec drapeau + liste déroulante. Clavier : ↑ ↓ Entrée Échap.
export function mountLangSwitcher(host, onChange) {
  host.classList.add('lang');
  host.innerHTML = `<button class="lang-btn" type="button" aria-haspopup="listbox" aria-expanded="false"><span class="fb"></span><span class="lc"></span>${CHEVRON}</button>`
    + `<ul class="lang-menu" role="listbox" hidden>${Object.keys(LANGS).map((c) =>
      `<li class="lang-opt" role="option" tabindex="-1" data-lang="${c}">${FLAGS[c]}<span class="ln">${LANGS[c].name}</span>${CHECK}</li>`).join('')}</ul>`;
  const btn = host.querySelector('.lang-btn'), menu = host.querySelector('.lang-menu');
  const opts = [...menu.querySelectorAll('.lang-opt')];

  function paint() {
    btn.querySelector('.fb').innerHTML = FLAGS[LANG];
    btn.querySelector('.lc').textContent = LANGS[LANG].short;
    btn.setAttribute('aria-label', `${t('lang.label')} : ${LANGS[LANG].name}`);
    btn.title = `${t('lang.label')} : ${LANGS[LANG].name}`;
    opts.forEach((o) => o.setAttribute('aria-selected', String(o.dataset.lang === LANG)));
  }
  function open() {
    menu.hidden = false; btn.setAttribute('aria-expanded', 'true');
    (opts.find((o) => o.dataset.lang === LANG) || opts[0]).focus();
  }
  function close(refocus) {
    menu.hidden = true; btn.setAttribute('aria-expanded', 'false');
    if (refocus) btn.focus();
  }
  async function pick(code) {
    close(true);
    if (code === LANG) return;
    await setLang(code);
    paint();
    if (onChange) await onChange(code);
  }

  btn.addEventListener('click', () => (menu.hidden ? open() : close(false)));
  btn.addEventListener('keydown', (e) => { if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); open(); } });
  opts.forEach((o, i) => {
    o.addEventListener('click', () => pick(o.dataset.lang));
    o.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown') { e.preventDefault(); opts[(i + 1) % opts.length].focus(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); opts[(i - 1 + opts.length) % opts.length].focus(); }
      else if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(o.dataset.lang); }
      else if (e.key === 'Escape' || e.key === 'Tab') { e.preventDefault(); close(true); }
    });
  });
  document.addEventListener('click', (e) => { if (!host.contains(e.target)) close(false); });
  paint();
  return { paint };
}
