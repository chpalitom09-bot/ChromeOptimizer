// EcoOptimizer : adapte l'extension au niveau de batterie.
// Module sans effet de bord (hors getEco, qui lit chrome.storage.session).
//
//  slow : part ajoutée à la durée entre deux cycles (0,05 = cycles 5 % plus lents)
//  shed : fonctions mises au repos
//         1 → plus d'écriture dans l'historique des sites
//         2 → en plus : BSWP retiré des pages, plus de lecture de la mémoire ni du réglage automatique
// Sur secteur : aucun changement.
export const ECO_NONE = { slow: 0, shed: 0 };

// Du plus bas au plus haut : le premier palier dont `max` couvre le niveau s'applique.
export const ECO_TIERS = [
  { max: 10, slow: 0.30, shed: 2 },
  { max: 20, slow: 0.15, shed: 1 },
  { max: 30, slow: 0.10, shed: 0 },
  { max: 40, slow: 0.05, shed: 0 }
];

// level : pourcentage entier (0–100). Renvoie { slow, shed }.
export function ecoProfile(level, charging) {
  if (charging || !Number.isFinite(level)) return ECO_NONE;
  const t = ECO_TIERS.find((x) => level <= x.max);
  return t ? { slow: t.slow, shed: t.shed } : ECO_NONE;
}

export async function getEco() {
  try {
    const { eco } = await chrome.storage.session.get('eco');
    if (!eco) return ECO_NONE;
    return { slow: Math.min(0.5, Math.max(0, Number(eco.slow) || 0)), shed: Math.min(2, Math.max(0, Number(eco.shed) || 0)) };
  } catch { return ECO_NONE; }
}
