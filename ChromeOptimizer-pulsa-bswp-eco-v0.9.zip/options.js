import { getSettings, saveSettings, getStats, resetStats, normalizeSites, MIN_IDLE, loadTune } from './lib.js';
import { tuneFactor } from './pulsa.js';
import { modelSize, resetModel } from './pulsa-store.js';
import { loadHistory, clearHistory } from './history.js';
import { ECO_TIERS, ecoProfile } from './eco.js';
import { initLang, mountLangSwitcher, t, tn, num } from './i18n.js';
import { checkForUpdate, getUpdateInfo, isNewer } from './update.js';

const $ = (id) => document.getElementById(id);
let toastTimer;

function toast() {
  const t = $('toast');
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 1400);
}

async function showStats() {
  const st = await getStats();
  $('stats').textContent = st.runs
    ? t('o.stats.line', { a: tn('n.slept', st.slept), b: tn('n.closed', st.closed) })
    : t('o.stats.none');
}

async function showModel() {
  const { hosts, intervals } = await modelSize();
  $('pulsaInfo').textContent = hosts ? tn('o.model.known', hosts, { m: intervals }) : t('o.model.none');
  const tune = await loadTune();
  const f = tuneFactor(tune);
  if (tune.n >= 5 && Math.abs(f - 1) > 0.02) {
    $('pulsaInfo').textContent += t('o.model.tune', { f: num(f, 2), kind: f < 1 ? t('o.model.cautious') : t('o.model.firm') });
  }
}

async function showHist() {
  const n = (await loadHistory()).length;
  $('histInfo').textContent = n ? tn('o.hist.n', n) : t('o.hist.empty');
}

async function showUpd() {
  const u = await getUpdateInfo(), cur = chrome.runtime.getManifest().version;
  $('updInfo').textContent = !u ? t('o.upd.never', { cur })
    : u.status === 'store' ? t('o.upd.store')
    : u.status === 'available' && isNewer(u.latest, cur) ? t('o.upd.avail', { latest: u.latest, cur })
    : u.status === 'current' ? t('o.upd.current', { cur })
    : t('o.upd.error', { cur });
}

const pct = (x) => Math.round(x * 100);

function showEcoTiers() {
  $('ecoTiers').innerHTML = [...ECO_TIERS].reverse()
    .map((x) => `<li>${t('eco.tier', { max: x.max, slow: pct(x.slow) })}${x.shed ? ' · ' + t('eco.tShed' + x.shed) : ''}</li>`).join('');
}

async function showEco(on) {
  const el = $('ecoInfo');
  if (!on) { el.textContent = ''; return; }
  try {
    const b = await navigator.getBattery();
    const level = Math.round(b.level * 100), p = ecoProfile(level, b.charging);
    el.textContent = b.charging ? t('eco.charging', { level })
      : p.slow ? t('eco.slow', { level, slow: pct(p.slow) })
      : t('eco.none', { level });
  } catch { el.textContent = t('eco.na'); }
}

function syncPulsaBox(algo) { $('pulsaBox').style.display = algo === 'pulsa' ? '' : 'none'; }

async function init() {
  await initLang();
  mountLangSwitcher($('langHost'), async () => {
    const s = await getSettings();
    showEcoTiers();
    await Promise.all([showEco(s.ecoOptimizer), showHist(), showUpd(), showModel(), showStats()]);
  });
  $('ver').textContent = chrome.runtime.getManifest().version;
  const s = await getSettings();
  document.querySelector(`input[name=mode][value=${s.mode}]`).checked = true;
  $('idle').value = s.idleMinutes;
  $('algo').value = s.algorithm;
  $('hist').value = s.history ? 'on' : 'off';
  $('adMem').value = s.adaptMemory ? 'on' : 'off';
  $('adTune').value = s.autoTune ? 'on' : 'off';
  $('adInt').value = s.adaptiveInterval ? 'on' : 'off';
  $('eco').value = s.ecoOptimizer ? 'on' : 'off';
  showEcoTiers();
  await showEco(s.ecoOptimizer);
  await showHist();
  $('upd').value = s.updateCheck ? 'on' : 'off';
  await showUpd();
  $('sens').value = s.sensitivity;
  syncPulsaBox(s.algorithm);
  await showModel();
  $('dups').value = s.duplicates;
  $('sites').value = s.protectedSites.join('\n');
  await showStats();
}

document.querySelectorAll('input[name=mode]').forEach((r) =>
  r.addEventListener('change', async () => { await saveSettings({ mode: r.value }); toast(); }));

$('idle').addEventListener('change', async () => {
  const v = Math.min(1440, Math.max(MIN_IDLE, Math.round(Number($('idle').value) || 30)));
  $('idle').value = v;
  await saveSettings({ idleMinutes: v });
  toast();
});

$('algo').addEventListener('change', async () => { await saveSettings({ algorithm: $('algo').value }); syncPulsaBox($('algo').value); toast(); });
$('sens').addEventListener('change', async () => { await saveSettings({ sensitivity: $('sens').value }); toast(); });
$('resetModel').addEventListener('click', async () => { await resetModel(); await showModel(); toast(); });

$('adMem').addEventListener('change', async () => { await saveSettings({ adaptMemory: $('adMem').value === 'on' }); toast(); });
$('adTune').addEventListener('change', async () => { await saveSettings({ autoTune: $('adTune').value === 'on' }); toast(); });
$('adInt').addEventListener('change', async () => { await saveSettings({ adaptiveInterval: $('adInt').value === 'on' }); toast(); });

$('eco').addEventListener('change', async () => { const on = $('eco').value === 'on'; await saveSettings({ ecoOptimizer: on }); await showEco(on); toast(); });
$('upd').addEventListener('change', async () => { await saveSettings({ updateCheck: $('upd').value === 'on' }); toast(); });
$('updNow').addEventListener('click', async () => {
  $('updNow').disabled = true; $('updInfo').textContent = t('o.upd.checking');
  await checkForUpdate({ force: true }); await showUpd(); $('updNow').disabled = false;
});

$('hist').addEventListener('change', async () => { await saveSettings({ history: $('hist').value === 'on' }); toast(); });
$('clearHist').addEventListener('click', async () => { await clearHistory(); await showHist(); toast(); });

$('dups').addEventListener('change', async () => { await saveSettings({ duplicates: $('dups').value }); toast(); });

$('sites').addEventListener('change', async () => {
  const list = normalizeSites($('sites').value);
  $('sites').value = list.join('\n');
  await saveSettings({ protectedSites: list });
  toast();
});

$('reset').addEventListener('click', async () => { await resetStats(); await showStats(); toast(); });

init();
