// Vérification de mise à jour, 100 % passive : une seule requête GET par jour vers le dépôt GitHub
// (le manifest.json public). Aucune donnée n'est envoyée, aucun identifiant, aucun contenu.
// Désactivable dans les réglages. L'extension ne se réécrit jamais toute seule :
// elle prévient, vous téléchargez et rechargez.
const REPO = 'chpalitom09-bot/ChromeOptimizer';
export const REPO_URL = `https://github.com/${REPO}`;
const MANIFEST_URL = `https://raw.githubusercontent.com/${REPO}/main/manifest.json`;
const DAY = 24 * 60 * 60 * 1000;

export function isNewer(a, b) {   // vrai si la version a est plus récente que b
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const x = pa[i] || 0, y = pb[i] || 0;
    if (x !== y) return x > y;
  }
  return false;
}

export async function getUpdateInfo() {
  const { update } = await chrome.storage.local.get('update');
  return update || null;
}

function setBadge(on) {
  chrome.action.setBadgeText({ text: on ? '↑' : '' });
  if (on) chrome.action.setBadgeBackgroundColor({ color: '#2f6fed' });
}

// force : ignore la limite d'une vérification par jour (bouton « Vérifier maintenant »).
export async function checkForUpdate({ force = false } = {}) {
  const current = chrome.runtime.getManifest().version;
  const prev = await getUpdateInfo();
  if (!force && prev && Date.now() - prev.checkedAt < DAY - 60000) return prev;

  // 1) Installation via le Chrome Web Store ou update_url : Chrome sait se mettre à jour seul.
  try {
    const r = await chrome.runtime.requestUpdateCheck();
    if (r && r.status === 'update_available') {
      const info = { status: 'store', latest: r.version || '', checkedAt: Date.now() };
      await chrome.storage.local.set({ update: info }); setBadge(true);
      return info;
    }
  } catch { /* extension chargée en mode développeur : on passe au dépôt */ }

  // 2) Extension chargée à la main : on compare avec le manifest du dépôt.
  let info = { status: 'error', latest: '', checkedAt: Date.now() };
  try {
    const res = await fetch(MANIFEST_URL, { cache: 'no-store', credentials: 'omit', referrerPolicy: 'no-referrer' });
    if (res.ok) {
      const latest = String((await res.json()).version || '');
      info = { status: latest && isNewer(latest, current) ? 'available' : 'current', latest, checkedAt: Date.now() };
    }
  } catch { /* hors ligne : on réessaiera au prochain cycle */ }
  await chrome.storage.local.set({ update: info });
  setBadge(info.status === 'available');
  return info;
}

export async function clearBadgeIfCurrent() {
  const u = await getUpdateInfo();
  if (u && u.status === 'available' && !isNewer(u.latest, chrome.runtime.getManifest().version)) {
    await chrome.storage.local.set({ update: { ...u, status: 'current' } });
    setBadge(false);
  }
}
