// BSWP (Better Speed WebPage) : script injecté uniquement quand l'interrupteur est activé.
// Méthodes sans risque pour l'affichage : on ne bloque, ne retire et ne reporte aucun script.
// On ne touche qu'à ce qui est loin sous la zone visible (au-delà de 2 écrans) :
//  - images et cadres (iframes) : chargement différé (loading="lazy"), décodage asynchrone ;
//  - vidéos sans lecture automatique : on ne précharge que les métadonnées.
// Rien n'est lu, stocké ni envoyé. Le script se met au repos après quelques secondes.
(() => {
  if (window.__bswp) return;
  window.__bswp = true;
  const stats = { img: 0, frame: 0, video: 0 };
  const far = (el) => el.getBoundingClientRect().top > innerHeight * 2;

  function scan(root) {
    root.querySelectorAll('img:not([loading])').forEach((el) => {
      if (el.complete || !far(el)) return;
      el.loading = 'lazy'; el.decoding = 'async'; stats.img++;
    });
    root.querySelectorAll('iframe:not([loading])').forEach((el) => {
      if (!far(el) || /^(about|javascript|data):/i.test(el.getAttribute('src') || 'about:')) return;
      el.loading = 'lazy'; stats.frame++;
    });
    root.querySelectorAll('video:not([autoplay])').forEach((el) => {
      if (el.preload === 'metadata' || el.preload === 'none' || !far(el)) return;
      el.preload = 'metadata'; stats.video++;
    });
  }

  scan(document);

  // Contenus ajoutés pendant le chargement (défilement infini, scripts tardifs) : 8 s maximum.
  let queued = false;
  const idle = window.requestIdleCallback || ((f) => setTimeout(f, 200));
  const mo = new MutationObserver(() => {
    if (queued) return;
    queued = true;
    idle(() => { queued = false; scan(document); });
  });
  mo.observe(document.documentElement, { childList: true, subtree: true });
  setTimeout(() => mo.disconnect(), 8000);

  chrome.runtime.onMessage.addListener((msg, _s, reply) => {
    if (msg && msg.type === 'bswp-stats') reply(stats);
  });
})();
