// Document invisible : l'API Batterie n'existe pas dans un service worker.
// Il n'existe que si EcoOptimizer est activé, ne boucle pas, et ne réveille
// l'extension que lorsque le palier change (pas à chaque pourcent).
import { ecoProfile } from './eco.js';

let last = '';
let bat = null;

function push() {
  if (!bat) return;
  const level = Math.round(bat.level * 100);
  const p = ecoProfile(level, bat.charging);
  const key = `${p.slow}|${p.shed}`;
  if (key === last) return;
  last = key;
  chrome.runtime.sendMessage({ type: 'eco-battery', level, charging: !!bat.charging, slow: p.slow, shed: p.shed }).catch(() => {});
}

navigator.getBattery().then((b) => {
  bat = b;
  b.addEventListener('levelchange', push);
  b.addEventListener('chargingchange', push);
  push();
}).catch(() => {});
