// Langues de l'extension : choix de l'utilisateur (réglage « lang »), sinon langue du navigateur.
// Les drapeaux sont des images vectorielles : les drapeaux emoji ne s'affichent pas sous Windows.
import { getSettings, saveSettings } from './lib.js';
import { STRINGS } from './i18n-strings.js';

export const LANGS = {
  fr: { name: 'Français', short: 'FR' },
  en: { name: 'English', short: 'EN' },
  es: { name: 'Español', short: 'ES' },
  de: { name: 'Deutsch', short: 'DE' },
  zh: { name: '中文', short: '中文' },
  ru: { name: 'Русский', short: 'RU' }
};

// Code de langue pour Intl.PluralRules, et séparateur décimal (virgule ou point).
const LOCALE = { fr: 'fr', en: 'en', es: 'es', de: 'de', zh: 'zh', ru: 'ru' };
const COMMA = new Set(['fr', 'es', 'de', 'ru']);

const FLAGS = {
  fr: '<svg class="flag" viewBox="0 0 3 2" preserveAspectRatio="none" aria-hidden="true"><rect width="1" height="2" fill="#0055A4"/><rect x="1" width="1" height="2" fill="#fff"/><rect x="2" width="1" height="2" fill="#EF4135"/></svg>',
  en: '<svg class="flag" viewBox="0 0 60 40" preserveAspectRatio="none" aria-hidden="true"><rect width="60" height="40" fill="#012169"/><path d="M0 0L60 40M60 0L0 40" stroke="#fff" stroke-width="8"/><path d="M0 0L60 40M60 0L0 40" stroke="#C8102E" stroke-width="3"/><path d="M30 0V40M0 20H60" stroke="#fff" stroke-width="13"/><path d="M30 0V40M0 20H60" stroke="#C8102E" stroke-width="8"/></svg>',
  es: '<svg class="flag" viewBox="0 0 3 2" preserveAspectRatio="none" aria-hidden="true"><rect width="3" height="2" fill="#AA151B"/><rect y="0.5" width="3" height="1" fill="#F1BF00"/></svg>',
  de: '<svg class="flag" viewBox="0 0 3 2" preserveAspectRatio="none" aria-hidden="true"><rect width="3" height="0.67" fill="#000"/><rect y="0.67" width="3" height="0.67" fill="#DD0000"/><rect y="1.33" width="3" height="0.67" fill="#FFCE00"/></svg>',
  zh: '<svg class="flag" viewBox="0 0 18 12" preserveAspectRatio="none" aria-hidden="true"><rect width="18" height="12" fill="#DE2910"/><polygon points="6.00,2.40 6.81,4.89 9.42,4.89 7.31,6.42 8.12,8.91 6.00,7.38 3.88,8.91 4.69,6.42 2.58,4.89 5.19,4.89" fill="#FFDE00"/><polygon points="10.97,3.02 11.54,2.36 11.09,1.61 11.90,1.95 12.47,1.30 12.39,2.16 13.20,2.51 12.35,2.70 12.27,3.57 11.82,2.82" fill="#FFDE00"/><polygon points="13.21,4.97 13.99,4.59 13.87,3.72 14.48,4.35 15.26,3.96 14.85,4.74 15.46,5.36 14.60,5.21 14.19,5.98 14.07,5.12" fill="#FFDE00"/><polygon points="13.25,8.07 14.12,8.04 14.36,7.20 14.66,8.02 15.53,7.99 14.84,8.53 15.14,9.34 14.42,8.86 13.73,9.40 13.97,8.56" fill="#FFDE00"/><polygon points="11.06,10.05 11.88,10.36 12.42,9.68 12.38,10.55 13.20,10.86 12.36,11.09 12.32,11.96 11.84,11.23 11.00,11.46 11.54,10.78" fill="#FFDE00"/></svg>',
  ru: '<svg class="flag" viewBox="0 0 3 2" preserveAspectRatio="none" aria-hidden="true"><rect width="3" height="0.67" fill="#fff"/><rect y="0.67" width="3" height="0.67" fill="#0039A6"/><rect y="1.33" width="3" height="0.67" fill="#D52B1E"/></svg>'
};
const CHEVRON = '<svg class="chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>';
const CHECK = '<svg class="ck" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';

export let LANG = 'fr';

function detect() {
  try {
    const code = (chrome.i18n.getUILanguage() || '').toLowerCase().slice(0, 2);
    return code in LANGS ? code : 'en';
  } catch { return 'fr'; }
}

export function t(key, vars = {}) {
  const s = (STRINGS[LANG] && STRINGS[LANG][key]) ?? STRINGS.fr[key] ?? key;
  return s.replace(/\{(\w+)\}/g, (_, k) => (k in vars ? vars[k] : `{${k}}`));
}

// Pluriel : catégories CLDR de la langue (fr : 0 et 1 au singulier ; ru : one / few / many ; zh : other seul).
// On cherche « clé.catégorie », puis « clé.other » dans la langue choisie, puis le français.
const rules = {};
export function tn(key, n, vars = {}) {
  const pr = rules[LANG] || (rules[LANG] = new Intl.PluralRules(LOCALE[LANG] || 'en'));
  const cat = pr.select(n);
  const dict = STRINGS[LANG] || {};
  const k = [`${key}.${cat}`, `${key}.other`].find((x) => x in dict) || `${key}.${cat === 'one' ? 'one' : 'other'}`;
  const s = dict[k] ?? STRINGS.fr[k] ?? STRINGS.fr[`${key}.other`] ?? k;
  return s.replace(/\{(\w+)\}/g, (_, v) => ((v === 'n') ? n : (v in vars ? vars[v] : `{${v}}`)));
}

export const num = (x, dec = 1) => (COMMA.has(LANG) ? x.toFixed(dec).replace('.', ',') : x.toFixed(dec));

export function applyI18n(root = document) {
  document.documentElement.lang = LANG;
  root.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
  root.querySelectorAll('[data-i18n-html]').forEach((el) => { el.innerHTML = t(el.dataset.i18nHtml); });   // textes internes uniquement
  root.querySelectorAll('[data-i18n-attr]').forEach((el) => {
    el.dataset.i18nAttr.split(';').forEach((pair) => {
      const [attr, key] = pair.split(':');
      if (attr && key) el.setAttribute(attr.trim(), t(key.trim()));
    });
  });
}

export async function initLang() {
  const s = await getSettings();
  LANG = s.lang in LANGS ? s.lang : detect();
  applyI18n();
  document.body.classList.add('i18n-ready');
}

export async function setLang(code) {
  if (!(code in LANGS)) return;
  LANG = code;
  await saveSettings({ lang: code });
  applyI18n();
}

// Sélecteur : bouton avec drapeau + liste déroulante. Clavier : ↑ ↓ Entrée Échap.
export function mountLangSwitcher(host, onChange) {
  host.classList.add('lang');
  host.innerHTML = `<button class="lang-btn" type="button" aria-haspopup="listbox" aria-expanded="false"><span class="fb"></span><span class="lc"></span>${CHEVRON}</button>`
    + `<ul class="lang-menu" role="listbox" hidden>${Object.keys(LANGS).map((c) =>
      `<li class="lang-opt" role="option" tabindex="-1" data-lang="${c}">${FLAGS[c]}<span class="ln">${LANGS[c].name}</span>${CHECK}</li>`).join('')}</ul>`;
  const btn = host.querySelector('.lang-btn'), menu = host.querySelector('.lang-menu');
  const opts = [...menu.querySelectorAll('.lang-opt')];

  function paint() {
    btn.querySelector('.fb').innerHTML = FLAGS[LANG];
    btn.querySelector('.lc').textContent = LANGS[LANG].short;
    btn.setAttribute('aria-label', `${t('lang.label')} : ${LANGS[LANG].name}`);
    btn.title = `${t('lang.label')} : ${LANGS[LANG].name}`;
    opts.forEach((o) => o.setAttribute('aria-selected', String(o.dataset.lang === LANG)));
  }
  function open() {
    menu.hidden = false; btn.setAttribute('aria-expanded', 'true');
    (opts.find((o) => o.dataset.lang === LANG) || opts[0]).focus();
  }
  function close(refocus) {
    menu.hidden = true; btn.setAttribute('aria-expanded', 'false');
    if (refocus) btn.focus();
  }
  async function pick(code) {
    close(true);
    if (code === LANG) return;
    await setLang(code);
    paint();
    if (onChange) await onChange(code);
  }

  btn.addEventListener('click', () => (menu.hidden ? open() : close(false)));
  btn.addEventListener('keydown', (e) => { if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); open(); } });
  opts.forEach((o, i) => {
    o.addEventListener('click', () => pick(o.dataset.lang));
    o.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown') { e.preventDefault(); opts[(i + 1) % opts.length].focus(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); opts[(i - 1 + opts.length) % opts.length].focus(); }
      else if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(o.dataset.lang); }
      else if (e.key === 'Escape' || e.key === 'Tab') { e.preventDefault(); close(true); }
    });
  });
  document.addEventListener('click', (e) => { if (!host.contains(e.target)) close(false); });
  paint();
  return { paint };
}
