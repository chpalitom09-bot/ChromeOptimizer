import { getSettings, saveSettings, getStats, analyze, optimize, hostOf, isProtectedSite, getContext } from './lib.js';
import { getUpdateInfo, isNewer, REPO_URL } from './update.js';
import { loadModel } from './pulsa-store.js';

const $ = (id) => document.getElementById(id);
const plural = (n, one, many) => `${n} ${n > 1 ? many : one}`;
const gb = (bytes) => (bytes / 1073741824).toFixed(1).replace('.', ',');

/* ---------- Performances du système (lues uniquement popup ouverte) ---------- */

let prevCpu = null;

function setGauge(id, pct, sub) {
  const ring = $(id + 'Ring');
  ring.style.strokeDasharray = `${pct} 100`;
  ring.classList.toggle('warn', pct >= 70 && pct < 90);
  ring.classList.toggle('hot', pct >= 90);
  $(id + 'Pct').textContent = pct + ' %';
  if (sub !== undefined) $(id + 'Sub').textContent = sub;
}

async function readMemory() {
  const m = await chrome.system.memory.getInfo();
  const used = m.capacity - m.availableCapacity;
  setGauge('mem', Math.round((used / m.capacity) * 100), `${gb(used)} / ${gb(m.capacity)} Go`);
}

async function readCpu() {
  const info = await chrome.system.cpu.getInfo();
  const total = info.processors.reduce((a, p) => ({ idle: a.idle + p.usage.idle, total: a.total + p.usage.total }), { idle: 0, total: 0 });
  if (prevCpu && total.total > prevCpu.total) {
    setGauge('cpu', Math.round((1 - (total.idle - prevCpu.idle) / (total.total - prevCpu.total)) * 100), `${info.numOfProcessors} cœurs`);
  }
  prevCpu = total;
}

function tick() { readMemory().catch(() => {}); readCpu().catch(() => {}); }

/* ---------- Onglets ---------- */

async function refreshTabs() {
  const [settings, tabs] = await Promise.all([getSettings(), chrome.tabs.query({})]);
  const model = settings.algorithm === 'pulsa' ? await loadModel() : null;
  const plan = analyze(tabs, settings, Date.now(), model, await getContext(settings));
  $('open').textContent = tabs.length;
  $('sleeping').textContent = tabs.filter((t) => t.discarded).length;
  $('todo').textContent = plan.sleep.length + plan.close.length;
  const dup = settings.duplicates === 'off' ? 'doublons ignorés' : plural(plan.close.length, 'doublon', 'doublons');
  $('hint').textContent = settings.algorithm === 'pulsa'
    ? `PULSA : ${plural(plan.sleep.length, 'onglet peu susceptible', 'onglets peu susceptibles')} d'être rouvert${plan.sleep.length > 1 ? 's' : ''}, ${dup}`
    : `${plural(plan.sleep.length, 'inactif', 'inactifs')} depuis ${settings.idleMinutes} min ou plus, ${dup}`;
}

/* ---------- BSWP on/off ---------- */

async function showBswp(s) {
  $('bswpOn').checked = s.bswp;
  const hint = $('bswpHint');
  if (!s.bswp) { hint.textContent = 'Désactivé : aucun script n\'est injecté dans les pages.'; return; }
  hint.textContent = 'Actif : les éléments loin sous la zone visible se chargent plus tard.';
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const r = await chrome.tabs.sendMessage(tab.id, { type: 'bswp-stats' });
    const n = r.img + r.frame + r.video;
    hint.textContent = n ? `Cette page : ${plural(r.img, 'image', 'images')}, ${plural(r.frame, 'cadre', 'cadres')}, ${plural(r.video, 'vidéo', 'vidéos')} différés.` : 'Cette page : rien à différer.';
  } catch { /* page interne, ou page ouverte avant l'activation : rechargez-la */ }
}

$('bswpOn').addEventListener('change', async (e) => {
  const on = e.target.checked;
  if (on) {   // Chrome demande l'accès aux sites à ce moment seulement (geste de l'utilisateur)
    const ok = await chrome.permissions.request({ origins: ['http://*/*', 'https://*/*'] });
    if (!ok) { e.target.checked = false; return; }
  } else {
    await chrome.permissions.remove({ origins: ['http://*/*', 'https://*/*'] }).catch(() => {});
  }
  const s = await saveSettings({ bswp: on });
  await showBswp(s);
  if (on) $('bswpHint').textContent += ' Rechargez les pages déjà ouvertes.';
});

/* ---------- PULSA on/off ---------- */

function showPulsa(s) {
  $('pulsaOn').checked = s.algorithm === 'pulsa';
  $('pulsaHint').textContent = s.algorithm === 'pulsa'
    ? 'Les onglets sont triés selon leur probabilité d\'être rouverts.'
    : `Désactivé : mise en veille après ${s.idleMinutes} min d'inactivité.`;
}

async function showUpdate() {
  const [s, u] = await Promise.all([getSettings(), getUpdateInfo()]);
  const b = $('updBanner');
  const cur = chrome.runtime.getManifest().version;
  const show = s.updateCheck && u && (u.status === 'store' || (u.status === 'available' && isNewer(u.latest, cur)));
  b.hidden = !show;
  if (!show) return;
  if (u.status === 'store') {
    b.textContent = 'Mise à jour prête : cliquez pour recharger l\'extension';
    b.href = '#';
    b.onclick = (e) => { e.preventDefault(); chrome.runtime.reload(); };
  } else {
    b.textContent = `Version ${u.latest} disponible (vous avez la ${cur}) · Télécharger`;
    b.href = REPO_URL; b.onclick = null;
  }
}

async function refreshTotals() {
  const st = await getStats();
  $('totals').textContent = st.runs
    ? `Depuis le début : ${plural(st.slept, 'onglet mis en veille', 'onglets mis en veille')}, ${plural(st.closed, 'doublon fermé', 'doublons fermés')}`
    : 'Aucune optimisation pour le moment';
}

async function refreshProtect() {
  const btn = $('protect');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const host = tab && /^https?:/i.test(tab.url || '') ? hostOf(tab.url) : '';
  if (!host) { btn.disabled = true; btn.textContent = 'Protéger ce site'; return; }
  const settings = await getSettings();
  const on = isProtectedSite(tab.url, settings.protectedSites);
  btn.disabled = false;
  btn.dataset.host = host;
  btn.dataset.on = on ? '1' : '';
  btn.textContent = on ? `Ne plus protéger ${host}` : `Protéger ${host}`;
  btn.title = btn.textContent;
}

/* ---------- Actions ---------- */

$('run').addEventListener('click', async () => {
  const btn = $('run');
  btn.disabled = true; btn.textContent = 'Optimisation…'; $('result').textContent = '';
  try {
    const { slept, closed } = await optimize({ manual: true });
    $('result').textContent = slept || closed
      ? `${plural(slept, 'onglet mis en veille', 'onglets mis en veille')}, ${plural(closed, 'doublon fermé', 'doublons fermés')}.`
      : 'Rien à optimiser avec ces réglages.';
  } catch {
    $('result').textContent = "L'optimisation a échoué. Réessayez.";
  }
  btn.disabled = false; btn.textContent = 'Optimiser maintenant';
  await Promise.all([refreshTabs(), refreshTotals()]);
  setTimeout(tick, 1200);
});

$('pulsaOn').addEventListener('change', async (e) => {
  const s = await saveSettings({ algorithm: e.target.checked ? 'pulsa' : 'classic' });
  showPulsa(s);
  await refreshTabs();
});

$('auto').addEventListener('change', async (e) => {
  await saveSettings({ mode: e.target.checked ? 'auto' : 'manual' });
});

$('protect').addEventListener('click', async () => {
  const btn = $('protect'), host = btn.dataset.host;
  if (!host) return;
  const s = await getSettings();
  const list = btn.dataset.on ? s.protectedSites.filter((d) => host !== d && !host.endsWith('.' + d)) : [...new Set([...s.protectedSites, host])];
  await saveSettings({ protectedSites: list });
  await Promise.all([refreshProtect(), refreshTabs()]);
});

$('openOptions').addEventListener('click', () => chrome.runtime.openOptionsPage());

/* ---------- Démarrage ---------- */

(async () => {
  const s = await getSettings();
  $('auto').checked = s.mode === 'auto';
  showPulsa(s);
  showBswp(s);
  await Promise.all([refreshTabs(), refreshTotals(), refreshProtect(), showUpdate()]);
  tick();
  setInterval(tick, 1500);   // s'arrête avec la fermeture du popup
})();
