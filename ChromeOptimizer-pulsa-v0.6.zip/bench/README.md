# Banc d'essai PULSA

    node bench/simulate.mjs

Rejoue 20 semaines d'usage **synthétiques** (40 onglets : périodiques, en rafale,
quotidiens, épars, jetables) et compare PULSA à des délais fixes.
Même code `pulsa.js` que l'extension.

Métriques : économie de mémoire relative à un oracle, rechargements,
faux positifs (retour < 1 h après la veille), précision, score de Brier de P(retour < 1 h).

Limite : ces résultats valident la mécanique, pas l'efficacité réelle.
Il faut des traces d'usage réelles (extension de collecte) pour conclure.

## Résultats v0.4 (données simulées)

- Machine simulée : 12 Go de RAM dont 4 Go pour le reste du système.
- « Réglage auto » rapproche le comportement du point équilibré quand le seuil est trop agressif ; il ne bat pas la frontière des délais fixes.
- « Mémoire » déplace PULSA vers plus de prudence tant que la RAM est libre. Le banc d'essai ne mesure pas le bénéfice attendu (ne pas déranger l'utilisateur quand rien ne presse).
- Les cycles espacés ne sont pas simulés : leur effet est sur le coût de l'extension, pas sur les décisions.

## v0.5
- Ajout de la vérification quotidienne de version (update.js), affichage Sites retiré du panneau (l'historique reste enregistré), jauges circulaires RAM / CPU.
- v0.6 : BSWP (bswp.js), interrupteur dans le panneau, accès aux sites demandé à l'activation seulement.
