// Service worker : il ne fait rien tant que Chrome ne le réveille pas.
// Mode automatique : une alarme à la fois, dont le délai s'allonge (1, 2, 5, 10 min)
// tant qu'il n'y a rien à faire, et repart à 1 min dès qu'un onglet change.
// Mode manuel : aucune alarme.
import { getSettings, saveSettings, optimize } from './lib.js';
import { trackActivated, trackRemoved, seedActive } from './pulsa-store.js';
import { CYCLE_STEPS, nextStage } from './pulsa.js';
import { checkForUpdate, clearBadgeIfCurrent } from './update.js';

const ALARM = 'chromeoptimizer-cycle';
const BSWP_ID = 'bswp';

// BSWP : le script n'est enregistré que si l'interrupteur est actif ET que Chrome a accordé l'accès.
async function syncBswp() {
  const { bswp } = await getSettings();
  const registered = (await chrome.scripting.getRegisteredContentScripts({ ids: [BSWP_ID] })).length > 0;
  const granted = await chrome.permissions.contains({ origins: ['http://*/*', 'https://*/*'] });
  if (bswp && granted && !registered) {
    await chrome.scripting.registerContentScripts([{ id: BSWP_ID, matches: ['http://*/*', 'https://*/*'], js: ['bswp.js'], runAt: 'document_idle', persistAcrossSessions: true }]);
  } else if ((!bswp || !granted) && registered) {
    await chrome.scripting.unregisterContentScripts({ ids: [BSWP_ID] });
  }
}
const UPDATE_ALARM = 'chromeoptimizer-update';

// Une alarme par jour, indépendante du mode : elle ne fait qu'un GET vers GitHub.
async function syncUpdateAlarm() {
  const { updateCheck } = await getSettings();
  if (!updateCheck) { await chrome.alarms.clear(UPDATE_ALARM); return; }
  if (!(await chrome.alarms.get(UPDATE_ALARM))) await chrome.alarms.create(UPDATE_ALARM, { delayInMinutes: 1, periodInMinutes: 1440 });
}

async function getStage() {
  const { cycleStage } = await chrome.storage.session.get('cycleStage');
  return cycleStage || 0;
}

async function schedule(stage) {
  const s = await getSettings();
  if (s.mode !== 'auto') { await chrome.alarms.clear(ALARM); return; }
  const delay = s.adaptiveInterval ? CYCLE_STEPS[stage] : CYCLE_STEPS[0];
  await chrome.alarms.create(ALARM, { delayInMinutes: delay });
  await chrome.storage.session.set({ cycleStage: s.adaptiveInterval ? stage : 0 });
}

async function syncAlarm() {
  const { mode } = await getSettings();
  if (mode !== 'auto') { await chrome.alarms.clear(ALARM); return; }
  if (!(await chrome.alarms.get(ALARM))) await schedule(0);
}

// Un onglet créé, fermé ou activé change la donne : on revient à un cycle par minute.
async function wake() {
  if ((await getStage()) > 0) await schedule(0);
}

chrome.runtime.onInstalled.addListener(() => { syncAlarm(); syncUpdateAlarm(); syncBswp().catch(() => {}); seedActive(); clearBadgeIfCurrent(); });
chrome.runtime.onStartup.addListener(() => { syncAlarm(); syncUpdateAlarm(); syncBswp().catch(() => {}); seedActive(); });

// Apprentissage PULSA : un événement par changement d'onglet, rien en continu.
chrome.tabs.onActivated.addListener((info) => { trackActivated(info); wake(); });
chrome.tabs.onRemoved.addListener((id) => { trackRemoved(id); wake(); });
chrome.tabs.onCreated.addListener(wake);

chrome.permissions.onRemoved.addListener(() => syncBswp().catch(() => {}));

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !changes.settings) return;
  const a = changes.settings.oldValue || {}, b = changes.settings.newValue || {};
  if (a.updateCheck !== b.updateCheck) syncUpdateAlarm();
  if (a.bswp !== b.bswp) syncBswp().catch(() => {});
  if (a.adaptiveInterval !== b.adaptiveInterval) schedule(0); else syncAlarm();
});

// Raccourci clavier : activer ou désactiver PULSA (modifiable dans chrome://extensions/shortcuts).
chrome.commands.onCommand.addListener(async (cmd) => {
  if (cmd === 'optimize-now') { optimize({ manual: true }); return; }
  if (cmd !== 'toggle-pulsa') return;
  const { algorithm } = await getSettings();
  await saveSettings({ algorithm: algorithm === 'pulsa' ? 'classic' : 'pulsa' });
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === UPDATE_ALARM) { checkForUpdate().catch(() => {}); return; }
  if (alarm.name !== ALARM) return;
  let stage = await getStage();
  try {
    const { slept, closed } = await optimize();
    stage = nextStage(stage, slept + closed > 0);
  } finally {
    await schedule(stage);
  }
});
