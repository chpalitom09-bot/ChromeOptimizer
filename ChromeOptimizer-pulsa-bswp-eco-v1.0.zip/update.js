// Vérification de mise à jour, 100 % passive : une seule requête GET par jour vers le dépôt GitHub
// (le fichier public version.json). Aucune donnée n'est envoyée, aucun identifiant, aucun contenu.
// Désactivable dans les réglages. L'extension ne se réécrit jamais toute seule :
// elle prévient, vous téléchargez et rechargez.
//
// Numérotation : « 1.0 » est la version affichée (manifest : version_name). Le numéro technique
// est 1.0.0.N : le dernier chiffre est la révision. Corriger la 1.0 = publier 1.0.0.2, 1.0.0.3…
// Les utilisateurs de la 1.0 voient alors la mise à jour sans que la version « 1.0 » change.
const REPO = 'chpalitom09-bot/ChromeOptimizer';
export const REPO_URL = `https://github.com/${REPO}`;
export const PAGE_URL = 'https://chpalitom09-bot.github.io/ChromeOptimizer/#versions';
const RAW = `https://raw.githubusercontent.com/${REPO}/main/`;
const VERSION_URL = RAW + 'version.json';
const MANIFEST_URL = RAW + 'manifest.json';   // repli : anciennes publications sans version.json
const DAY = 24 * 60 * 60 * 1000;

export function isNewer(a, b) {   // vrai si la version a est plus récente que b
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const x = pa[i] || 0, y = pb[i] || 0;
    if (x !== y) return x > y;
  }
  return false;
}

// Libellé lisible : « 1.0 » pour 1.0.0, « 1.0 r2 » pour 1.0.0.2.
export function shownVersion(version, name) {
  const rev = Number(String(version).split('.')[3] || 0);
  const base = name || String(version).split('.').slice(0, 2).join('.');
  return rev ? `${base} r${rev}` : base;
}
export function currentLabel() {
  const m = chrome.runtime.getManifest();
  return shownVersion(m.version, m.version_name);
}

// On n'ouvre que des liens du dépôt : un version.json altéré ne peut pas rediriger ailleurs.
const safe = (u, fallback) => (/^https:\/\/(github\.com|raw\.githubusercontent\.com)\/chpalitom09-bot\/ChromeOptimizer\//.test(u) ||
  /^https:\/\/chpalitom09-bot\.github\.io\/ChromeOptimizer\//.test(u)) ? u : fallback;

export async function getUpdateInfo() {
  const { update } = await chrome.storage.local.get('update');
  return update || null;
}

function setBadge(on) {
  chrome.action.setBadgeText({ text: on ? '↑' : '' });
  if (on) chrome.action.setBadgeBackgroundColor({ color: '#2f6fed' });
}

async function getJson(url) {
  const res = await fetch(url, { cache: 'no-store', credentials: 'omit', referrerPolicy: 'no-referrer' });
  return res.ok ? res.json() : null;
}

// force : ignore la limite d'une vérification par jour (bouton « Vérifier maintenant »).
export async function checkForUpdate({ force = false } = {}) {
  const current = chrome.runtime.getManifest().version;
  const prev = await getUpdateInfo();
  if (!force && prev && Date.now() - prev.checkedAt < DAY - 60000) return prev;

  // 1) Installation via le Chrome Web Store ou update_url : Chrome sait se mettre à jour seul.
  try {
    const r = await chrome.runtime.requestUpdateCheck();
    if (r && r.status === 'update_available') {
      const info = { status: 'store', latest: r.version || '', checkedAt: Date.now() };
      await chrome.storage.local.set({ update: info }); setBadge(true);
      return info;
    }
  } catch { /* extension chargée en mode développeur : on passe au dépôt */ }

  // 2) Extension chargée à la main : on compare avec version.json du dépôt (sinon manifest.json).
  let info = { status: 'error', latest: '', checkedAt: Date.now() };
  try {
    let j = null;
    try { j = await getJson(VERSION_URL); } catch { /* repli ci-dessous */ }
    if (!j || !j.version) j = await getJson(MANIFEST_URL);
    if (j && j.version) {
      const latest = String(j.version);
      info = {
        status: isNewer(latest, current) ? 'available' : 'current',
        latest,
        label: shownVersion(latest, j.version_name || j.name),
        notes: j.notes && typeof j.notes === 'object' ? j.notes : null,
        page: safe(j.page, PAGE_URL),
        download: safe(j.download, ''),
        checkedAt: Date.now()
      };
    }
  } catch { /* hors ligne : on réessaiera au prochain cycle */ }
  await chrome.storage.local.set({ update: info });
  setBadge(info.status === 'available');
  return info;
}

export async function clearBadgeIfCurrent() {
  const u = await getUpdateInfo();
  if (u && u.status === 'available' && !isNewer(u.latest, chrome.runtime.getManifest().version)) {
    await chrome.storage.local.set({ update: { ...u, status: 'current' } });
    setBadge(false);
  }
}
