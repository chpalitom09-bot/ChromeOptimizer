import { getSettings, saveSettings, getStats, resetStats, normalizeSites, MIN_IDLE, loadTune } from './lib.js';
import { tuneFactor } from './pulsa.js';
import { modelSize, resetModel } from './pulsa-store.js';
import { loadHistory, clearHistory } from './history.js';
import { ECO_TIERS, ecoProfile } from './eco.js';
import { initLang, mountLangSwitcher, t, tn, num, LANG } from './i18n.js';
import { checkForUpdate, getUpdateInfo, isNewer, PAGE_URL, currentLabel } from './update.js';

const $ = (id) => document.getElementById(id);
let toastTimer;

function toast() {
  const t = $('toast');
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 1400);
}

async function showStats() {
  const st = await getStats();
  $('stats').textContent = st.runs
    ? t('o.stats.line', { a: tn('n.slept', st.slept), b: tn('n.closed', st.closed) })
    : t('o.stats.none');
}

async function showModel() {
  const { hosts, intervals } = await modelSize();
  $('pulsaInfo').textContent = hosts ? tn('o.model.known', hosts, { m: intervals }) : t('o.model.none');
  const tune = await loadTune();
  const f = tuneFactor(tune);
  if (tune.n >= 5 && Math.abs(f - 1) > 0.02) {
    $('pulsaInfo').textContent += t('o.model.tune', { f: num(f, 2), kind: f < 1 ? t('o.model.cautious') : t('o.model.firm') });
  }
}

async function showHist() {
  const n = (await loadHistory()).length;
  $('histInfo').textContent = n ? tn('o.hist.n', n) : t('o.hist.empty');
}

async function showUpd() {
  const u = await getUpdateInfo(), cur = currentLabel(), curRaw = chrome.runtime.getManifest().version;
  const avail = u && u.status === 'available' && isNewer(u.latest, curRaw);
  $('updInfo').textContent = !u ? t('o.upd.never', { cur })
    : u.status === 'store' ? t('o.upd.store')
    : avail ? t('o.upd.avail', { latest: u.label || u.latest, cur })
    : u.status === 'current' ? t('o.upd.current', { cur })
    : t('o.upd.error', { cur });
  const link = $('updLink');
  link.href = (avail && u.page) || PAGE_URL;
  const notes = avail && u.notes ? (u.notes[LANG] || u.notes.en || u.notes.fr || []) : [];
  $('updNotes').innerHTML = '';
  for (const n of notes.slice(0, 8)) { const li = document.createElement('li'); li.textContent = n; $('updNotes').appendChild(li); }
}

const pct = (x) => Math.round(x * 100);

function showEcoTiers() {
  $('ecoTiers').innerHTML = [...ECO_TIERS].reverse()
    .map((x) => `<li>${t('eco.tier', { max: x.max, slow: pct(x.slow) })}${x.shed ? ' · ' + t('eco.tShed' + x.shed) : ''}</li>`).join('');
}

async function showEco(on) {
  const el = $('ecoInfo');
  if (!on) { el.textContent = ''; return; }
  try {
    const b = await navigator.getBattery();
    const level = Math.round(b.level * 100), p = ecoProfile(level, b.charging);
    el.textContent = b.charging ? t('eco.charging', { level })
      : p.slow ? t('eco.slow', { level, slow: pct(p.slow) })
      : t('eco.none', { level });
  } catch { el.textContent = t('eco.na'); }
}

function syncPulsaBox(algo) {
  const on = algo === 'pulsa';
  $('pulsaBox').disabled = !on;
  $('pulsaNeeds').hidden = on;
}


// ---------- États « Activé / Désactivé » à côté des interrupteurs ----------
function paintStates() {
  document.querySelectorAll('.switch input').forEach((cb) => {
    const em = cb.closest('.row-ctl').querySelector('.state');
    if (em) em.textContent = cb.checked ? t('on') : t('off');
  });
}
document.querySelectorAll('.switch input').forEach((cb) => cb.addEventListener('change', paintStates));

// ---------- Navigation façon « Paramètres » : catégories, sous-parties, recherche ----------
const panels = [...document.querySelectorAll('.panel')];
const cats = [...document.querySelectorAll('.cat')];
let currentCat = 'general';
let spy;

const fold = (s) => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

function buildSubnav() {
  cats.forEach((cat) => {
    const panel = panels.find((p) => p.dataset.cat === cat.dataset.cat);
    const ul = cat.querySelector('.subnav');
    ul.textContent = '';
    panel.querySelectorAll('.group').forEach((g) => {
      const li = document.createElement('li'), a = document.createElement('a');
      a.href = '#' + g.id; a.dataset.g = g.id;
      a.textContent = g.querySelector('.group-title').textContent;
      li.appendChild(a); ul.appendChild(li);
    });
  });
}

function watchGroups() {
  if (spy) spy.disconnect();
  spy = new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (!e.isIntersecting) return;
      document.querySelectorAll('.subnav a').forEach((a) => a.classList.toggle('on', a.dataset.g === e.target.id));
    });
  }, { rootMargin: '-15% 0px -70% 0px' });
  panels.find((p) => p.dataset.cat === currentCat).querySelectorAll('.group').forEach((g) => spy.observe(g));
}

function showCat(cat, groupId, push = true) {
  if (!cats.some((c) => c.dataset.cat === cat)) cat = 'general';
  currentCat = cat;
  clearSearch(false);
  panels.forEach((p) => { p.hidden = p.dataset.cat !== cat; });
  cats.forEach((c) => {
    const on = c.dataset.cat === cat;
    c.classList.toggle('active', on);
    on ? c.querySelector('.cat-link').setAttribute('aria-current', 'page') : c.querySelector('.cat-link').removeAttribute('aria-current');
  });
  document.querySelectorAll('.subnav a').forEach((a) => a.classList.toggle('on', a.dataset.g === groupId));
  if (push) history.replaceState(null, '', '#' + (groupId || cat));
  const target = groupId && document.getElementById(groupId);
  if (target) target.scrollIntoView({ block: 'start' }); else window.scrollTo(0, 0);
  watchGroups();
}

function route() {
  const h = decodeURIComponent(location.hash.slice(1));
  const g = h && document.getElementById(h);
  if (g && g.classList.contains('group')) showCat(g.closest('.panel').dataset.cat, h, false);
  else showCat(h || 'general', null, false);
}

document.getElementById('side').addEventListener('click', (e) => {
  const a = e.target.closest('a');
  if (!a) return;
  e.preventDefault();
  const id = a.getAttribute('href').slice(1);
  const g = document.getElementById(id);
  if (g && g.classList.contains('group')) showCat(g.closest('.panel').dataset.cat, id);
  else showCat(id);
});
window.addEventListener('hashchange', route);

// Recherche : filtre les lignes de toutes les catégories (sans accents ni majuscules).
const q = $('q');
function applySearch() {
  const words = fold(q.value.trim()).split(/\s+/).filter(Boolean);
  $('qClear').hidden = !q.value;
  document.body.classList.toggle('searching', words.length > 0);
  const rows = document.querySelectorAll('.row');
  if (!words.length) {
    rows.forEach((r) => { r.hidden = false; });
    document.querySelectorAll('.group').forEach((g) => { g.hidden = false; });
    $('noResult').hidden = true;
    panels.forEach((p) => { p.hidden = p.dataset.cat !== currentCat; });
    return;
  }
  let any = false;
  panels.forEach((p) => {
    const catName = p.querySelector('.cat-title').textContent;
    let panelHit = false;
    p.querySelectorAll('.group').forEach((g) => {
      const gName = g.querySelector('.group-title').textContent;
      let groupHit = false;
      g.querySelectorAll('.row').forEach((r) => {
        const hay = fold(`${catName} ${gName} ${r.textContent}`);
        const hit = words.every((w) => hay.includes(w));
        r.hidden = !hit; if (hit) groupHit = true;
      });
      g.hidden = !groupHit; if (groupHit) panelHit = true;
    });
    p.hidden = !panelHit; if (panelHit) any = true;
  });
  $('noResult').hidden = any;
  if (!any) $('noResult').textContent = t('o.search.none', { q: q.value.trim() });
}
function clearSearch(refocus) {
  if (!q.value) return;
  q.value = '';
  applySearch();
  if (refocus) q.focus();
}
q.addEventListener('input', applySearch);
q.addEventListener('keydown', (e) => { if (e.key === 'Escape' && q.value) { e.preventDefault(); clearSearch(false); } });
$('qClear').addEventListener('click', () => clearSearch(true));
document.addEventListener('keydown', (e) => {
  const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName);
  if ((e.key === '/' && !typing) || ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k')) { e.preventDefault(); q.focus(); q.select(); }
});

async function init() {
  await initLang();
  mountLangSwitcher($('langHost'), async () => {
    const s = await getSettings();
    showEcoTiers();
    await Promise.all([showEco(s.ecoOptimizer), showHist(), showUpd(), showModel(), showStats()]);
    paintStates(); buildSubnav(); applySearch();
    document.querySelectorAll('.subnav a').forEach((a) => a.classList.toggle('on', location.hash.slice(1) === a.dataset.g));
  });
  $('ver').textContent = currentLabel();
  const s = await getSettings();
  document.querySelector(`input[name=mode][value=${s.mode}]`).checked = true;
  $('idle').value = s.idleMinutes;
  $('algo').value = s.algorithm;
  $('hist').checked = !!s.history;
  $('adMem').checked = !!s.adaptMemory;
  $('adTune').checked = !!s.autoTune;
  $('adInt').checked = !!s.adaptiveInterval;
  $('eco').checked = !!s.ecoOptimizer;
  showEcoTiers();
  await showEco(s.ecoOptimizer);
  await showHist();
  $('upd').checked = !!s.updateCheck;
  await showUpd();
  $('sens').value = s.sensitivity;
  syncPulsaBox(s.algorithm);
  await showModel();
  $('dups').value = s.duplicates;
  $('sites').value = s.protectedSites.join('\n');
  await showStats();
  paintStates();
  buildSubnav();
  route();
}

document.querySelectorAll('input[name=mode]').forEach((r) =>
  r.addEventListener('change', async () => { await saveSettings({ mode: r.value }); toast(); }));

$('idle').addEventListener('change', async () => {
  const v = Math.min(1440, Math.max(MIN_IDLE, Math.round(Number($('idle').value) || 30)));
  $('idle').value = v;
  await saveSettings({ idleMinutes: v });
  toast();
});

$('algo').addEventListener('change', async () => { await saveSettings({ algorithm: $('algo').value }); syncPulsaBox($('algo').value); toast(); });
$('sens').addEventListener('change', async () => { await saveSettings({ sensitivity: $('sens').value }); toast(); });
$('resetModel').addEventListener('click', async () => { await resetModel(); await showModel(); toast(); });

$('adMem').addEventListener('change', async () => { await saveSettings({ adaptMemory: $('adMem').checked }); toast(); });
$('adTune').addEventListener('change', async () => { await saveSettings({ autoTune: $('adTune').checked }); toast(); });
$('adInt').addEventListener('change', async () => { await saveSettings({ adaptiveInterval: $('adInt').checked }); toast(); });

$('eco').addEventListener('change', async () => { const on = $('eco').checked; await saveSettings({ ecoOptimizer: on }); await showEco(on); toast(); });
$('upd').addEventListener('change', async () => { await saveSettings({ updateCheck: $('upd').checked }); toast(); });
$('updNow').addEventListener('click', async () => {
  $('updNow').disabled = true; $('updInfo').textContent = t('o.upd.checking');
  await checkForUpdate({ force: true }); await showUpd(); $('updNow').disabled = false;
});

$('hist').addEventListener('change', async () => { await saveSettings({ history: $('hist').checked }); toast(); });
$('clearHist').addEventListener('click', async () => { await clearHistory(); await showHist(); toast(); });

$('dups').addEventListener('change', async () => { await saveSettings({ duplicates: $('dups').value }); toast(); });

$('sites').addEventListener('change', async () => {
  const list = normalizeSites($('sites').value);
  $('sites').value = list.join('\n');
  await saveSettings({ protectedSites: list });
  toast();
});

$('reset').addEventListener('click', async () => { await resetStats(); await showStats(); toast(); });

init();
