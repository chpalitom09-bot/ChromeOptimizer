import { getSettings, saveSettings, getStats, analyze, optimize, hostOf, isProtectedSite, getContext } from './lib.js';
import { loadModel } from './pulsa-store.js';
import { loadHistory } from './history.js';

const $ = (id) => document.getElementById(id);
const plural = (n, one, many) => `${n} ${n > 1 ? many : one}`;
const gb = (bytes) => (bytes / 1073741824).toFixed(1).replace('.', ',');

/* ---------- Performances du système (lues uniquement popup ouverte) ---------- */

let prevCpu = null;

async function readMemory() {
  const m = await chrome.system.memory.getInfo();
  const used = m.capacity - m.availableCapacity;
  const pct = Math.round((used / m.capacity) * 100);
  $('memText').textContent = `${gb(used)} sur ${gb(m.capacity)} Go`;
  $('memBar').style.width = pct + '%';
}

async function readCpu() {
  const info = await chrome.system.cpu.getInfo();
  const total = info.processors.reduce((a, p) => ({ idle: a.idle + p.usage.idle, total: a.total + p.usage.total }), { idle: 0, total: 0 });
  if (prevCpu && total.total > prevCpu.total) {
    const pct = Math.round((1 - (total.idle - prevCpu.idle) / (total.total - prevCpu.total)) * 100);
    $('cpuText').textContent = pct + ' %';
    $('cpuBar').style.width = pct + '%';
  }
  prevCpu = total;
}

function tick() { readMemory().catch(() => {}); readCpu().catch(() => {}); }

/* ---------- Onglets ---------- */

async function refreshTabs() {
  const [settings, tabs] = await Promise.all([getSettings(), chrome.tabs.query({})]);
  const model = settings.algorithm === 'pulsa' ? await loadModel() : null;
  const plan = analyze(tabs, settings, Date.now(), model, await getContext(settings));
  $('open').textContent = tabs.length;
  $('sleeping').textContent = tabs.filter((t) => t.discarded).length;
  $('todo').textContent = plan.sleep.length + plan.close.length;
  const dup = settings.duplicates === 'off' ? 'doublons ignorés' : plural(plan.close.length, 'doublon', 'doublons');
  $('hint').textContent = settings.algorithm === 'pulsa'
    ? `PULSA : ${plural(plan.sleep.length, 'onglet peu susceptible', 'onglets peu susceptibles')} d'être rouvert${plan.sleep.length > 1 ? 's' : ''}, ${dup}`
    : `${plural(plan.sleep.length, 'inactif', 'inactifs')} depuis ${settings.idleMinutes} min ou plus, ${dup}`;
}

/* ---------- PULSA on/off ---------- */

function showPulsa(s) {
  $('pulsaOn').checked = s.algorithm === 'pulsa';
  $('pulsaHint').textContent = s.algorithm === 'pulsa'
    ? 'Les onglets sont triés selon leur probabilité d\'être rouverts.'
    : `Désactivé : mise en veille après ${s.idleMinutes} min d'inactivité.`;
}

/* ---------- Sites : favoris et récents ---------- */

const ago = (ts) => {
  const m = Math.max(0, Math.round((Date.now() - ts) / 60000));
  if (m < 1) return "à l'instant";
  if (m < 60) return `il y a ${m} min`;
  const h = Math.round(m / 60);
  if (h < 24) return `il y a ${h} h`;
  return `il y a ${Math.round(h / 24)} j`;
};

async function openSite(host) {
  const tabs = await chrome.tabs.query({});
  const hit = tabs.find((t) => hostOf(t.url) === host);
  if (hit) {
    await chrome.tabs.update(hit.id, { active: true });
    await chrome.windows.update(hit.windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url: 'https://' + host });
  }
  window.close();
}

async function toggleFavorite(host) {
  const s = await getSettings();
  const favorites = s.favorites.includes(host) ? s.favorites.filter((h) => h !== host) : [...s.favorites, host];
  await saveSettings({ favorites });
  await refreshSites();
}

async function refreshSites() {
  const [s, hist, tabs] = await Promise.all([getSettings(), loadHistory(), chrome.tabs.query({})]);
  const state = {};
  tabs.forEach((t) => { const h = hostOf(t.url); if (h) state[h] = state[h] === 'open' ? 'open' : (t.discarded ? 'sleep' : 'open'); });

  const favs = $('favs'), list = $('recent');
  favs.replaceChildren(); list.replaceChildren();

  s.favorites.forEach((host) => {
    const wrap = document.createElement('span'); wrap.className = 'chip';
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'chip-open'; b.title = `Ouvrir ${host}`; b.textContent = host;
    b.addEventListener('click', () => openSite(host));
    const x = document.createElement('button');
    x.type = 'button'; x.className = 'chip-x'; x.textContent = '×';
    x.setAttribute('aria-label', `Retirer le raccourci ${host}`); x.title = 'Retirer le raccourci';
    x.addEventListener('click', () => toggleFavorite(host));
    wrap.append(b, x); favs.append(wrap);
  });

  const recents = hist.filter((x) => !s.favorites.includes(x.host)).slice(0, 6);
  recents.forEach((x) => {
    const li = document.createElement('li');
    const btn = document.createElement('button');
    btn.type = 'button'; btn.className = 'site'; btn.title = `Ouvrir ${x.host}`;
    const ico = document.createElement('span'); ico.className = 'ico'; ico.textContent = x.host[0] || '?';
    const txt = document.createElement('span'); txt.className = 'txt';
    const name = document.createElement('b'); name.textContent = x.host;
    const sub = document.createElement('small');
    const st = state[x.host];
    sub.textContent = `${st === 'open' ? 'ouvert' : st === 'sleep' ? 'en veille' : ago(x.last)} · ${plural(x.n, 'visite', 'visites')}`;
    txt.append(name, sub); btn.append(ico, txt);
    btn.addEventListener('click', () => openSite(x.host));
    const star = document.createElement('button');
    star.type = 'button'; star.className = 'star'; star.textContent = '☆';
    star.setAttribute('aria-pressed', 'false'); star.setAttribute('aria-label', `Épingler ${x.host} en raccourci`); star.title = 'Épingler en raccourci';
    star.addEventListener('click', () => toggleFavorite(x.host));
    li.append(btn, star); list.append(li);
  });

  $('sitesCard').hidden = !s.history && !s.favorites.length;
  $('sitesHint').textContent = !s.history ? "L'historique est désactivé dans les réglages."
    : (!recents.length && !s.favorites.length ? 'Les sites que vous visitez apparaîtront ici.' : '');
}

async function refreshTotals() {
  const st = await getStats();
  $('totals').textContent = st.runs
    ? `Depuis le début : ${plural(st.slept, 'onglet mis en veille', 'onglets mis en veille')}, ${plural(st.closed, 'doublon fermé', 'doublons fermés')}`
    : 'Aucune optimisation pour le moment';
}

async function refreshProtect() {
  const btn = $('protect');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const host = tab && /^https?:/i.test(tab.url || '') ? hostOf(tab.url) : '';
  if (!host) { btn.disabled = true; btn.textContent = 'Protéger ce site'; return; }
  const settings = await getSettings();
  const on = isProtectedSite(tab.url, settings.protectedSites);
  btn.disabled = false;
  btn.dataset.host = host;
  btn.dataset.on = on ? '1' : '';
  btn.textContent = on ? `Ne plus protéger ${host}` : `Protéger ${host}`;
  btn.title = btn.textContent;
}

/* ---------- Actions ---------- */

$('run').addEventListener('click', async () => {
  const btn = $('run');
  btn.disabled = true; btn.textContent = 'Optimisation…'; $('result').textContent = '';
  try {
    const { slept, closed } = await optimize({ manual: true });
    $('result').textContent = slept || closed
      ? `${plural(slept, 'onglet mis en veille', 'onglets mis en veille')}, ${plural(closed, 'doublon fermé', 'doublons fermés')}.`
      : 'Rien à optimiser avec ces réglages.';
  } catch {
    $('result').textContent = "L'optimisation a échoué. Réessayez.";
  }
  btn.disabled = false; btn.textContent = 'Optimiser maintenant';
  await Promise.all([refreshTabs(), refreshTotals()]);
  setTimeout(tick, 1200);
});

$('pulsaOn').addEventListener('change', async (e) => {
  const s = await saveSettings({ algorithm: e.target.checked ? 'pulsa' : 'classic' });
  showPulsa(s);
  await refreshTabs();
});

$('auto').addEventListener('change', async (e) => {
  await saveSettings({ mode: e.target.checked ? 'auto' : 'manual' });
});

$('protect').addEventListener('click', async () => {
  const btn = $('protect'), host = btn.dataset.host;
  if (!host) return;
  const s = await getSettings();
  const list = btn.dataset.on ? s.protectedSites.filter((d) => host !== d && !host.endsWith('.' + d)) : [...new Set([...s.protectedSites, host])];
  await saveSettings({ protectedSites: list });
  await Promise.all([refreshProtect(), refreshTabs()]);
});

$('openOptions').addEventListener('click', () => chrome.runtime.openOptionsPage());

/* ---------- Démarrage ---------- */

(async () => {
  const s = await getSettings();
  $('auto').checked = s.mode === 'auto';
  showPulsa(s);
  await Promise.all([refreshTabs(), refreshTotals(), refreshProtect(), refreshSites()]);
  tick();
  setInterval(tick, 1500);   // s'arrête avec la fermeture du popup
})();
