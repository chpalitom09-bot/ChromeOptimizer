// Stockage local du modèle PULSA et suivi des changements d'onglet.
// Seuls le domaine et des durées sont conservés. Aucune URL complète, aucun titre.
import {
  emptyRecord, recordReturn, recordCensored, recordSleepOutcome, recordSleepKept
} from './pulsa.js';
import { recordVisit } from './history.js';
import { emptyTune, updateTune } from './pulsa.js';
import { emptyBrain, learn } from './brain.js';

async function tuneOutcome(minutes) {
  const { settings, pulsaTune } = await chrome.storage.local.get(['settings', 'pulsaTune']);
  if (settings && settings.autoTune === false) return;
  await chrome.storage.local.set({ pulsaTune: updateTune(pulsaTune || emptyTune(), minutes) });
}

// Compteurs PULSA 2.0 : hit = rechargé à temps, miss = revenu trop tôt, waste = rechargé pour rien.
async function bumpP2(k) {
  const { pulsa2 } = await chrome.storage.local.get('pulsa2');
  const v = { hit: 0, miss: 0, waste: 0, ...(pulsa2 || {}) };
  v[k]++;
  if (v.hit + v.miss > 60) { v.hit *= 0.8; v.miss *= 0.8; }   // oubli progressif
  await chrome.storage.local.set({ pulsa2: v });
}
export async function loadP2() { const { pulsa2 } = await chrome.storage.local.get('pulsa2'); return pulsa2 || { hit: 0, miss: 0, waste: 0 }; }
export async function loadSnap() { const st = await getState(); return { pre: st.pre, ctx: st.ctx }; }
export async function loadBrain() { const { brain } = await chrome.storage.local.get('brain'); return brain || emptyBrain(); }

// 2.1 : le cerveau apprend ce retour (avant l'enregistrement de l'intervalle) et note la destination.
async function brainLearn(host, c, minutes) {
  const key = PREFIX + host;
  const cur = await chrome.storage.local.get([key, GLOBAL_KEY, 'brain', 'settings']);
  const s = cur.settings || {};
  if (s.algorithm === 'classic' || s.algorithm === 'pulsa' || s.brain === false) return;
  const rec = cur[key] || emptyRecord();
  const brain = learn(cur.brain || emptyBrain(), c, rec, cur[GLOBAL_KEY] || emptyRecord(), minutes);
  await chrome.storage.local.set({ brain, [key]: rec });
}

const PREFIX = 'p:';
const GLOBAL_KEY = PREFIX + '*';
const MAX_HOSTS = 300;

function hostOf(url) {
  try { return new URL(url).hostname.toLowerCase().replace(/^www\./, ''); }
  catch { return ''; }
}
const isWeb = (url) => /^https?:/i.test(url || '');

/* ---------- Modèle ---------- */

export async function loadModel() {
  const all = await chrome.storage.local.get(null);
  const hosts = {};
  for (const [k, v] of Object.entries(all)) {
    if (k.startsWith(PREFIX) && k !== GLOBAL_KEY) hosts[k.slice(PREFIX.length)] = v;
  }
  return { hosts, glob: all[GLOBAL_KEY] || emptyRecord() };
}

export async function modelSize() {
  const m = await loadModel();
  return { hosts: Object.keys(m.hosts).length, intervals: Object.values(m.hosts).reduce((a, r) => a + r.iv.length, 0) };
}

export async function resetModel() {
  const all = await chrome.storage.local.get(null);
  const keys = Object.keys(all).filter((k) => k.startsWith(PREFIX));
  if (keys.length) await chrome.storage.local.remove(keys);
  await chrome.storage.local.remove('pulsaTune');
  await chrome.storage.local.remove(['pulsa2', 'brain']);
  await chrome.storage.session.remove(['pulsaTabs', 'cycleStage']);
}

// Garde les domaines les plus récents quand il y en a trop.
export async function pruneModel() {
  const m = await loadModel();
  const names = Object.keys(m.hosts);
  if (names.length <= MAX_HOSTS) return;
  names.sort((a, b) => (m.hosts[a].last || 0) - (m.hosts[b].last || 0));
  const drop = names.slice(0, names.length - MAX_HOSTS + 50).map((h) => PREFIX + h);
  await chrome.storage.local.remove(drop);
}

async function update(host, fn) {
  const keys = host ? [PREFIX + host, GLOBAL_KEY] : [GLOBAL_KEY];
  const cur = await chrome.storage.local.get(keys);
  const out = {};
  if (host) { const r = cur[PREFIX + host] || emptyRecord(); fn(r, false); out[PREFIX + host] = r; }
  const g = cur[GLOBAL_KEY] || emptyRecord();
  fn(g, true);
  out[GLOBAL_KEY] = g;
  await chrome.storage.local.set(out);
}

/* ---------- État éphémère (service worker non persistant) ---------- */

async function getState() {
  const { pulsaTabs } = await chrome.storage.session.get('pulsaTabs');
  const st = pulsaTabs || { left: {}, host: {}, active: {}, slept: {} };
  st.plan = st.plan || {}; st.pre = st.pre || {}; st.ctx = st.ctx || {};   // 2.0 : rechargements prévus / effectués
  return st;
}
const setState = (s) => chrome.storage.session.set({ pulsaTabs: s });

// Les événements sont traités l'un après l'autre pour éviter les écritures concurrentes.
let chain = Promise.resolve();
const queue = (fn) => { const p = chain.then(fn); chain = p.catch(() => {}); return p.catch(() => undefined); };

/* ---------- Événements ---------- */

export function trackActivated({ tabId, windowId }) {
  return queue(async () => {
    const now = Date.now();
    const st = await getState();
    const prev = st.active[windowId];

    if (prev !== undefined && prev !== tabId) {
      st.left[prev] = now;
      let B = '', n = 0;                          // 2.1 : contexte du départ (heure, jour, nb d'onglets, destination)
      try { const nt = await chrome.tabs.get(tabId); B = isWeb(nt.url) ? hostOf(nt.url) : ''; n = (await chrome.tabs.query({})).length; } catch { /* ignoré */ }
      const d = new Date(now);
      st.ctx[prev] = { h: d.getHours() + d.getMinutes() / 60, d: d.getDay(), n, B };
    }

    let host = st.host[tabId] || '';
    try {
      const tab = await chrome.tabs.get(tabId);
      host = isWeb(tab.url) ? hostOf(tab.url) : '';
      st.host[tabId] = host;
    } catch { /* onglet disparu */ }

    if (host) await recordVisit(host, now);
    if (host && st.left[tabId]) {
      const minutes = (now - st.left[tabId]) / 60000;
      if (minutes >= 0.25) {
        if (st.ctx[tabId]) await brainLearn(host, st.ctx[tabId], minutes);
        await update(host, (r) => recordReturn(r, minutes, now));
      }
    }
    if (host && st.slept[tabId]) {
      const asleep = (now - st.slept[tabId]) / 60000;
      if (st.pre[tabId] > 0) {                   // 2.0 : l'onglet avait été rechargé à l'avance → réussite
        await update(host, (r) => recordSleepKept(r, now)); await tuneOutcome(Infinity); await bumpP2('hit');
      } else {
        await update(host, (r) => recordSleepOutcome(r, asleep, now)); await tuneOutcome(asleep);
        if (st.plan[tabId]) await bumpP2('miss');   // revenu avant le rechargement prévu
      }
    }
    delete st.plan[tabId]; delete st.pre[tabId]; delete st.ctx[tabId];
    delete st.slept[tabId];
    delete st.left[tabId];
    st.active[windowId] = tabId;
    await setState(st);
  });
}

export function trackRemoved(tabId) {
  return queue(async () => {
    const now = Date.now();
    const st = await getState();
    const host = st.host[tabId];
    if (host && st.left[tabId]) {
      const minutes = (now - st.left[tabId]) / 60000;
      if (minutes >= 1) await update(host, (r) => recordCensored(r, minutes, now));
    }
    if (host && st.slept[tabId]) { await update(host, (r) => recordSleepKept(r, now)); await tuneOutcome(Infinity); }
    if (st.pre[tabId] > 0) await bumpP2('waste');    // rechargé pour rien
    delete st.plan[tabId]; delete st.pre[tabId]; delete st.ctx[tabId];
    delete st.left[tabId]; delete st.host[tabId]; delete st.slept[tabId];
    for (const w of Object.keys(st.active)) if (st.active[w] === tabId) delete st.active[w];
    await setState(st);
  });
}

// Appelé par optimize() juste après une mise en veille.
export function markSlept(ids, wake = {}) {
  return queue(async () => {
    const st = await getState();
    const now = Date.now();
    ids.forEach((id) => { st.slept[id] = now; if (st.pre[id] > 0) st.pre[id] = -st.pre[id];   // déjà rechargé une fois : plus de rechargement
      if (wake[id] != null) st.plan[id] = now + wake[id] * 60000; });
    await setState(st);
  });
}

// 2.0 : prochain rechargement prévu (timestamp) ou 0.
export function nextWake() {
  return queue(async () => { const v = Object.values((await getState()).plan); return v.length ? Math.min(...v) : 0; }).then((x) => x || 0);
}

// 2.0 : retire les plans échus (tolérance 20 s) et renvoie les onglets à recharger.
export function takeDue(now = Date.now()) {
  return queue(async () => {
    const st = await getState();
    const due = Object.keys(st.plan).filter((id) => st.plan[id] <= now + 20000).map(Number);
    due.forEach((id) => { delete st.plan[id]; st.pre[id] = now; });
    await setState(st);
    return due;
  }).then((x) => x || []);
}

// 2.0 : le rechargement n'a pas eu lieu (onglet disparu ou RAM saturée) : on oublie le marquage.
export function unmarkPre(ids) {
  return queue(async () => { const st = await getState(); ids.forEach((id) => { delete st.pre[id]; }); await setState(st); });
}

// Amorce l'état au démarrage : on sait quel onglet est actif, rien d'autre.
export function seedActive() {
  return queue(async () => {
    const st = await getState();
    const tabs = await chrome.tabs.query({});
    for (const t of tabs) {
      if (isWeb(t.url)) st.host[t.id] = hostOf(t.url);
      if (t.active) st.active[t.windowId] = t.id;
      else if (st.left[t.id] === undefined && t.lastAccessed) st.left[t.id] = t.lastAccessed;
    }
    await setState(st);
  });
}
