// Simulateur : PULSA 2.0 seul vs 2.1 (avec cerveau) sur un utilisateur fictif dont les habitudes
// dépendent de l'heure et de l'onglet de destination. Usage : node bench/simulate-brain.mjs [événements] [graine]
import { emptyRecord, recordReturn } from '../pulsa.js';
import { decide } from '../pulsa2.js';
import { emptyBrain, learn, feat } from '../brain.js';

const N = Number(process.argv[2]) || 4000;
let seed = Number(process.argv[3]) || 7;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296);
const gauss = () => Math.sqrt(-2 * Math.log(rnd() + 1e-9)) * Math.cos(2 * Math.PI * rnd());
const HOSTS = ['mail', 'video', 'docs', 'news', 'chat', 'shop'];
const BASE = { mail: 2.6, video: 3.0, docs: 2.2, news: 3.4, chat: 1.5, shop: 3.7 };   // ln(minutes)
function truth(A, B, h, d) {
  let m = BASE[A];
  if (A === 'video' && h >= 18) m -= 1.0;           // le soir on enchaîne les vidéos
  if (A === 'mail' && h >= 6 && h < 11) m -= 0.7;    // le matin on consulte le mail souvent
  if (A === 'news' && (d === 0 || d === 6)) m += 0.8;
  if (A === 'mail' && B === 'docs') m -= 1.0;        // vers Docs, retour rapide sur Mail
  if (A === 'video' && B === 'chat') m -= 0.7;
  if (A === 'shop' && B === 'mail') m += 0.5;
  return Math.exp(m + 0.28 * gauss());
}

const recs = {}, glob = emptyRecord(); let brain = emptyBrain(), clock = 8 * 60;
const mk = () => ({ sleep: 0, miss: 0, gain: 0, n: 0 });
const stat = { 'PULSA 2.0 prudent': mk(), 'PULSA 2.0 équilibré': mk(), 'PULSA 2.0 performance': mk(), 'PULSA 2.1 équilibré': mk(), 'PULSA 2.1 performance': mk() };
const SENS = { prudent: 'prudent', 'équilibré': 'balanced', performance: 'aggressive' };
const T = 3, WARM = 600;
for (let e = 0; e < N; e++) {
  clock += 30 + rnd() * 150;
  const h = (clock / 60) % 24, d = Math.floor(clock / 1440) % 7;
  const A = HOSTS[Math.floor(rnd() * HOSTS.length)];
  let B = HOSTS[Math.floor(rnd() * HOSTS.length)]; if (B === A) B = HOSTS[(HOSTS.indexOf(A) + 1) % HOSTS.length];
  const c = { h, d, n: 5 + Math.floor(rnd() * 20), B };
  const x = truth(A, B, h, d), rec = recs[A] || (recs[A] = emptyRecord());
  if (e >= WARM && x > T) {
    const { f, lb } = feat(c, rec, glob);
    const base = { sens: 'balanced', p2: null, preloaded: false, canPreload: true, factor: 1 };
    for (const k of Object.keys(stat)) {
      const s = stat[k], r = decide(rec, glob, T, { ...base, sens: SENS[k.split(' ')[2]], brain: k.includes('2.1') ? { model: brain, f, lb } : null });
      s.n++;
      if (r.act !== 'sleep') continue;
      s.sleep++;
      const wake = r.wake != null ? T + r.wake : Infinity;
      if (x < wake) { s.miss++; s.gain += x - T; } else s.gain += wake - T;   // gain : minutes de RAM libérées
    }
  }
  learn(brain, c, rec, glob, x);          // avant recordReturn (le cerveau ne doit pas voir la réponse)
  recordReturn(rec, x); recordReturn(glob, x);
}
console.log(`événements évalués : ${stat['PULSA 2.0 équilibré'].n} — cerveau entraîné sur ${brain.n} retours, calibration tête 20 % = ${(brain.cov * 100).toFixed(0)} %`);
for (const [k, s] of Object.entries(stat)) {
  console.log(`${k.padEnd(22)} : mises en veille ${s.sleep}, ratés ${(100 * s.miss / Math.max(1, s.sleep)).toFixed(1)} %, ` +
    `veille moyenne ${(s.gain / s.n).toFixed(2)} min/onglet (${(s.gain / Math.max(1, s.sleep)).toFixed(1)} min par veille)`);
}
