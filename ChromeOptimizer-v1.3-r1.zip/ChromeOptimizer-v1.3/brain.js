// PULSA 2.1 — « cerveau » : mini-modèle qui apprend EN DIRECT chez l'utilisateur (≈ 40 paramètres, quelques Ko).
// Module pur. Il prédit le délai de retour en tenant compte du CONTEXTE que PULSA 2.0 ignore :
// heure, jour, nombre d'onglets, et surtout l'onglet vers lequel tu es parti (« après Docs, je rouvre Mail vite »).
//
// Modèle : régression par quantiles (perte « pinball »), une tête par risque de rater (10, 20, 30 %).
//   cible = ln(délai de retour) − ln(délai habituel du site)   → le modèle ne corrige que l'écart à l'habitude
//   entrée = 11 variables ; apprentissage : un pas de gradient à chaque retour observé.
// Garde-fous : mélange borné avec la méthode empirique de 2.0, confiance qui monte avec l'expérience,
// et chute si la tête 20 % rate trop souvent (calibration mesurée en continu).
// Vie privée : seulement des noms de domaine, l'heure et des durées.

export const HEADS = [0.1, 0.2, 0.3];
export const NF = 11;
export const BRAIN = { ready: 30, maxConf: 0.6, confN: 150, lr: 0.04, l2: 1e-3, clipY: 3, pairCap: 8, pairMem: 12 };
const BIAS0 = [-0.6, -0.4, -0.25];   // départ : un peu avant le délai habituel
const clip = (x, a, b) => Math.min(b, Math.max(a, x));

export function emptyBrain() {
  return { w: HEADS.map((_, k) => { const a = new Array(NF).fill(0); a[0] = BIAS0[k]; return a; }), n: 0, cov: 0.2 };
}

function medLn(iv) {
  const p = iv.filter((x) => x > 0).map(Math.log).sort((a, b) => a - b);
  return p.length >= 3 ? p[p.length >> 1] : null;
}
// Délai « habituel » (ln minutes) : médiane du site, sinon globale, sinon 20 min.
export function baseLn(rec, glob) {
  const a = rec && medLn(rec.iv); if (a != null) return a;
  const g = glob && medLn(glob.iv); return g != null ? g : Math.log(20);
}

// Contexte à l'instant où l'on quitte l'onglet : { h: heure locale 0–24, d: jour 0–6, n: nb d'onglets, B: domaine de destination }.
export function feat(c, rec, glob) {
  const lb = baseLn(rec, glob);
  const tr = rec && rec.tr && rec.tr[c.B];
  const conf = tr ? tr[0] / (tr[0] + 3) : 0;
  const dd = tr ? clip(tr[1] - lb, -2, 2) : 0;
  let last = 0;
  if (rec && rec.iv.length) for (let i = rec.iv.length - 1; i >= 0; i--) if (rec.iv[i] > 0) { last = clip(Math.log(rec.iv[i]) - lb, -2, 2); break; }
  const a = (2 * Math.PI * c.h) / 24;
  const f = [1, Math.sin(a), Math.cos(a), Math.sin(2 * a), Math.cos(2 * a), c.d === 0 || c.d === 6 ? 1 : 0,
    Math.log(Math.max(1, c.n)) - 2, dd, conf, dd * conf, last];
  return { f, lb };
}

const dot = (w, f) => { let s = 0; for (let i = 0; i < NF; i++) s += w[i] * f[i]; return s; };

// Résidu prédit au risque q (interpolé entre les têtes).
export function residual(model, f, q) {
  const p = model.w.map((w) => dot(w, f));
  if (q <= HEADS[0]) return p[0];
  if (q >= HEADS[2]) return p[2];
  const k = q < HEADS[1] ? 0 : 1, u = (q - HEADS[k]) / (HEADS[k + 1] - HEADS[k]);
  return p[k] + u * (p[k + 1] - p[k]);
}

export function train(model, f, yRes) {
  const y = clip(yRes, -BRAIN.clipY, BRAIN.clipY);
  const lr = BRAIN.lr / Math.sqrt(1 + model.n / 100);
  const preds = model.w.map((w) => dot(w, f));
  HEADS.forEach((q, k) => {
    const g = y < preds[k] ? 1 - q : -q;                  // dérivée de la perte pinball
    const w = model.w[k];
    for (let i = 0; i < NF; i++) {
      w[i] = clip(w[i] - lr * g * f[i], -3, 3);
      if (i) w[i] *= 1 - BRAIN.l2;                        // léger rappel vers 0 : pas d'emballement
    }
  });
  model.cov = 0.95 * model.cov + 0.05 * (y < preds[1] ? 1 : 0);   // la tête 20 % doit rater ~20 % du temps
  model.n++;
  return model;
}

// Mémorise « depuis ce site, en partant vers B, retour en ~x min » (moyenne glissante en ln).
export function notePair(rec, B, minutes) {
  if (!B) return;
  rec.tr = rec.tr || {};
  const y = Math.log(Math.max(0.1, minutes)), e = rec.tr[B] || [0, y];
  e[0]++; e[1] += (y - e[1]) / Math.min(e[0], BRAIN.pairMem);
  rec.tr[B] = e;
  const ks = Object.keys(rec.tr);
  if (ks.length > BRAIN.pairCap) { ks.sort((a, b) => rec.tr[a][0] - rec.tr[b][0]); delete rec.tr[ks[0]]; }
}

// Un retour observé : apprend, puis met à jour les stats de destination. À appeler AVANT recordReturn.
export function learn(model, c, rec, glob, minutes) {
  const { f, lb } = feat(c, rec, glob);
  train(model, f, Math.log(Math.max(0.1, minutes)) - lb);
  if (rec) notePair(rec, c.B, minutes);
  return model;
}

// Confiance dans le cerveau (0 → 0,6) : expérience × calibration.
export function confidence(model) {
  if (!model || model.n < BRAIN.ready) return 0;
  const exp = Math.min(BRAIN.maxConf, (model.n / BRAIN.confN) * BRAIN.maxConf);
  const cal = model.cov > 0.2 ? Math.max(0, 1 - (model.cov - 0.2) * 4) : 1;   // trop de retours avant la prédiction : on s'efface
  return exp * cal;
}

// Corrige l'attente (minutes) de PULSA 2.0 avec l'avis du cerveau. Borné : jamais < 0,6× ni > 1,5×.
export function blendWait(wait, idleMin, q, b) {
  const c = confidence(b.model);
  if (!c) return wait;
  const total = Math.exp(b.lb + residual(b.model, b.f, q));   // délai de retour total prédit
  const waitB = total - idleMin;
  if (!(waitB > 0)) return wait;                                // le cerveau pense que c'est déjà dépassé : on garde 2.0
  const mix = Math.exp((1 - c) * Math.log(wait) + c * Math.log(waitB));
  return clip(mix, wait * 0.6, wait * 1.5);
}
