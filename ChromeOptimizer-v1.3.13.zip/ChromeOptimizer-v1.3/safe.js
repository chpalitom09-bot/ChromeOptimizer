const KEY = 'audioSeen';
export const RECENT_MS = 5 * 60 * 1000;
const KEEP_MS = 60 * 60 * 1000;

export const CALL_HOSTS = [
  { host: 'meet.google.com' },
  { host: 'voice.google.com' },
  { host: 'teams.microsoft.com' },
  { host: 'teams.live.com' },
  { host: 'zoom.us', path: /^\/(wc|j|s)\// },
  { host: 'whereby.com' },
  { host: 'webex.com' },
  { host: 'meet.jit.si' },
  { host: 'web.skype.com' },
  { host: 'bluejeans.com' },
  { host: 'gotomeeting.com' },
  { host: 'around.co' }
];

export function isCallUrl(url) {
  let u;
  try { u = new URL(url); } catch { return false; }
  if (u.protocol !== 'https:' && u.protocol !== 'http:') return false;
  const h = u.hostname.toLowerCase();
  return CALL_HOSTS.some((c) => (h === c.host || h.endsWith('.' + c.host)) && (!c.path || c.path.test(u.pathname)));
}

export function safeReason(t, seen, now = Date.now()) {
  if (t.audible) return 'sound';
  const ts = seen && seen[t.id];
  if (ts && now - ts < RECENT_MS) return 'recent';
  if (isCallUrl(t.url || '')) return 'call';
  return null;
}

export async function loadAudioSeen() {
  try { const { [KEY]: m } = await chrome.storage.session.get(KEY); return m || {}; } catch { return {}; }
}

let chain = Promise.resolve();
function update(fn) {
  chain = chain.then(async () => {
    const m = await loadAudioSeen();
    fn(m);
    const cut = Date.now() - KEEP_MS;
    for (const k of Object.keys(m)) if (m[k] < cut) delete m[k];
    await chrome.storage.session.set({ [KEY]: m });
  }).catch(() => {});
  return chain;
}
export const markAudio = (id) => update((m) => { m[id] = Date.now(); });
export const forgetAudio = (id) => update((m) => { delete m[id]; });
export async function seedAudio() {
  const tabs = await chrome.tabs.query({ audible: true });
  if (tabs.length) await update((m) => { tabs.forEach((t) => { m[t.id] = Date.now(); }); });
}
