import { AO1Engine } from './ao1.js';
const antivirusEngine = new AO1Engine();
import { getSettings, saveSettings, optimize } from './lib.js';
import { armPreload, runPreload, PRELOAD_ALARM } from './preload.js';
import { trackActivated, trackRemoved, seedActive } from './pulsa-store.js';
import { CYCLE_STEPS, nextStage } from './pulsa.js';
import { checkForUpdate, clearBadgeIfCurrent } from './update.js';
import { getEco, ECO_NONE } from './eco.js';
import { markAudio, forgetAudio, seedAudio } from './safe.js';
import { getOnePw, startOnePw, stopOnePw, discardIfEligible, refreshBadge } from './onepw.js';
import { getPower, POWER_KEY } from './power.js';

const ALARM = 'chromeoptimizer-cycle';
const BSWP_ID = 'bswp';
const PRELOAD = PRELOAD_ALARM;

// Icône grisée + badge OFF quand l'extension est éteinte
async function setOffIcon(off) {
  try {
    if (!off) {
      await chrome.action.setIcon({ path: { 16: 'icons/icon16.png', 32: 'icons/icon32.png', 48: 'icons/icon48.png', 128: 'icons/icon128.png' } });
      await chrome.action.setTitle({ title: 'ChromeOptimizer' });
      return;
    }
    const imageData = {};
    for (const sz of [16, 32, 48]) {
      const bmp = await createImageBitmap(await (await fetch(chrome.runtime.getURL(`icons/icon${sz}.png`))).blob());
      const c = new OffscreenCanvas(sz, sz), x = c.getContext('2d');
      x.filter = 'grayscale(1) opacity(.45)'; x.drawImage(bmp, 0, 0, sz, sz);
      imageData[sz] = x.getImageData(0, 0, sz, sz);
    }
    await chrome.action.setIcon({ imageData });
    await chrome.action.setTitle({ title: 'ChromeOptimizer (OFF)' });
  } catch { /* icône par défaut conservée */ }
}

// Interrupteur général : coupe (ou rétablit) toutes les fonctions en une fois
async function applyPower() {
  if (!(await getPower())) {
    await Promise.all([chrome.alarms.clear(ALARM), chrome.alarms.clear(UPDATE_ALARM), chrome.alarms.clear(PRELOAD)]).catch(() => {});
    await chrome.storage.session.remove(['cycleStage', 'eco']).catch(() => {});
    try { await stopOnePw(); } catch { /* ignore */ }
    await syncBswp().catch(() => {});
    await syncEco().catch(() => {});
    await setOffIcon(true);
    chrome.action.setBadgeText({ text: 'OFF' });
    chrome.action.setBadgeBackgroundColor({ color: '#6b6b73' });
  } else {
    await setOffIcon(false);
    chrome.action.setBadgeText({ text: '' });
    syncEco().catch(() => {}); syncAlarm(); syncUpdateAlarm(); syncBswp().catch(() => {});
    seedActive(); armPreload().catch(() => {}); clearBadgeIfCurrent(); refreshBadge(); seedAudio().catch(() => {});
  }
}

async function syncBswp() {
  const { bswp: wanted, ecoOptimizer } = await getSettings();
  const bswp = (await getPower()) && wanted && !(ecoOptimizer && (await getEco()).shed >= 2);
  const registered = (await chrome.scripting.getRegisteredContentScripts({ ids: [BSWP_ID] })).length > 0;
  const granted = await chrome.permissions.contains({ origins: ['http://*/*', 'https://*/*'] });
  if (bswp && granted && !registered) {
    await chrome.scripting.registerContentScripts([{ id: BSWP_ID, matches: ['http://*/*', 'https://*/*'], js: ['bswp.js'], runAt: 'document_idle', persistAcrossSessions: true }]);
  } else if ((!bswp || !granted) && registered) {
    await chrome.scripting.unregisterContentScripts({ ids: [BSWP_ID] });
  }
}

async function syncEco() {
  const { ecoOptimizer: wantEco } = await getSettings();
  const ecoOptimizer = wantEco && (await getPower());
  const has = (await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] })).length > 0;
  if (ecoOptimizer && !has) {
    await chrome.offscreen.createDocument({ url: 'offscreen.html', reasons: ['BATTERY_STATUS'], justification: 'Lire le niveau de batterie pour ralentir les cycles quand elle est faible.' });
  } else if (!ecoOptimizer) {
    if (has) await chrome.offscreen.closeDocument();
    await chrome.storage.session.remove('eco');
    await syncBswp();
  }
}

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (sender.id !== chrome.runtime.id || !msg || msg.type !== 'eco-battery') return;
  (async () => {
    const { ecoOptimizer } = await getSettings();
    if (!ecoOptimizer) return;
    const before = await getEco();
    const eco = { level: Number(msg.level) || 0, charging: !!msg.charging, slow: Number(msg.slow) || 0, shed: Number(msg.shed) || 0 };
    await chrome.storage.session.set({ eco });
    if ((await getEco()).shed !== before.shed) await syncBswp();
  })().catch(() => {});
});

const UPDATE_ALARM = 'chromeoptimizer-update';

async function syncUpdateAlarm() {
  const { updateCheck } = await getSettings();
  if (!updateCheck || !(await getPower())) { await chrome.alarms.clear(UPDATE_ALARM); return; }
  if (!(await chrome.alarms.get(UPDATE_ALARM))) await chrome.alarms.create(UPDATE_ALARM, { delayInMinutes: 1, periodInMinutes: 1440 });
}

async function getStage() {
  const { cycleStage } = await chrome.storage.session.get('cycleStage');
  return cycleStage || 0;
}

async function schedule(stage) {
  const s = await getSettings();
  if (s.mode !== 'auto' || !(await getPower())) { await chrome.alarms.clear(ALARM); return; }
  const base = s.adaptiveInterval ? CYCLE_STEPS[stage] : CYCLE_STEPS[0];
  const eco = s.ecoOptimizer ? await getEco() : ECO_NONE;
  await chrome.alarms.create(ALARM, { delayInMinutes: Math.max(0.5, base * (1 + eco.slow)) });
  await chrome.storage.session.set({ cycleStage: s.adaptiveInterval ? stage : 0 });
}

async function syncAlarm() {
  const { mode } = await getSettings();
  if (mode !== 'auto' || !(await getPower())) { await chrome.alarms.clear(ALARM); return; }
  if (!(await chrome.alarms.get(ALARM))) await schedule(0);
}

async function wake() {
  if (!(await getPower())) return;
  if ((await getStage()) > 0) await schedule(0);
}

chrome.runtime.onInstalled.addListener((d) => {
  if (d && d.reason === 'install') chrome.tabs.create({ url: chrome.runtime.getURL('welcome.html') });
  applyPower().catch(() => {});
});
chrome.runtime.onStartup.addListener(() => { applyPower().catch(() => {}); });

const whenOn = (fn) => async (...a) => { if (await getPower()) return fn(...a); };
chrome.tabs.onActivated.addListener(whenOn((info) => { trackActivated(info); wake(); }));
chrome.tabs.onRemoved.addListener(whenOn((id) => { trackRemoved(id); wake(); }));
chrome.tabs.onCreated.addListener(wake);

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (sender.id !== chrome.runtime.id || !msg || msg.type !== '1pw') return;
  (async () => {
    if (msg.on && !(await getPower())) reply({ ok: false });
    else if (msg.on) reply(await startOnePw(msg.tabId));
    else { await stopOnePw(); reply({ ok: true }); }
  })().catch(() => reply({ ok: false }));
  return true;
});
chrome.tabs.onUpdated.addListener((id, info) => { if (info.audible !== undefined) markAudio(id); });
chrome.tabs.onRemoved.addListener((id) => { forgetAudio(id); });

chrome.tabs.onRemoved.addListener(async (id) => {
  const st = await getOnePw();
  if (st && st.tabId === id) await stopOnePw();
});
chrome.tabs.onUpdated.addListener(async (id, info, tab) => {
  if (info.status === 'complete' && (await getPower())) discardIfEligible(tab).catch(() => {});
});

chrome.permissions.onRemoved.addListener(() => syncBswp().catch(() => {}));
chrome.permissions.onAdded.addListener(async (p) => {
  if (!p.origins || !p.origins.length) return;
  const s = await getSettings();
  if (s.bswpPending) await saveSettings({ bswp: true, bswpPending: false });
  syncBswp().catch(() => {});
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes[POWER_KEY]) applyPower().catch(() => {});
  if (area !== 'local' || !changes.settings) return;
  const a = changes.settings.oldValue || {}, b = changes.settings.newValue || {};
  if (a.updateCheck !== b.updateCheck) syncUpdateAlarm();
  if (a.bswp !== b.bswp) syncBswp().catch(() => {});
  if (!!a.ecoOptimizer !== !!b.ecoOptimizer) syncEco().catch(() => {});
  if (a.adaptiveInterval !== b.adaptiveInterval) schedule(0); else syncAlarm();
});

chrome.commands.onCommand.addListener(async (cmd) => {
  if (!(await getPower())) return;
  if (cmd === 'optimize-now') { optimize({ manual: true }); return; }
  if (cmd === 'toggle-1pw') {
    if (await getOnePw()) { await stopOnePw(); return; }
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (tab) await startOnePw(tab.id);
    return;
  }
  if (cmd !== 'toggle-pulsa') return;
  const { algorithm, pulsaLast } = await getSettings();
  await saveSettings(algorithm === 'classic' ? { algorithm: pulsaLast } : { algorithm: 'classic', pulsaLast: algorithm });
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (!(await getPower())) return;
  if (alarm.name === UPDATE_ALARM) { checkForUpdate().catch(() => {}); return; }
  if (alarm.name === PRELOAD_ALARM) { runPreload().catch(() => {}); return; }
  if (alarm.name !== ALARM) return;
  let stage = await getStage();
  try {
    const { slept, closed } = await optimize();
    stage = nextStage(stage, slept + closed > 0);
  } finally {
    await schedule(stage);
  }
});
