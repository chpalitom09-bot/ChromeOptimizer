import { getSettings, saveSettings } from './lib.js';

const PRESETS = ['auto', 'light', 'dark', 'blue', 'graphite', 'green', 'pink'];
const mq = typeof matchMedia === 'function' ? matchMedia('(prefers-color-scheme: light)') : null;

export function applyTheme(s) {
  const theme = PRESETS.includes(s.theme) ? s.theme : 'auto';
  document.documentElement.setAttribute('data-theme', theme);
  document.documentElement.setAttribute('data-radius', s.radius === 'sharp' ? 'sharp' : 'round');
  if (s.accent) document.documentElement.style.setProperty('--accent', s.accent);
  else document.documentElement.style.removeProperty('--accent');
}

export async function initTheme() {
  const s = await getSettings();
  applyTheme(s);
  mq && mq.addEventListener('change', async () => {
    const cur = await getSettings();
    if (cur.theme === 'auto') applyTheme(cur);
  });
  return s;
}

export async function toggleLightDark() {
  const s = await getSettings();
  const isLight = s.theme === 'light' || (s.theme === 'auto' && mq && mq.matches);
  const next = await saveSettings({ theme: isLight ? 'dark' : 'light' });
  applyTheme(next);
  return next;
}
