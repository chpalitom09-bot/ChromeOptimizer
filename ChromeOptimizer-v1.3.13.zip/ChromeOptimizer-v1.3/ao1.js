import {
  analyze, scoreOf, gradeFor, THRESHOLDS, HEAD_BYTES, TAIL_BYTES, TRUSTED_HOSTS,
  extOf, nameFromUrl, parseDisposition, hostMatches, sha256Hex
} from './ao1-core.js';

const MODES = ['warn', 'ask', 'block'];
const LEVELS = Object.keys(THRESHOLDS);
const HISTORY_MAX = 50;
const ORIGINS = ['http://*/*', 'https://*/*'];

// R6 : les listeners sont enregistrés de façon SYNCHRONE à la création du moteur
// (obligatoire en MV3, sinon le service worker endormi rate les événements),
// la config est chargée à la demande.
export class AO1Engine {
  constructor() {
    this.config = { enabled: false, level: 'normal', mode: 'warn', trusted: [], allow: [], power: true, readContent: true, cookies: true, keepDetails: true };
    this.chain = Promise.resolve();
    this.ready = this.loadConfig();

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      if (changes.ao1On) this.config.enabled = !!changes.ao1On.newValue;
      if (changes.ao1Level) this.config.level = LEVELS.includes(changes.ao1Level.newValue) ? changes.ao1Level.newValue : 'normal';
      if (changes.ao1Mode) this.config.mode = MODES.includes(changes.ao1Mode.newValue) ? changes.ao1Mode.newValue : 'warn';
      if (changes.ao1Trusted) this.config.trusted = Array.isArray(changes.ao1Trusted.newValue) ? changes.ao1Trusted.newValue : [];
      if (changes.power) this.config.power = changes.power.newValue !== false;
      if (changes.ao1Allow) this.config.allow = Array.isArray(changes.ao1Allow.newValue) ? changes.ao1Allow.newValue : [];
      if (changes.ao1ReadContent) this.config.readContent = changes.ao1ReadContent.newValue !== false;
      if (changes.ao1Cookies) this.config.cookies = changes.ao1Cookies.newValue !== false;
      if (changes.ao1KeepDetails) this.config.keepDetails = changes.ao1KeepDetails.newValue !== false;
    });

    chrome.downloads.onCreated.addListener((item) => {
      this.scanDownload(item).catch((e) => console.warn('AO1: analyse échouée', e));
    });

    if (chrome.notifications) {
      chrome.notifications.onButtonClicked.addListener((id, idx) => { this.onButton(id, idx).catch(() => {}); });
      chrome.notifications.onClicked.addListener((id) => { if (id.startsWith('ao1:')) chrome.notifications.clear(id); });
    }
  }

  async loadConfig() {
    const d = await chrome.storage.local.get(['ao1On', 'ao1Level', 'ao1Mode', 'ao1Trusted', 'ao1Allow', 'ao1ReadContent', 'ao1Cookies', 'ao1KeepDetails', 'power']);
    this.config.enabled = !!d.ao1On;
    this.config.level = LEVELS.includes(d.ao1Level) ? d.ao1Level : 'normal';
    this.config.mode = MODES.includes(d.ao1Mode) ? d.ao1Mode : 'warn';
    this.config.trusted = Array.isArray(d.ao1Trusted) ? d.ao1Trusted : [];
    this.config.allow = Array.isArray(d.ao1Allow) ? d.ao1Allow : [];
    this.config.power = d.power !== false;
    this.config.readContent = d.ao1ReadContent !== false;
    this.config.cookies = d.ao1Cookies !== false;
    this.config.keepDetails = d.ao1KeepDetails !== false;
  }

  async readLimited(res, max) {
    if (!res.body) return new Uint8Array(await res.arrayBuffer()).subarray(0, max);
    const reader = res.body.getReader();
    const chunks = [];
    let n = 0;
    while (n < max) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value); n += value.length;
    }
    try { await reader.cancel(); } catch { /* ignore */ }
    const out = new Uint8Array(Math.min(n, max));
    let o = 0;
    for (const c of chunks) {
      const take = Math.min(c.length, out.length - o);
      out.set(c.subarray(0, take), o); o += take;
      if (o >= out.length) break;
    }
    return out;
  }

  async fetchRange(url, range, ms) {
    return fetch(url, {
      headers: { Range: range },
      credentials: this.config.cookies ? 'include' : 'omit',
      cache: 'no-store',
      referrerPolicy: 'no-referrer',
      signal: AbortSignal.timeout(ms)
    });
  }

  async scanDownload(item) {
    await this.ready;
    if (!this.config.enabled || !this.config.power || !/^https?:/i.test(item.url || '')) return;

    const finalUrl = item.finalUrl || item.url;
    let host = '';
    try { host = new URL(finalUrl).hostname; } catch { /* ignore */ }
    const trusted = hostMatches(host, TRUSTED_HOSTS) || hostMatches(host, this.config.trusted);

    let filename = (item.filename || '').split(/[\\/]/).pop() || nameFromUrl(finalUrl);
    let ctx = { url: finalUrl, filename, trusted };
    let bytes = null, tail = null, total = 0, ctype = '', sha256 = null, hashFull = false;
    let extraNote = null;

    const granted = await chrome.permissions.contains({ origins: ORIGINS }).catch(() => false);
    if (!this.config.readContent) {
      extraNote = 'Lecture du contenu désactivée dans vos réglages : analyse limitée à l\'adresse et au nom du fichier';
    } else if (!granted) {
      extraNote = 'Analyse du contenu indisponible : autorisez l\'accès aux sites dans Options → AntiVirus';
    } else {
      try {
        const res = await this.fetchRange(finalUrl, `bytes=0-${HEAD_BYTES - 1}`, 6000);
        if (res.ok || res.status === 206) {
          ctype = res.headers.get('content-type') || '';
          const cd = parseDisposition(res.headers.get('content-disposition'));
          if (cd && !item.filename) filename = cd;
          const cr = /\/(\d+)\s*$/.exec(res.headers.get('content-range') || '');
          total = cr ? Number(cr[1]) : (res.status === 200 ? Number(res.headers.get('content-length')) || 0 : 0);
          if (!total) total = Math.max(item.fileSize || 0, item.totalBytes || 0);
          bytes = await this.readLimited(res, HEAD_BYTES);
          sha256 = await sha256Hex(bytes);
          hashFull = !!total && total <= bytes.length;

          const looksZip = bytes.length > 4 && bytes[0] === 0x50 && bytes[1] === 0x4B;
          if (looksZip && total > bytes.length) {
            try {
              const r2 = await this.fetchRange(finalUrl, `bytes=-${TAIL_BYTES}`, 6000);
              if (r2.status === 206) tail = await this.readLimited(r2, TAIL_BYTES);
            } catch { /* fin de fichier indisponible */ }
          }
        } else {
          extraNote = `Contenu non récupéré (HTTP ${res.status}) : analyse limitée à l'URL et au nom`;
        }
      } catch (e) {
        extraNote = 'Contenu non récupérable (réseau, délai dépassé ou lien à usage unique) : analyse limitée à l\'URL et au nom';
      }
    }

    ctx = { ...ctx, filename, ext: extOf(filename), ctype, bytes, tail, total };
    const result = analyze(ctx);
    const signals = result.signals;
    if (extraNote) signals.push({ label: extraNote, weight: 0, hard: false, note: true });

    // Empreinte du fichier COMPLET déjà validée par l'utilisateur (Garder/Ignorer) : on ne le re-signale plus
    const allowed = hashFull && !!sha256 && this.config.allow.includes(sha256);
    if (allowed) signals.push({ label: 'Fichier identique déjà validé par vous (empreinte SHA-256)', weight: 0, hard: false, note: true });
    const score = scoreOf(signals);
    const threshold = THRESHOLDS[this.config.level];
    const flagged = !allowed && score >= threshold;
    const mode = this.config.mode;
    const grade = gradeFor(score);
    let status = 'SAIN';

    if (flagged) {
      if (mode === 'block') {
        status = 'BLOQUÉ';
        try { await chrome.downloads.cancel(item.id); } catch { /* déjà terminé */ }
        this.notify(`ao1:block:${item.id}`, 'ChromeOptimizer : fichier bloqué', filename, score, grade, signals, []);
      } else if (mode === 'ask') {
        status = 'EN PAUSE';
        try { await chrome.downloads.pause(item.id); } catch { status = 'SUSPECT'; }
        this.notify(`ao1:ask:${item.id}`, 'ChromeOptimizer : fichier suspect', filename, score, grade, signals,
          ['Garder le téléchargement', 'Supprimer']);
      } else {
        status = 'SUSPECT';
        this.notify(`ao1:warn:${item.id}`, 'ChromeOptimizer : fichier suspect', filename, score, grade, signals,
          ['Supprimer le fichier', 'Ignorer']);
      }
    }

    const keep = this.config.keepDetails;
    const ext = extOf(filename);
    await this.saveHistory({
      dlId: item.id,
      filename: keep ? filename : (ext ? `•••.${ext}` : '•••'),
      score, status, grade: grade.grade, gradeLabel: grade.label,
      threats: signals.map((s) => (s.note ? 'ℹ ' : '') + (keep ? s.label : s.label.replace(/\s*\([^)]*\)/g, ''))),
      sha256: keep ? sha256 : null, hashFull, entropy: result.entropy, trusted, checks: result.checks
    });
    await this.bumpStats(flagged, status, result.checks);
  }

  notify(id, title, filename, score, grade, signals, buttons) {
    if (!chrome.notifications) return;
    const top = signals.filter((s) => s.weight > 0).sort((a, b) => b.weight - a.weight).slice(0, 2).map((s) => s.label).join(' · ');
    try {
      chrome.notifications.create(id, {
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title,
        message: `${filename || 'Fichier'}\nScore ${score}/100 (note ${grade.grade}). ${top}`,
        buttons: buttons.map((t) => ({ title: t })),
        requireInteraction: buttons.length > 0,
        priority: 2
      });
    } catch (e) { console.warn('AO1: notification impossible', e); }
  }

  async onButton(notifId, idx) {
    const m = /^ao1:(warn|ask):(\d+)$/.exec(notifId);
    if (!m) return;
    const kind = m[1], id = Number(m[2]);
    const keep = kind === 'ask' && idx === 0;
    const del = (kind === 'ask' && idx === 1) || (kind === 'warn' && idx === 0);
    if (keep) {
      try { await chrome.downloads.resume(id); } catch { /* ignore */ }
      await this.updateHistory(id, { status: 'GARDÉ' });
      await this.allowHash(id);
    } else if (del) {
      await this.removeDownload(id);
      await this.updateHistory(id, { status: 'SUPPRIMÉ' });
    } else {
      await this.updateHistory(id, { status: 'IGNORÉ' });
      await this.allowHash(id);
    }
    chrome.notifications.clear(notifId);
  }

  async removeDownload(id) {
    try { await chrome.downloads.cancel(id); } catch { /* ignore */ }
    try { await chrome.downloads.removeFile(id); } catch { /* ignore */ }
    try { await chrome.downloads.erase({ id }); } catch { /* ignore */ }
  }

  queue(fn) {
    this.chain = this.chain.then(fn).catch((e) => console.warn('AO1: stockage', e));
    return this.chain;
  }

  saveHistory(entry) {
    return this.queue(async () => {
      const { ao1History = [] } = await chrome.storage.local.get('ao1History');
      ao1History.unshift({
        dlId: entry.dlId,
        ts: Date.now(),
        date: new Date().toLocaleString(),
        filename: entry.filename,
        score: entry.score,
        status: entry.status,
        grade: entry.grade,
        gradeLabel: entry.gradeLabel,
        threats: entry.threats.join(' | ') || 'Aucune anomalie détectée',
        sha256: entry.sha256,
        hashFull: !!entry.hashFull,
        trusted: !!entry.trusted,
        entropy: Number.isFinite(entry.entropy) ? Number(entry.entropy.toFixed(2)) : null,
        checks: entry.checks || 0
      });
      if (ao1History.length > HISTORY_MAX) ao1History.length = HISTORY_MAX;
      await chrome.storage.local.set({ ao1History });
    });
  }

  bumpStats(flagged, status, checks) {
    return this.queue(async () => {
      const { ao1Stats } = await chrome.storage.local.get('ao1Stats');
      const st = ao1Stats || { scanned: 0, flagged: 0, blocked: 0, checks: 0, since: Date.now() };
      st.scanned++; st.checks += checks || 0;
      if (flagged) st.flagged++;
      if (status === 'BLOQUÉ' || status === 'EN PAUSE') st.blocked++;
      await chrome.storage.local.set({ ao1Stats: st });
    });
  }

  allowHash(dlId) {
    return this.queue(async () => {
      const { ao1History = [], ao1Allow = [] } = await chrome.storage.local.get(['ao1History', 'ao1Allow']);
      const e = ao1History.find((h) => h.dlId === dlId);
      if (!e || !e.sha256 || !e.hashFull || ao1Allow.includes(e.sha256)) return;
      ao1Allow.push(e.sha256);
      if (ao1Allow.length > 200) ao1Allow.shift();
      await chrome.storage.local.set({ ao1Allow });
    });
  }

  updateHistory(dlId, patch) {
    return this.queue(async () => {
      const { ao1History = [] } = await chrome.storage.local.get('ao1History');
      const e = ao1History.find((h) => h.dlId === dlId);
      if (!e) return;
      Object.assign(e, patch);
      await chrome.storage.local.set({ ao1History });
    });
  }
}
