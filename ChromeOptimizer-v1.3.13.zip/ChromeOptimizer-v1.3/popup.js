import { getSettings, saveSettings, getStats, analyze, optimize, hostOf, isProtectedSite, getContext } from './lib.js';
import { getUpdateInfo, isNewer, PAGE_URL, currentLabel } from './update.js';
import { loadModel } from './pulsa-store.js';
import { initLang, mountLangSwitcher, t, tn, num } from './i18n.js';
import { ecoProfile } from './eco.js';
import { getOnePw } from './onepw.js';
import { safeReason, loadAudioSeen } from './safe.js';
import { initTheme, toggleLightDark } from './theme.js';
import { openWelcomeIfNeeded } from './onboarding.js';
import { getPower, setPower } from './power.js';

// état de l'interrupteur lu AVANT le premier rendu : pas de flash du mauvais état
let powerOn = await getPower();
document.body.dataset.power = powerOn ? 'on' : 'off';
document.body.classList.add('no-anim');
requestAnimationFrame(() => requestAnimationFrame(() => document.body.classList.remove('no-anim')));

openWelcomeIfNeeded();

const $ = (id) => document.getElementById(id);
const gb = (bytes) => num(bytes / 1073741824, 1);

let prevCpu = null;

function setGauge(id, pct, sub) {
  const ring = $(id + 'Ring');
  ring.style.strokeDasharray = `${pct} 100`;
  ring.classList.toggle('warn', pct >= 70 && pct < 90);
  ring.classList.toggle('hot', pct >= 90);
  $(id + 'Pct').textContent = pct + ' %';
  if (sub !== undefined) $(id + 'Sub').textContent = sub;
}

async function readMemory() {
  const m = await chrome.system.memory.getInfo();
  const used = m.capacity - m.availableCapacity;
  setGauge('mem', Math.round((used / m.capacity) * 100), `${gb(used)} / ${gb(m.capacity)} ${t('p.gb')}`);
}

async function readCpu() {
  const info = await chrome.system.cpu.getInfo();
  const total = info.processors.reduce((a, p) => ({ idle: a.idle + p.usage.idle, total: a.total + p.usage.total }), { idle: 0, total: 0 });
  if (prevCpu && total.total > prevCpu.total) {
    setGauge('cpu', Math.round((1 - (total.idle - prevCpu.idle) / (total.total - prevCpu.total)) * 100), tn('p.cores', info.numOfProcessors));
  }
  prevCpu = total;
}

function tick() { readMemory().catch(() => {}); readCpu().catch(() => {}); }

async function refreshTabs() {
  const [settings, tabs] = await Promise.all([getSettings(), chrome.tabs.query({})]);
  const model = settings.algorithm !== 'classic' ? await loadModel() : null;
  const plan = analyze(tabs, settings, Date.now(), model, await getContext(settings));
  $('open').textContent = tabs.length;
  $('sleeping').textContent = tabs.filter((t) => t.discarded).length;
  $('todo').textContent = plan.sleep.length + plan.close.length;
  const dup = settings.duplicates === 'off' ? t('p.dupOff') : tn('n.dup', plan.close.length);
  $('hint').textContent = plan.offline ? t('p.offline')
    : settings.algorithm !== 'classic'
    ? tn('p.hintPulsa', plan.sleep.length, { dup })
    : tn('p.hintClassic', plan.sleep.length, { dup, min: settings.idleMinutes });
}

async function showBswp(s) {
  if (s.bswpPending) {
    const granted = await chrome.permissions.contains({ origins: ['http://*/*', 'https://*/*'] });
    s = await saveSettings(granted ? { bswp: true, bswpPending: false } : { bswpPending: false });
  }
  $('bswpOn').checked = s.bswp;
  const hint = $('bswpHint');
  if (!s.bswp) { hint.textContent = t('p.bswpOff'); return; }
  hint.textContent = t('p.bswpOn');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const r = await chrome.tabs.sendMessage(tab.id, { type: 'bswp-stats' });
    const n = r.img + r.frame + r.video;
    hint.textContent = n ? t('p.bswpPage', { img: tn('n.img', r.img), frame: tn('n.frame', r.frame), video: tn('n.video', r.video) }) : t('p.bswpNone');
  } catch { }
}

$('bswpOn').addEventListener('change', async (e) => {
  const on = e.target.checked;
  if (on) {
    await saveSettings({ bswpPending: true });
    const ok = await chrome.permissions.request({ origins: ['http://*/*', 'https://*/*'] });
    if (!ok) { await saveSettings({ bswpPending: false }); e.target.checked = false; return; }
  } else {
    await chrome.permissions.remove({ origins: ['http://*/*', 'https://*/*'] }).catch(() => {});
  }
  const s = await saveSettings({ bswp: on, bswpPending: false });
  await showBswp(s);
  if (on) $('bswpHint').textContent += t('p.bswpReload');
});

async function showSafe(s) {
  $('safeOn').checked = s.safe;
  if (!s.safe) { $('safeHint').textContent = t('p.safeOff'); return; }
  const [seen, tabs] = await Promise.all([loadAudioSeen(), chrome.tabs.query({})]);
  const n = tabs.filter((x) => !x.discarded && safeReason(x, seen)).length;
  $('safeHint').textContent = t('p.safeOn', { n });
}

$('safeOn').addEventListener('change', async (e) => {
  await showSafe(await saveSettings({ safe: e.target.checked }));
  refreshTabs();
});

async function showOnePw() {
  const st = await getOnePw();
  $('opwOn').checked = !!st;
  if (!st) { $('opwHint').textContent = t('p.opwOff'); return; }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const n = (await chrome.tabs.query({})).filter((x) => x.discarded).length;
  $('opwHint').textContent = t(tab && tab.id === st.tabId ? 'p.opwOn' : 'p.opwElse', { n });
}

$('opwOn').addEventListener('change', async (e) => {
  try {
    if (e.target.checked) {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const r = tab ? await chrome.runtime.sendMessage({ type: '1pw', on: true, tabId: tab.id }) : null;
      if (!r || !r.ok) { e.target.checked = false; $('opwHint').textContent = t('p.opwPage'); return; }
    } else {
      await chrome.runtime.sendMessage({ type: '1pw', on: false });
    }
  } catch { e.target.checked = !e.target.checked; return; }
  await Promise.all([showOnePw(), refreshTabs()]);
  setTimeout(tick, 1200);
});

function showPulsa(s) {
  $('pulsaOn').checked = s.algorithm !== 'classic';
  $('pulsaHint').textContent = s.algorithm !== 'classic' ? t('p.pulsaOn') : t('p.pulsaOff', { min: s.idleMinutes });
}

async function showUpdate() {
  const [s, u] = await Promise.all([getSettings(), getUpdateInfo()]);
  const b = $('updBanner');
  const cur = chrome.runtime.getManifest().version;
  const show = s.updateCheck && u && (u.status === 'store' || (u.status === 'available' && isNewer(u.latest, cur)));
  b.hidden = !show;
  if (!show) return;
  if (u.status === 'store') {
    b.textContent = t('p.updReady');
    b.href = '#';
    b.onclick = (e) => { e.preventDefault(); chrome.runtime.reload(); };
  } else {
    b.textContent = t('p.updAvail', { latest: u.label || u.latest, cur: currentLabel() });
    b.href = u.page || PAGE_URL; b.onclick = null;
  }
}

async function refreshTotals() {
  const st = await getStats();
  $('totals').textContent = st.runs
    ? t('p.totals', { a: tn('n.slept', st.slept), b: tn('n.closed', st.closed) })
    : t('p.totalsNone');
}

async function refreshProtect() {
  const btn = $('protect');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const host = tab && /^https?:/i.test(tab.url || '') ? hostOf(tab.url) : '';
  if (!host) { btn.disabled = true; btn.textContent = t('p.protect'); return; }
  const settings = await getSettings();
  const on = isProtectedSite(tab.url, settings.protectedSites);
  btn.disabled = false;
  btn.dataset.host = host;
  btn.dataset.on = on ? '1' : '';
  btn.textContent = on ? t('p.unprotectHost', { host }) : t('p.protectHost', { host });
  btn.title = btn.textContent;
}

$('run').addEventListener('click', async () => {
  const btn = $('run');
  btn.disabled = true; btn.textContent = t('p.running'); $('result').textContent = '';
  try {
    const { slept, closed } = await optimize({ manual: true });
    $('result').textContent = slept || closed
      ? t('p.result', { a: tn('n.slept', slept), b: tn('n.closed', closed) })
      : t('p.nothing');
  } catch {
    $('result').textContent = t('p.failed');
  }
  btn.disabled = false; btn.textContent = t('p.run');
  await Promise.all([refreshTabs(), refreshTotals()]);
  setTimeout(tick, 1200);
});

$('pulsaOn').addEventListener('change', async (e) => {
  const cur = await getSettings();
  const s = await saveSettings(e.target.checked ? { algorithm: cur.pulsaLast } : { algorithm: 'classic', pulsaLast: cur.algorithm === 'classic' ? cur.pulsaLast : cur.algorithm });
  showPulsa(s);
  await refreshTabs();
});

$('auto').addEventListener('change', async (e) => {
  await saveSettings({ mode: e.target.checked ? 'auto' : 'manual' });
});

$('protect').addEventListener('click', async () => {
  const btn = $('protect'), host = btn.dataset.host;
  if (!host) return;
  const s = await getSettings();
  const list = btn.dataset.on ? s.protectedSites.filter((d) => host !== d && !host.endsWith('.' + d)) : [...new Set([...s.protectedSites, host])];
  await saveSettings({ protectedSites: list });
  await Promise.all([refreshProtect(), refreshTabs()]);
});

$('openOptions').addEventListener('click', () => chrome.runtime.openOptionsPage());
initTheme();
$('themeToggle').addEventListener('click', toggleLightDark);

async function showEco() {
  const box = $('ecoMsg');
  box.hidden = true;
  try {
    const s = await getSettings();
    if (!s.ecoOptimizer) return;
    const b = await navigator.getBattery();
    const level = Math.round(b.level * 100), p = ecoProfile(level, b.charging);
    if (!p.slow) return;
    $('ecoMsgText').textContent = t('eco.popup', { level, slow: Math.round(p.slow * 100) }) + (p.shed ? ' ' + t('eco.shed' + p.shed) : '');
    box.hidden = false;
  } catch { }
}

async function renderAll() {
  const s = await getSettings();
  showPulsa(s);
  showBswp(s);
  showOnePw();
  showSafe(s);
  await Promise.all([refreshTabs(), refreshTotals(), refreshProtect(), showUpdate(), showEco()]);
  tick();
}

// ───── interrupteur général ─────
let tickId = null;
const startTick = () => { if (!tickId) tickId = setInterval(tick, 1500); };
const stopTick = () => { clearInterval(tickId); tickId = null; };

function splitNames() {
  document.querySelectorAll('.name').forEach((n) => {
    const txt = n.textContent;
    n.setAttribute('aria-label', txt);
    n.innerHTML = [...txt].map((c, i) => `<span class="ch" aria-hidden="true" style="--k:${i}">${c}</span>`).join('');
  });
}

function bootAnim() {
  const b = document.body;
  document.querySelectorAll('#panel .inner > *').forEach((e, i) => e.style.setProperty('--j', i));
  b.classList.add('waking');
  const marks = document.querySelectorAll('.logo-live, .name');
  marks.forEach((e) => { e.classList.remove('boot'); void e.offsetWidth; e.classList.add('boot'); });
  setTimeout(() => { b.classList.remove('waking'); marks.forEach((e) => e.classList.remove('boot')); }, 1700);
}

async function applyPower(on) {
  powerOn = on;
  document.body.dataset.power = on ? 'on' : 'off';
  await setPower(on);
  if (on) { bootAnim(); await renderAll(); startTick(); }
  else stopTick();
}

const confirmBox = $('pwConfirm');
const openConfirm = () => { confirmBox.classList.add('open'); $('pwNo').focus(); };
const closeConfirm = () => confirmBox.classList.remove('open');
$('powerBtn').addEventListener('click', openConfirm);
$('pwNo').addEventListener('click', closeConfirm);
$('pwYes').addEventListener('click', () => { closeConfirm(); setTimeout(() => applyPower(false), 220); });
confirmBox.addEventListener('click', (e) => { if (e.target === confirmBox) closeConfirm(); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && confirmBox.classList.contains('open')) closeConfirm(); });
$('powerOn').addEventListener('click', () => applyPower(true));

(async () => {
  await initLang();
  splitNames();
  mountLangSwitcher($('langHost'), () => (powerOn ? renderAll() : undefined));
  const s = await getSettings();
  $('auto').checked = s.mode === 'auto';
  if (powerOn) { await renderAll(); startTick(); }
})();
