import { getSettings, isProtectedSite } from './lib.js';
import { safeReason, loadAudioSeen } from './safe.js';
import { getUpdateInfo } from './update.js';

const KEY = 'onePw';

export async function getOnePw() {
  const { onePw } = await chrome.storage.session.get(KEY);
  return onePw || null;
}

export function eligible(t, st, settings, seen) {
  if (!st || t.id === st.tabId || t.discarded || t.active || t.pinned) return false;
  if (settings.safe && safeReason(t, seen)) return false;
  if (t.autoDiscardable === false || !/^https?:/i.test(t.url || '')) return false;
  if (isProtectedSite(t.url, settings.protectedSites)) return false;
  if (settings.onePwWindowOnly && t.windowId !== st.windowId) return false;
  return true;
}

export async function refreshBadge() {
  if (await getOnePw()) {
    chrome.action.setBadgeText({ text: '1PW' });
    chrome.action.setBadgeBackgroundColor({ color: '#1a9d5a' });
    return;
  }
  const u = await getUpdateInfo();
  const up = u && (u.status === 'store' || u.status === 'available');
  chrome.action.setBadgeText({ text: up ? '↑' : '' });
  if (up) chrome.action.setBadgeBackgroundColor({ color: '#2f6fed' });
}

export async function sweep() {
  const st = await getOnePw();
  if (!st) return 0;
  const settings = await getSettings();
  const tabs = await chrome.tabs.query({});
  const seen = settings.safe ? await loadAudioSeen() : null;
  let n = 0;
  for (const t of tabs) {
    if (t.status === 'loading' || !eligible(t, st, settings, seen)) continue;
    try { if (await chrome.tabs.discard(t.id)) n++; } catch { }
  }
  return n;
}

export async function discardIfEligible(tab) {
  const st = await getOnePw();
  if (!st) return;
  const settings = await getSettings();
  if (!eligible(tab, st, settings, settings.safe ? await loadAudioSeen() : null)) return;
  try { await chrome.tabs.discard(tab.id); } catch { }
}

export async function startOnePw(tabId) {
  let tab;
  try { tab = await chrome.tabs.get(tabId); } catch { return { ok: false, reason: 'tab' }; }
  if (!/^https?:/i.test(tab.url || '')) return { ok: false, reason: 'page' };
  await chrome.storage.session.set({ [KEY]: { tabId, windowId: tab.windowId, since: Date.now() } });
  await refreshBadge();
  return { ok: true, n: await sweep() };
}

export async function stopOnePw() {
  await chrome.storage.session.remove(KEY);
  await refreshBadge();
}
