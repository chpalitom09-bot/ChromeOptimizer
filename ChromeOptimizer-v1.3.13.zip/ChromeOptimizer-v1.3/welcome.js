import { initTheme } from './theme.js';
import { startOnboarding } from './onboarding.js';
import { playIntro } from './intro.js';

initTheme();
const intro = playIntro();          // l'intro démarre tout de suite
startOnboarding();                  // la carte est construite en coulisses (masquée tant que l'intro joue)
intro.done.then(() => intro.land(document.querySelector('.ob-brand img')));
