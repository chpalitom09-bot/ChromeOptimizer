// Intro de bienvenue : logo seul → le logo glisse à gauche et le nom sort de derrière lui →
// le nom disparaît et le logo glisse/rétrécit jusqu'au logo de la barre latérale.
// playIntro() → { done, land(target) } ; done se résout à la fin (ou au clic / Échap / Entrée).
import { OB } from './onboarding-strings.js';

const AUTO_MS = 4100;
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

export function playIntro() {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    return { done: Promise.resolve(false), land: async () => {} };
  }
  document.body.classList.add('introing');
  const lang = (chrome.i18n.getUILanguage() || 'fr').slice(0, 2);
  const skipLabel = (OB[lang] && OB[lang]['intro.skip']) ?? OB.fr['intro.skip'];
  const root = document.createElement('div');
  root.id = 'intro';
  root.innerHTML = `
    <div class="in-bg"></div>
    <div class="in-lock" dir="ltr">
      <div class="in-logo">
        <span class="ring"></span><span class="halo"></span>
        <div class="in-tile"><img src="icons/icon128.png" alt=""><span class="sweep"></span></div>
      </div>
      <div class="in-word"><h1 class="in-name">ChromeOptimizer</h1></div>
    </div>
    <button class="in-skip" type="button">${skipLabel}</button>`;
  document.body.appendChild(root);
  // largeur naturelle du nom, pour que la « fenêtre » s'ouvre exactement à la bonne taille
  root.style.setProperty('--w', Math.ceil(root.querySelector('.in-name').getBoundingClientRect().width) + 'px');

  let go; const exit = new Promise((r) => { go = r; });
  const timer = setTimeout(go, AUTO_MS);
  const skip = () => { clearTimeout(timer); go(); };
  root.addEventListener('click', skip);
  const onKey = (e) => { if (e.key === 'Escape' || e.key === 'Enter' || e.key === ' ') skip(); };
  window.addEventListener('keydown', onKey);

  async function land(target) {
    window.removeEventListener('keydown', onKey);
    root.classList.add('out');
    await wait(420);
    // on affiche la carte pour mesurer la position finale du logo cible, puis on relance son animation d'entrée
    document.body.classList.remove('introing');
    const card = document.getElementById('onboard');
    if (card) card.style.animation = 'none';
    if (target) target.style.visibility = 'hidden';
    const to = target ? target.getBoundingClientRect() : null;
    if (card) { void card.offsetWidth; card.style.animation = ''; }
    root.classList.add('land');
    const tile = root.querySelector('.in-tile');
    const from = tile.getBoundingClientRect();
    const O = { transformOrigin: '0 0' };
    const frames = to && to.width > 0
      ? [{ ...O, transform: 'none' }, { ...O, transform: `translate(${to.left - from.left}px,${to.top - from.top}px) scale(${to.width / from.width})` }]
      : [{ ...O, transform: 'none', opacity: 1 }, { ...O, transform: 'translateY(-40px) scale(.6)', opacity: 0 }];
    await tile.animate(frames, { duration: 950, easing: 'cubic-bezier(.65,0,.25,1)', fill: 'forwards' }).finished.catch(() => {});
    if (target) target.style.visibility = '';
    root.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 220, fill: 'forwards' }).finished.catch(() => {}).then(() => root.remove());
  }
  return { done: exit.then(() => true), land };
}
