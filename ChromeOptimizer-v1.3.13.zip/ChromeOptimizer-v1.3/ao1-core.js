// AO1 core : analyse pure (aucune dépendance à chrome.*), donc testable sous Node.
// Principe anti faux-positifs : les signaux "durs" (preuves) comptent en entier,
// les signaux "souples" (indices) sont plafonnés (SOFT_CAP) et ne bloquent seuls
// qu'en sensibilité "Poussé".

export const SOFT_CAP = 45;
export const HEAD_BYTES = 262144;      // 256 Ko lus en tête de fichier
export const TAIL_BYTES = 131072;      // 128 Ko lus en fin de fichier (archives ZIP)
export const THRESHOLDS = { light: 85, normal: 60, aggressive: 40 };

export const GRADES = [
  { max: 9, grade: 'A+', label: 'Sain' },
  { max: 24, grade: 'A', label: 'Très probablement sain' },
  { max: 39, grade: 'B', label: 'Faible risque' },
  { max: 59, grade: 'C', label: 'Risque modéré' },
  { max: 74, grade: 'D', label: 'Risque élevé' },
  { max: 89, grade: 'E', label: 'Dangereux' },
  { max: 100, grade: 'F', label: 'Menace critique' }
];

export const BLACKLIST = ['malware.com', 'virus-test.com', 'shady-downloads.net', 'free-cracks.biz'];
export const SUSPICIOUS_TLDS = ['.zip', '.mov', '.xyz', '.top', '.rest', '.gq', '.tk', '.cam', '.click', '.work', '.country', '.kim', '.loan'];
export const EPHEMERAL_HOSTS = ['cdn.discordapp.com', 'media.discordapp.net', 'pastebin.com', 'transfer.sh', 'anonfiles.com', 'gofile.io', 'catbox.moe', 'temp.sh', 'api.telegram.org', 'file.io', 'tmpfiles.org', 'bashupload.com', 'ufile.io', 'send.cm', 'trycloudflare.com', 'ngrok-free.app', 'ngrok.io'];
export const DYNDNS = ['duckdns.org', 'ddns.net', 'no-ip.org', 'no-ip.biz', 'hopto.org', 'zapto.org', 'serveftp.com', 'myftp.biz'];
const BAIT_RE = /(^|[\s_\-])(facture|invoice|payment|paiement|devis|receipt|swift|commande|cv)([\s_\-.\d]|$)/i;
const BAIT_EXT = new Set(['exe', 'scr', 'com', 'pif', 'vbs', 'jse', 'wsf', 'hta', 'lnk']);

// Éditeurs / distributeurs connus : les signaux souples sont ignorés (les preuves restent comptées).
export const TRUSTED_HOSTS = [
  'microsoft.com', 'windowsupdate.com', 'visualstudio.com', 'google.com', 'gstatic.com', 'mozilla.org', 'mozilla.net',
  'apple.com', 'adobe.com', 'videolan.org', 'python.org', 'nodejs.org', '7-zip.org', 'jetbrains.com', 'ubuntu.com',
  'debian.org', 'kernel.org', 'oracle.com', 'zoom.us', 'slack.com', 'spotify.com', 'steampowered.com', 'valvesoftware.com',
  'nvidia.com', 'amd.com', 'intel.com', 'logitech.com', 'anthropic.com', 'brave.com', 'opera.com', 'notepad-plus-plus.org'
];

export const NATIVE_EXE = new Set(['exe', 'dll', 'sys', 'scr', 'com', 'drv', 'cpl', 'ocx']);
export const SCRIPTY = new Set(['vbs', 'js', 'jse', 'wsf', 'wsh', 'hta', 'ps1', 'bat', 'cmd', 'msi', 'msp', 'reg', 'lnk', 'scf', 'pif', 'vbe', 'jar', 'apk', 'iso', 'img']);
const TEXTY = new Set(['txt', 'csv', 'json', 'html', 'htm', 'xml', 'svg', 'md', 'log', 'ini', 'css', 'js', 'vbs', 'ps1', 'bat', 'cmd', 'reg', 'hta', 'wsf', 'py', 'sh', 'url', 'tsv', 'yaml', 'yml']);
const DOCLIKE = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'jpg', 'jpeg', 'png', 'gif', 'txt', 'zip', 'rar', '7z', 'mp3', 'mp4', 'rtf'];
const IMAGE_KINDS = new Set(['png', 'jpg', 'gif', 'bmp', 'webp', 'ico']);
const ZIPLIKE_NOEXE = new Set(['jar', 'apk', 'crx', 'xpi', 'docx', 'xlsx', 'pptx', 'docm', 'xlsm', 'pptm', 'odt', 'ods', 'odp', 'epub', 'vsix', 'nupkg', 'whl', 'aab']);
const OFFICE_PLAIN = new Set(['docx', 'xlsx', 'pptx']);

const EXT_KINDS = {
  exe: ['exe'], dll: ['exe'], sys: ['exe'], scr: ['exe'], com: ['exe'], drv: ['exe'], cpl: ['exe'], ocx: ['exe'],
  pdf: ['pdf'],
  zip: ['zip'], jar: ['zip'], apk: ['zip'], crx: ['zip'], xpi: ['zip'], docx: ['zip'], xlsx: ['zip'], pptx: ['zip'],
  docm: ['zip'], xlsm: ['zip'], pptm: ['zip'], odt: ['zip'], ods: ['zip'], odp: ['zip'], epub: ['zip'],
  rar: ['rar'], '7z': ['7z'], gz: ['gz'], tgz: ['gz'], bz2: ['bz2'], xz: ['xz'], zst: ['zst'],
  png: ['png'], jpg: ['jpg'], jpeg: ['jpg'], gif: ['gif'], bmp: ['bmp'], webp: ['webp'], ico: ['ico'],
  mp3: ['mp3'], mp4: ['mp4'], m4a: ['mp4'], m4v: ['mp4'], mov: ['mp4'], mkv: ['mkv'], webm: ['mkv'],
  ogg: ['ogg'], oga: ['ogg'], wav: ['wav'], avi: ['avi'], flac: ['flac'],
  doc: ['ole'], xls: ['ole'], ppt: ['ole'], msi: ['ole'], msg: ['ole'], dot: ['ole'],
  lnk: ['lnk'], rtf: ['rtf'], sqlite: ['sqlite'], db: ['sqlite'], class: ['class']
};

const STRONG_PATTERNS = [
  { re: /EICAR-STANDARD-ANTIVIRUS-TEST-FILE/, label: 'Fichier de test antivirus EICAR', weight: 100, hard: true },
  { re: /vssadmin(\.exe)?\s+delete\s+shadows/i, label: 'Suppression des copies de sauvegarde (typique rançongiciel)', weight: 45, hard: true },
  { re: /bcdedit[^\n]{0,60}recoveryenabled\s+no/i, label: 'Désactivation de la récupération Windows (typique rançongiciel)', weight: 45, hard: true },
  { re: /stratum\+(tcp|ssl):\/\//i, label: 'Connexion à un pool de cryptominage', weight: 40, hard: true },
  { re: /xmrig/i, label: 'Mineur de cryptomonnaie (XMRig)', weight: 35, hard: true }
];

const SCRIPT_PATTERNS = [
  { re: /powershell[^\n]{0,120}\s-e(nc|ncodedcommand)?\s+[A-Za-z0-9+\/=]{20,}/i, label: 'PowerShell avec commande encodée', weight: 40, hard: true },
  { re: /(invoke-expression|\biex\b)[^\n]{0,120}(downloadstring|downloadfile|invoke-webrequest|net\.webclient)/i, label: 'Téléchargement + exécution en mémoire (PowerShell)', weight: 40, hard: true },
  { re: /(downloadstring|downloadfile|net\.webclient)[^\n]{0,120}(invoke-expression|\biex\b)/i, label: 'Téléchargement + exécution en mémoire (PowerShell)', weight: 40, hard: true },
  { re: /mshta(\.exe)?\s+(https?:|vbscript:|javascript:)/i, label: 'mshta lance un script distant', weight: 35, hard: true },
  { re: /regsvr32[^\n]{0,80}\/i:https?:/i, label: 'regsvr32 charge un script distant', weight: 40, hard: true },
  { re: /rundll32[^\n]{0,80}javascript:/i, label: 'rundll32 exécute du JavaScript', weight: 40, hard: true },
  { re: /certutil[^\n]{0,60}-(urlcache|decode)/i, label: 'certutil détourné (téléchargement/décodage)', weight: 30, hard: true },
  { re: /bitsadmin[^\n]{0,40}\/transfer/i, label: 'bitsadmin détourné pour télécharger', weight: 30, hard: true },
  { re: /schtasks[^\n]{0,30}\/create/i, label: 'Création de tâche planifiée (persistance)', weight: 15, hard: false },
  { re: /reg(\.exe)?\s+add[^\n]{0,100}\\run\b/i, label: 'Ajout au démarrage Windows (persistance)', weight: 20, hard: false },
  { re: /-(windowstyle|w)\s+hidden|\s-nop\b/i, label: 'Exécution PowerShell masquée', weight: 15, hard: false },
  { re: /wscript\.shell/i, label: 'Objet WScript.Shell', weight: 15, hard: false },
  { re: /adodb\.stream/i, label: 'Objet ADODB.Stream (écriture de fichiers)', weight: 15, hard: false },
  { re: /eval\s*\(\s*(unescape|atob|string\.fromcharcode)/i, label: 'Code obfusqué (eval + décodage)', weight: 25, hard: false },
  { re: /frombase64string/i, label: 'Décodage base64 à l\'exécution', weight: 15, hard: false },
  { re: /[A-Za-z0-9+\/]{300,}={0,2}/, label: 'Gros bloc encodé en base64', weight: 15, hard: false },
  { re: /sekurlsa::(logonpasswords|pth)|invoke-mimikatz/i, label: 'Outil de vol d\'identifiants Windows (Mimikatz)', weight: 45, hard: true },
  { re: /comsvcs\.dll[^\n]{0,40}minidump/i, label: 'Copie de la mémoire LSASS (vol de mots de passe)', weight: 45, hard: true },
  { re: /set-mppreference[^\n]{0,80}-disable(realtimemonitoring|behaviormonitoring|ioavprotection)\s+\$?(true|1)/i, label: 'Désactivation de Windows Defender', weight: 40, hard: true },
  { re: /add-mppreference[^\n]{0,60}-exclusion(path|process|extension)/i, label: 'Ajout d\'une exclusion Windows Defender', weight: 30, hard: true },
  { re: /wmic[^\n]{0,40}shadowcopy\s+delete/i, label: 'Suppression des copies de sauvegarde via WMI (typique rançongiciel)', weight: 45, hard: true },
  { re: /amsiInitFailed|amsiContext[^\n]{0,60}(0x|\[int)/i, label: 'Contournement de l\'antivirus Windows (AMSI)', weight: 40, hard: true },
  { re: /bash\s+-i\s+>&\s*\/dev\/tcp\/|\bnc(at)?\s+(-\w+\s+)*-e\s+\/bin\/(ba)?sh/i, label: 'Shell inversé (prise de contrôle à distance)', weight: 45, hard: true },
  { re: /(files|data|documents)[^\n]{0,40}(have been|are|were)\s+(encrypted|locked)[\s\S]{0,500}(bitcoin|monero|\bbtc\b|\.onion)/i, label: 'Note de rançon (fichiers chiffrés + paiement crypto)', weight: 50, hard: true },
  { re: /wevtutil[^\n]{0,20}\bcl\b/i, label: 'Effacement des journaux Windows', weight: 20, hard: false },
  { re: /netsh\s+advfirewall[^\n]{0,60}state\s+off/i, label: 'Désactivation du pare-feu Windows', weight: 25, hard: false },
  { re: /net\s+user\s+\S+\s+\S+\s+\/add/i, label: 'Création d\'un compte utilisateur', weight: 20, hard: false },
  { re: /start-bitstransfer/i, label: 'Téléchargement via BITS (PowerShell)', weight: 10, hard: false },
  { re: /-executionpolicy\s+bypass/i, label: 'Contournement de la politique d\'exécution PowerShell', weight: 8, hard: false },
  { re: /(curl|wget)[^\n|]{0,100}\|\s*(ba)?sh\b/i, label: 'Téléchargement exécuté directement (curl | sh)', weight: 8, hard: false }
];

const INJECTION_APIS = ['VirtualAllocEx', 'WriteProcessMemory', 'CreateRemoteThread', 'NtUnmapViewOfSection', 'QueueUserAPC', 'SetThreadContext', 'NtWriteVirtualMemory'];
const SPY_APIS = ['SetWindowsHookEx', 'GetAsyncKeyState', 'URLDownloadToFile', 'AdjustTokenPrivileges', 'CryptEncrypt'];
const PACKER_SECTIONS = ['UPX0', 'UPX1', 'UPX2', '.themida', '.vmp0', '.vmp1', '.mpress1', '.mpress2', '.aspack', '.adata', '.petite', '.enigma1', '.enigma2', '.packed', '.nsp0', '.nsp1', 'PEC2', '.boom'];

const S = (label, weight) => ({ label, weight, hard: false });
const H = (label, weight) => ({ label, weight, hard: true });
const N = (label) => ({ label, weight: 0, hard: false, note: true });

export function gradeFor(score) {
  return GRADES.find((g) => score <= g.max) || GRADES[GRADES.length - 1];
}

export function scoreOf(signals) {
  let hard = 0, soft = 0;
  for (const s of signals) { if (s.hard) hard += s.weight; else soft += s.weight; }
  return Math.min(100, hard + Math.min(soft, SOFT_CAP));
}

export function extOf(name) {
  let n = String(name || '').trim().replace(/\.(crdownload|part|tmp)$/i, '');
  const i = n.lastIndexOf('.');
  if (i < 0 || i === n.length - 1) return '';
  return n.slice(i + 1).toLowerCase().replace(/[^a-z0-9]/g, '');
}

export function nameFromUrl(url) {
  try { return decodeURIComponent(new URL(url).pathname.split('/').pop() || ''); } catch { return ''; }
}

export function parseDisposition(h) {
  if (!h) return '';
  const m = /filename\*\s*=\s*(?:UTF-8'[^']*')?"?([^";]+)"?/i.exec(h) || /filename\s*=\s*"?([^";]+)"?/i.exec(h);
  if (!m) return '';
  try { return decodeURIComponent(m[1]).split(/[\\/]/).pop(); } catch { return m[1].split(/[\\/]/).pop(); }
}

export function hostMatches(host, list) {
  host = String(host || '').toLowerCase();
  return list.some((d) => { d = String(d).toLowerCase().trim(); return d && (host === d || host.endsWith('.' + d)); });
}

export function calculateEntropy(u8) {
  if (!u8.length) return 0;
  const f = new Array(256).fill(0);
  for (let i = 0; i < u8.length; i++) f[u8[i]]++;
  let e = 0;
  for (let i = 0; i < 256; i++) if (f[i]) { const p = f[i] / u8.length; e -= p * Math.log2(p); }
  return e;
}

export function maxWindowEntropy(bytes, win = 4096) {
  if (bytes.length <= win) return { max: calculateEntropy(bytes), offset: 0 };
  let max = 0, offset = 0;
  for (let i = 0; i + win <= bytes.length; i += win) {
    const e = calculateEntropy(bytes.subarray(i, i + win));
    if (e > max) { max = e; offset = i; }
  }
  return { max, offset };
}

export async function sha256Hex(bytes) {
  try {
    const d = await crypto.subtle.digest('SHA-256', bytes);
    return [...new Uint8Array(d)].map((b) => b.toString(16).padStart(2, '0')).join('');
  } catch { return null; }
}

function at(b, i, ...sig) { for (let k = 0; k < sig.length; k++) if (b[i + k] !== sig[k]) return false; return true; }

export function detectKind(b) {
  const n = b.length;
  if (n < 2) return null;
  if (at(b, 0, 0x4D, 0x5A)) return 'exe';
  if (at(b, 0, 0x7F, 0x45, 0x4C, 0x46)) return 'elf';
  if (at(b, 0, 0xCF, 0xFA, 0xED, 0xFE) || at(b, 0, 0xCE, 0xFA, 0xED, 0xFE) || at(b, 0, 0xFE, 0xED, 0xFA, 0xCE) || at(b, 0, 0xFE, 0xED, 0xFA, 0xCF)) return 'macho';
  if (at(b, 0, 0xCA, 0xFE, 0xBA, 0xBE)) return 'class';
  if (n > 20 && at(b, 0, 0x4C, 0, 0, 0, 0x01, 0x14, 0x02, 0x00)) return 'lnk';
  const head = String.fromCharCode(...b.subarray(0, Math.min(1024, n)));
  if (head.includes('%PDF')) return 'pdf';
  if (at(b, 0, 0x50, 0x4B, 0x03, 0x04) || at(b, 0, 0x50, 0x4B, 0x05, 0x06)) return 'zip';
  if (at(b, 0, 0x52, 0x61, 0x72, 0x21)) return 'rar';
  if (at(b, 0, 0x37, 0x7A, 0xBC, 0xAF)) return '7z';
  if (at(b, 0, 0x1F, 0x8B)) return 'gz';
  if (at(b, 0, 0x42, 0x5A, 0x68)) return 'bz2';
  if (at(b, 0, 0xFD, 0x37, 0x7A, 0x58, 0x5A, 0x00)) return 'xz';
  if (at(b, 0, 0x28, 0xB5, 0x2F, 0xFD)) return 'zst';
  if (at(b, 0, 0x89, 0x50, 0x4E, 0x47)) return 'png';
  if (at(b, 0, 0xFF, 0xD8, 0xFF)) return 'jpg';
  if (at(b, 0, 0x47, 0x49, 0x46, 0x38)) return 'gif';
  if (at(b, 0, 0x42, 0x4D) && n > 14 && b[6] === 0 && b[7] === 0 && b[8] === 0 && b[9] === 0) return 'bmp';
  if (at(b, 0, 0x52, 0x49, 0x46, 0x46) && n > 12) {
    if (at(b, 8, 0x57, 0x45, 0x42, 0x50)) return 'webp';
    if (at(b, 8, 0x57, 0x41, 0x56, 0x45)) return 'wav';
    if (at(b, 8, 0x41, 0x56, 0x49, 0x20)) return 'avi';
  }
  if (at(b, 0, 0x00, 0x00, 0x01, 0x00)) return 'ico';
  if (at(b, 0, 0xD0, 0xCF, 0x11, 0xE0)) return 'ole';
  if (at(b, 0, 0x7B, 0x5C, 0x72, 0x74, 0x66)) return 'rtf';
  if (n > 12 && (at(b, 4, 0x66, 0x74, 0x79, 0x70) || at(b, 4, 0x6D, 0x6F, 0x6F, 0x76) || at(b, 4, 0x6D, 0x64, 0x61, 0x74) || at(b, 4, 0x77, 0x69, 0x64, 0x65) || at(b, 4, 0x66, 0x72, 0x65, 0x65))) return 'mp4';
  if (at(b, 0, 0x1A, 0x45, 0xDF, 0xA3)) return 'mkv';
  if (at(b, 0, 0x4F, 0x67, 0x67, 0x53)) return 'ogg';
  if (at(b, 0, 0x66, 0x4C, 0x61, 0x43)) return 'flac';
  if (at(b, 0, 0x49, 0x44, 0x33) || (b[0] === 0xFF && (b[1] & 0xE0) === 0xE0)) return 'mp3';
  if (at(b, 0, 0x53, 0x51, 0x4C, 0x69)) return 'sqlite';

  let s = 0;
  if (at(b, 0, 0xEF, 0xBB, 0xBF)) s = 3;
  const sample = String.fromCharCode(...b.subarray(s, Math.min(s + 600, n))).trimStart().toLowerCase();
  if (/^<!doctype html|^<html|^<head|^<body|^<meta|^<script/.test(sample)) return 'html';
  if (sample.startsWith('<svg')) return 'svg';
  if (sample.startsWith('<?xml')) return 'xml';
  if (sample.startsWith('#!') || sample.startsWith('@echo off')) return 'script';
  const lim = Math.min(4096, n);
  let bin = 0;
  for (let i = 0; i < lim; i++) { const c = b[i]; if (c < 9 || (c > 13 && c < 32)) bin++; }
  return bin === 0 ? 'text' : null;
}

function u16(b, o) { return b[o] | (b[o + 1] << 8); }
function u32(b, o) { return (b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0; }
function ascii(b, o, len) { let s = ''; for (let i = 0; i < len && o + i < b.length; i++) s += String.fromCharCode(b[o + i]); return s; }

export function inspectFilename(filename) {
  const out = [];
  if (/\u202E/.test(filename)) out.push(H('Caractère Unicode trompeur (RTLO) dans le nom', 40));
  const parts = filename.split('.');
  if (parts.length > 2) {
    const last = parts[parts.length - 1].toLowerCase();
    const prev = parts[parts.length - 2].toLowerCase().trim();
    if ((SCRIPTY.has(last) || NATIVE_EXE.has(last)) && DOCLIKE.includes(prev)) out.push(H(`Double extension suspecte (.${prev}.${last})`, 45));
  }
  if (/\s{3,}\.\w+$/.test(filename)) out.push(S('Extension masquée par des espaces', 25));
  if (/\.(exe|scr|com|pif|lnk|hta|vbs|js|bat|cmd|ps1)[\s.]+$/i.test(filename)) out.push(S('Point/espace après l\'extension (contournement de filtres)', 15));
  if (BAIT_EXT.has(extOf(filename)) && BAIT_RE.test(filename)) out.push(S('Nom évoquant un document (leurre classique) sur un exécutable', 15));
  return out;
}

export function inspectUrl(urlObj) {
  const out = [];
  const host = urlObj.hostname.toLowerCase();
  if (BLACKLIST.some((d) => host === d || host.endsWith('.' + d))) out.push(H('Domaine sur liste noire', 50));
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host) || host.startsWith('[')) out.push(S('Téléchargement depuis une adresse IP brute', 15));
  const tld = SUSPICIOUS_TLDS.find((t) => host.endsWith(t));
  if (tld) out.push(S(`Domaine à extension à risque (${tld})`, 10));
  if (host.split('.').some((p) => p.startsWith('xn--'))) out.push(S('Nom de domaine en punycode (risque d\'imitation)', 12));
  for (const d of TRUSTED_HOSTS) {
    const i = host.indexOf(d + '.');
    if (i < 0 || (i > 0 && host[i - 1] !== '.') || hostMatches(host, [d])) continue;
    const rest = host.slice(i + d.length + 1);
    if (rest && !/^([a-z]{2}|com?|org|net)(\.[a-z]{2})?$/.test(rest)) { out.push(S(`Faux sous-domaine imitant ${d}`, 20)); break; }
  }
  if (urlObj.username) out.push(S('Identifiants dans l\'URL (technique de leurre)', 15));
  if (/%2e%2e|%252e|\.\.%2f/i.test(urlObj.pathname)) out.push(S('Manipulation d\'URL suspecte (encodage/traversée de chemin)', 15));
  return out;
}

export function inspectPE(b, text) {
  const out = [];
  out.signed = false;
  if (b.length <= 0x40 || b[0] !== 0x4D || b[1] !== 0x5A) return out;
  const pe = u32(b, 0x3C);
  const valid = pe > 0 && pe + 24 <= b.length && b[pe] === 0x50 && b[pe + 1] === 0x45 && b[pe + 2] === 0 && b[pe + 3] === 0;
  let packer = null;
  if (!valid) { out.push(S('En-tête PE incohérent (fichier corrompu ou trafiqué)', 20)); }
  else {
    const nSec = Math.min(u16(b, pe + 6), 96);
    const tbl = pe + 24 + u16(b, pe + 20);
    let weird = false, rwx = false;
    for (let i = 0; i < nSec; i++) {
      const off = tbl + i * 40;
      if (off + 40 > b.length) break;
      const name = ascii(b, off, 8).replace(/\0+$/, '');
      const chars = u32(b, off + 36);
      if (PACKER_SECTIONS.some((p) => p.toLowerCase() === name.toLowerCase())) packer = packer || name;
      else if (name && /[^\x20-\x7E]/.test(name)) weird = true;
      if ((chars & 0x20000000) && (chars & 0x80000000)) rwx = true;
    }
    // Authenticode : entrée « Security » du répertoire de données (présence seulement, signature non vérifiée)
    const opt = pe + 24, magic = u16(b, opt), dd = opt + (magic === 0x20B ? 112 : 96);
    if ((magic === 0x10B || magic === 0x20B) && dd + 40 <= b.length) out.signed = u32(b, dd + 32) > 0 && u32(b, dd + 36) >= 8;
    if (packer) out.push(S(`Exécutable compressé/protégé par un packer (section ${packer})`, 15));
    if (weird) out.push(S('Noms de sections PE illisibles (obfuscation)', 10));
    if (rwx) out.push(S('Section exécutable ET inscriptible (code auto-modifiable)', 12));
  }
  const inj = INJECTION_APIS.filter((a) => text.includes(a));
  const spy = SPY_APIS.filter((a) => text.includes(a));
  if (inj.length >= 3) out.push(S(`Combinaison d'API d'injection de code (${inj.slice(0, 4).join(', ')})`, 30));
  else if (inj.length >= 2 && spy.length >= 2) out.push(S(`API d'injection + espionnage (${[...inj, ...spy].slice(0, 4).join(', ')})`, 22));
  else if (text.includes('SetWindowsHookEx') && text.includes('GetAsyncKeyState')) out.push(S('API de capture clavier (SetWindowsHookEx + GetAsyncKeyState)', 25));
  if (inj.length >= 3 && packer && !out.signed) out.push(H('Profil typique d\'injecteur : packé + injection de code + non signé', 30));
  const store = ['Login Data', 'Local State', 'os_crypt', 'encrypted_key'].filter((a) => text.includes(a)).length;
  const exfil = /discord(app)?\.com\/api\/webhooks|api\.telegram\.org\/bot/i.test(text);
  if (store >= 2 && exfil) out.push(H('Voleur de mots de passe : données du navigateur + envoi vers Discord/Telegram', 50));
  else if (store >= 3) out.push(S('Accès aux données de navigateur (mots de passe, cookies)', 20));
  return out;
}

export function inspectLnk(b, text) {
  const flat = text.replace(/\0/g, '');
  if (/(powershell|cmd(\.exe)?\s*\/[ck]|mshta|wscript|cscript|rundll32|regsvr32|certutil|bitsadmin)/i.test(flat)) return [H('Raccourci Windows (.lnk) qui lance une commande ou un script', 50)];
  return [];
}

export function inspectOffice(b, text, ext) {
  const out = [];
  const flat = text.replace(/\0/g, '');
  if (!/VBA|Macros|_VBA_PROJECT/.test(flat)) return out;
  const auto = /auto_?open|document_?open|workbook_?open|autoexec|auto_?close/i.test(flat);
  const exec = /shell|createobject|powershell|wscript|urldownloadtofile/i.test(flat);
  if (auto && exec) out.push(H('Macro Office à exécution automatique qui lance des commandes', 40));
  else out.push(S('Document Office avec macro intégrée', 20));
  return out;
}

export function parseZip(tail, total) {
  const res = { names: [], encrypted: 0, ratio: 0, ok: false };
  if (!tail || tail.length < 46) return res;
  let start = -1;
  for (let i = 0; i + 4 <= tail.length; i++) if (tail[i] === 0x50 && tail[i + 1] === 0x4B && tail[i + 2] === 0x01 && tail[i + 3] === 0x02) { start = i; break; }
  if (start < 0) return res;
  let p = start, c = 0, usz = 0, csz = 0;
  while (p + 46 <= tail.length && tail[p] === 0x50 && tail[p + 1] === 0x4B && tail[p + 2] === 0x01 && tail[p + 3] === 0x02 && c < 3000) {
    const flags = u16(tail, p + 8);
    const cs = u32(tail, p + 20), us = u32(tail, p + 24);
    const nl = u16(tail, p + 28), el = u16(tail, p + 30), cl = u16(tail, p + 32);
    if (p + 46 + nl > tail.length) break;
    res.names.push(ascii(tail, p + 46, nl));
    if (flags & 1) res.encrypted++;
    csz += cs; usz += us; c++;
    p += 46 + nl + el + cl;
  }
  res.ok = c > 0;
  res.ratio = csz > 0 ? usz / csz : 0;
  return res;
}

export function inspectZip(zip, ext) {
  const out = [];
  if (!zip.ok) return out;
  const names = zip.names;
  const lower = names.map((n) => n.toLowerCase());
  if (names.some((n) => /(^|[\\/])\.\.([\\/]|$)/.test(n))) out.push(H('Archive avec chemins "../" (écrasement de fichiers système)', 40));
  const dbl = names.find((n) => /\.(pdf|docx?|xlsx?|jpe?g|png|txt)\s*\.(exe|scr|js|vbs|bat|cmd|com|pif|lnk|hta|ps1)$/i.test(n));
  if (dbl) out.push(H(`Double extension à l'intérieur de l'archive (${dbl.split('/').pop()})`, 45));
  if (zip.encrypted > 0) out.push(S('Archive protégée par mot de passe (contenu non analysable)', 20));
  if (ext === 'zip' || ext === '') {
    const exe = names.find((n, i) => { const e = extOf(lower[i]); return NATIVE_EXE.has(e) || SCRIPTY.has(e); });
    if (exe) out.push(S(`Archive contenant un exécutable/script (${exe.split('/').pop()})`, 15));
    if (exe && zip.encrypted > 0) out.push(H('Archive chiffrée contenant un exécutable (contourne les analyses)', 25));
  }
  if (lower.some((n) => n.endsWith('vbaproject.bin'))) {
    if (OFFICE_PLAIN.has(ext)) out.push(H(`Macro VBA cachée dans un document .${ext}`, 35));
    else out.push(S('Document Office avec macro VBA intégrée', 20));
  }
  if (zip.ratio > 1000) out.push(S(`Taux de compression extrême (x${Math.round(zip.ratio)}), risque de bombe ZIP`, 20));
  return out;
}

/**
 * ctx = { url, filename, ext?, ctype?, bytes?, tail?, total?, trusted?, reliable? }
 * Retourne { signals, kind, entropy, offset }
 */
export function analyze(ctx) {
  const sig = [];
  const filename = ctx.filename || '';
  const ext = ctx.ext !== undefined ? ctx.ext : extOf(filename);
  const isExecExt = NATIVE_EXE.has(ext) || SCRIPTY.has(ext);
  let checks = 6, signed = false; // URL, liste noire, nom, extension, type annoncé, hébergeur

  try { sig.push(...inspectUrl(new URL(ctx.url))); } catch { /* URL illisible */ }
  if (isExecExt) sig.push(S('Format exécutable ou script (intrinsèquement risqué)', 12));
  try {
    const u = new URL(ctx.url);
    if (u.protocol === 'http:' && isExecExt) sig.push(S('Exécutable téléchargé sans chiffrement (HTTP)', 10));
    if (isExecExt && hostMatches(u.hostname, DYNDNS)) sig.push(S('Exécutable servi depuis un DNS dynamique', 12));
    if (isExecExt && hostMatches(u.hostname, EPHEMERAL_HOSTS)) sig.push(S('Exécutable hébergé sur un service de partage anonyme/éphémère', 15));
  } catch { /* ignore */ }
  sig.push(...inspectFilename(filename));

  const ctype = String(ctx.ctype || '').toLowerCase();
  if (/x-msdownload|x-dosexec|portable-executable|x-msdos-program/.test(ctype) && !NATIVE_EXE.has(ext) && ext !== '') {
    sig.push(H(`Le serveur annonce un exécutable mais le fichier se nomme .${ext}`, 40));
  }

  let kind = null, entropy = 0, offset = 0;
  const bytes = ctx.bytes;
  const reliable = ctx.reliable !== false && !(ctype.includes('text/html') && !['html', 'htm', 'php', 'asp', 'aspx'].includes(ext));

  if (bytes && bytes.length > 4) {
    if (!reliable) {
      sig.push(N('Contenu non vérifiable (le serveur a renvoyé une page web, connexion ou lien à usage unique)'));
    } else {
      kind = detectKind(bytes); checks += 3;
      if (kind === 'lnk' && ext !== 'lnk') sig.push(H(`Raccourci Windows (.lnk) caché sous l'extension .${ext || '?'}`, 50));
      const expected = EXT_KINDS[ext];
      const latin = new TextDecoder('latin1').decode(bytes);
      const lower = latin.toLowerCase();

      if ((kind === 'exe' || kind === 'elf' || kind === 'macho') && !NATIVE_EXE.has(ext)) {
        if (expected) sig.push(H(`Exécutable (${kind.toUpperCase()}) caché sous l'extension .${ext}`, 70));
        else if (ext === '' || ['bin', 'dat', 'tmp', 'download'].includes(ext)) sig.push(S('Exécutable sans extension explicite', 20));
        else if (!SCRIPTY.has(ext)) sig.push(S(`Exécutable (${kind.toUpperCase()}) sous une extension inhabituelle (.${ext})`, 20));
      } else if (expected && kind && !expected.includes(kind)) {
        const bothImages = IMAGE_KINDS.has(kind) && IMAGE_KINDS.has(expected[0]);
        if (!bothImages && !(kind === 'text' && TEXTY.has(ext))) sig.push(S(`Contenu inattendu (détecté : ${kind}, attendu : .${ext})`, 12));
      } else if (expected && !kind && ext === 'pdf') {
        sig.push(S('Fichier .pdf sans en-tête PDF valide', 15));
      } else if (!expected && TEXTY.has(ext) && ['zip', 'rar', '7z', 'gz', 'ole', 'pdf'].includes(kind)) {
        sig.push(S(`Contenu inattendu (détecté : ${kind}, attendu : .${ext})`, 12));
      }

      const risky = isExecExt || ext === '' || ext === 'txt' || ['exe', 'elf', 'macho', 'script'].includes(kind);
      for (const p of STRONG_PATTERNS) if (p.re.test(latin)) sig.push(p.hard ? H(p.label, p.weight) : S(p.label, p.weight));
      checks += STRONG_PATTERNS.length;
      if (risky) {
        const seen = new Set(), hits = [];
        for (const p of SCRIPT_PATTERNS) {
          if (seen.has(p.label) || !p.re.test(latin)) continue;
          seen.add(p.label); hits.push(p);
        }
        checks += SCRIPT_PATTERNS.length;
        // Anti faux positif : un simple document texte/HTML qui *parle* d'une technique (tuto, article de sécurité) n'est pas une preuve
        const docLike = !isExecExt && ['text', 'html', 'xml', 'svg'].includes(kind);
        const hardHits = hits.filter((p) => p.hard).length;
        for (const p of hits) {
          if (docLike && p.hard && hardHits < 2) sig.push(S(`${p.label} (simple mention dans un document)`, Math.min(p.weight, 20)));
          else sig.push(p.hard ? H(p.label, p.weight) : S(p.label, p.weight));
        }
      }
      if ([null, 'text', 'html', 'script', 'xml', 'svg'].includes(kind)) {
        checks += 2;
        if (/["'`\s=:]TV(qQAAMA|pQAAIA|oAAAAA|qAAAEA)[A-Za-z0-9+\/]{800,}/.test(latin)) sig.push(H('Exécutable Windows encodé en base64 dissimulé dans le fichier', 50));
        if ((kind === 'svg' || ext === 'svg') && /<script[\s>]|\son(load|click|error)\s*=/i.test(latin)) sig.push(S('SVG contenant du script actif (technique de phishing)', 20));
        if (kind === 'html' && /new\s+blob\s*\(/i.test(latin) && /(atob\(|new\s+uint8array)/i.test(latin) && /(createobjecturl|mssaveorOpenblob)/i.test(lower) && /\.click\(\)|\.download\s*=/i.test(latin) && /[A-Za-z0-9+\/]{2000,}/.test(latin)) sig.push(S('HTML smuggling : fichier reconstruit et déposé par le navigateur', 30));
      }

      if (kind === 'exe') {
        const pes = inspectPE(bytes, latin); signed = !!pes.signed; checks += 5;
        sig.push(...pes.map((x) => ({ ...x, src: 'pe' })));
        if (signed) sig.push(N('Signature numérique présente (non vérifiée localement)'));
      }
      if (kind === 'lnk') { sig.push(...inspectLnk(bytes, latin)); checks += 1; }
      if (kind === 'ole') { sig.push(...inspectOffice(bytes, latin, ext)); checks += 1; }
      if (IMAGE_KINDS.has(kind)) checks += 1;
      if (IMAGE_KINDS.has(kind) && /<script[\s>]|powershell|cmd\.exe/i.test(latin)) sig.push(H('Contenu exécutable caché dans une image (fichier polyglotte)', 60));
      if (kind === 'zip') {
        const tail = ctx.tail && ctx.tail.length ? ctx.tail : (ctx.total && ctx.total <= bytes.length ? bytes : (bytes.length < HEAD_BYTES ? bytes : null));
        if (tail) { sig.push(...inspectZip(parseZip(tail, ctx.total), ext)); checks += 6; }
        else sig.push(N('Archive volumineuse : contenu non inspecté (fin de fichier indisponible)'));
      }

      if (['exe', 'elf', 'macho', null, 'script'].includes(kind) && (isExecExt || ext === '' || ['bin', 'dat'].includes(ext))) {
        const e = maxWindowEntropy(bytes);
        entropy = e.max; offset = e.offset;
        checks += 1;
        if (e.max > 7.5) sig.push({ ...S(`Section fortement compressée/chiffrée (entropie ${e.max.toFixed(2)})`, 25), src: 'pe' });
        else if (e.max > 7.2) sig.push({ ...S(`Entropie élevée (${e.max.toFixed(2)})`, 8), src: 'pe' });
      } else {
        entropy = calculateEntropy(bytes.subarray(0, 4096));
      }
    }
  }

  // Binaire signé : les indices structurels (packer, entropie, API) pèsent moitié moins
  if (signed) for (const x of sig) if (x.src === 'pe' && !x.hard && x.weight > 0) x.weight = Math.ceil(x.weight / 2);
  let signals = sig;
  if (ctx.trusted) {
    const dropped = sig.filter((s) => !s.hard && !s.note && s.weight > 0);
    signals = sig.filter((s) => s.hard || s.note || s.weight === 0);
    if (dropped.length) signals.push(N(`Source de confiance : ${dropped.length} indice(s) mineur(s) ignoré(s)`));
  }
  return { signals, kind, entropy, offset, checks, signed };
}
