// Interrupteur général : clé unique, sans dépendance (importable partout, y compris content/offscreen).
export const POWER_KEY = 'power';

export async function getPower() {
  try { const r = await chrome.storage.local.get(POWER_KEY); return r[POWER_KEY] !== false; } catch { return true; }
}

export async function setPower(on) {
  await chrome.storage.local.set({ [POWER_KEY]: !!on });
}
