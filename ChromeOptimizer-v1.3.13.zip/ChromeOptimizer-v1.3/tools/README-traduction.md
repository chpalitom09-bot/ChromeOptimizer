# Traduire la page Réglages

Chaque langue a son fichier `_locales/<dossier>/settings.json` (fr, en, de, es, it, pt_PT, ru, zh_CN, ja, ko, ar).

1. Ouvre `_locales/en/settings.json` (référence complète) et copie son contenu dans le fichier de ta langue.
2. Traduis uniquement les **valeurs** (jamais les clés). Les lignes `_section_…` et `_meta` sont des commentaires.
3. Garde intacts : `{n}`, `{cur}`… (variables), les balises `<b> <span> <a href> <code>` et les liens.
4. Pluriels : `.one` et `.other` (ajoute `.few`, `.many`, `.two`, `.zero` si ta langue en a besoin, ex. ru, ar).
5. Vérifie : `node tools/check-settings.mjs de` (ou sans argument pour toutes les langues).

Une clé absente retombe sur l'anglais, puis sur le français : tu peux traduire petit à petit.

Nouvelle langue : ajoute-la dans `LANGS`, `LOCALE`, `FLAGS` de `i18n.js` (et `PACK_DIR` si le dossier n'est pas le code), crée `_locales/<dossier>/messages.json` + `settings.json`.
