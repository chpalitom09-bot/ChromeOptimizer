// Vérifie les traductions de la page Réglages : node tools/check-settings.mjs [code]
// Compare chaque _locales/<dossier>/settings.json à en/settings.json (référence complète).
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', '_locales');
const load = (dir) => {
  const j = JSON.parse(fs.readFileSync(path.join(root, dir, 'settings.json'), 'utf8'));
  return Object.fromEntries(Object.entries(j).filter(([k, v]) => !k.startsWith('_') && typeof v === 'string'));
};
const holders = (s) => [...s.matchAll(/\{(\w+)\}/g)].map((m) => m[1]).sort().join(',');
const tags = (s) => [...s.matchAll(/<\/?\w+[^>]*>/g)].map((m) => m[0].replace(/\s+/g, ' ')).sort().join('|');
const tagNames = (s) => [...s.matchAll(/<\/?(\w+)/g)].map((m) => m[1]).sort().join(',');

const ref = load('en');
const only = process.argv[2];
const dirs = fs.readdirSync(root).filter((d) => fs.existsSync(path.join(root, d, 'settings.json')) && d !== 'en');
let bad = 0;
for (const dir of dirs) {
  if (only && !dir.startsWith(only)) continue;
  const tr = load(dir);
  const missing = Object.keys(ref).filter((k) => !(k in tr));
  const extra = Object.keys(tr).filter((k) => !(k in ref));
  const issues = [];
  for (const k of Object.keys(tr)) {
    if (!(k in ref)) continue;
    if (!tr[k].trim()) issues.push(`${k}: valeur vide`);
    if (!/\.(zero|one|two|few|many)$/.test(k) && holders(tr[k]) !== holders(ref[k])) issues.push(`${k}: variables {…} différentes (attendu : ${holders(ref[k]) || 'aucune'})`);
    if (tagNames(tr[k]) !== tagNames(ref[k])) issues.push(`${k}: balises HTML différentes`);
    else if (/href=/.test(ref[k]) && tags(tr[k]) !== tags(ref[k])) issues.push(`${k}: lien/attributs modifiés (garde href, target, rel identiques)`);
  }
  const done = Object.keys(ref).length - missing.length;
  console.log(`\n${dir}: ${done}/${Object.keys(ref).length} clés traduites`);
  if (missing.length) console.log(`  manquantes (${missing.length}) : ${missing.slice(0, 12).join(', ')}${missing.length > 12 ? ' …' : ''}`);
  extra.forEach((k) => console.log(`  clé inconnue : ${k}`));
  issues.forEach((i) => console.log('  ⚠ ' + i));
  if (extra.length || issues.length) bad++;
}
console.log(bad ? `\n${bad} langue(s) avec des erreurs.` : '\nAucune erreur (les clés manquantes retombent sur l\'anglais).');
process.exit(bad ? 1 : 0);
