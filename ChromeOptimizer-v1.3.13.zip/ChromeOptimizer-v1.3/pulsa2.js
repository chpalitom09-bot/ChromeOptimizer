import { priorP, PULSA_DEFAULTS } from './pulsa.js';
import { blendWait } from './brain.js';

export const P2 = {
  minGain:  { prudent: 15, balanced: 10, aggressive: 6 },
  miss:     { prudent: 0.10, balanced: 0.20, aggressive: 0.30 },
  floorMin: 3,
  margin: 1,
  maxPreload: 120,
  preloadMinP: 0.35,
  hold: 12,
  minObs: 6,
  globW: 0.35,
  H: 360
};

const GRID = [2, 5, 10, 15, 30, 60, 120, 360];

function samples(rec, glob, t, cfg) {
  const out = []; let nObs = 0;
  const add = (iv, mult) => {
    const n = iv.length;
    for (let i = 0; i < n; i++) {
      const w = mult * Math.pow(cfg.recency, n - 1 - i), x = iv[i];
      nObs += mult;
      if (x > 0) { if (x > t) out.push([x - t, w]); }
      else if (-x - t >= P2.H) out.push([Infinity, w]);
    }
  };
  if (rec && rec.iv.length) add(rec.iv, 1);
  if (glob && glob.iv.length) add(glob.iv, P2.globW);
  const a = cfg.priorWeight * 6 / (6 + nObs);
  let prev = 0, lo = 0;
  for (const h of GRID) {
    const F = priorP(t, h, cfg);
    out.push([(lo + h) / 2, a * (F - prev)]);
    prev = F; lo = h;
  }
  out.push([Infinity, a * (1 - prev)]);
  return { out, nObs };
}

export function forecast(rec, glob, t, qMiss, cfg = PULSA_DEFAULTS) {
  const { out, nObs } = samples(rec, glob, t, cfg);
  out.sort((a, b) => a[0] - b[0]);
  let W = 0; for (const s of out) W += s[1];
  let cum = 0, wait = null, pRet = 0;
  for (const [r, w] of out) {
    if (r > P2.H) break;
    cum += w;
    pRet = cum / W;
    if (wait === null && pRet >= qMiss) wait = r;
  }
  return { pRet, wait, nObs };
}

function caution(rec, t, cfg) {
  if (!rec) return 0;
  const fpRate = rec.fp / (rec.fp + rec.ok + 3);
  return Math.min(cfg.fpCap, fpRate * cfg.fpStrength) * Math.exp((-Math.LN2 * t) / (2 * cfg.halfLifeMin));
}

export function missFactor(p2, q) {
  if (!p2 || p2.hit + p2.miss < 6) return 1;
  const r = p2.miss / (p2.hit + p2.miss);
  return Math.min(1.3, Math.max(0.5, q / Math.max(r, 0.02)));
}

export function decide(rec, glob, idleMin, o) {
  const cfg = PULSA_DEFAULTS;
  const f = forecast(rec, glob, idleMin, 0.5, cfg);
  if (f.nObs < P2.minObs) return { act: 'legacy', pRet: f.pRet, wait: null };
  const q = Math.min(0.5, P2.miss[o.sens] * (1 - caution(rec, idleMin, cfg)) * missFactor(o.p2, P2.miss[o.sens]));
  const minGain = Math.min(30, Math.max(3, P2.minGain[o.sens] / (o.factor || 1)));
  const r = forecast(rec, glob, idleMin, q, cfg);
  if (r.wait === null) return { act: 'sleep', pRet: r.pRet, wait: null };
  const wait = o.brain ? blendWait(r.wait, idleMin, q, o.brain) : r.wait;
  const gain = wait - P2.margin;
  if (gain < minGain) return { act: 'keep', pRet: r.pRet, wait };
  const reload = o.canPreload && !o.preloaded && r.pRet >= P2.preloadMinP && gain <= P2.maxPreload;
  return reload ? { act: 'sleep', wake: gain, pRet: r.pRet, wait } : { act: 'sleep', pRet: r.pRet, wait };
}
