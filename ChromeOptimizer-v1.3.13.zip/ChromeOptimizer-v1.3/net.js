export function offline() {
  try {
    const c = navigator.connection;
    return navigator.onLine === false || !!(c && (c.effectiveType === 'slow-2g' || c.effectiveType === '2g'));
  } catch { return false; }
}
