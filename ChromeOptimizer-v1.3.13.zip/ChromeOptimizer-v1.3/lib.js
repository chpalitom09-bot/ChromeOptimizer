import { pulsaScore, SENSITIVITY, effectiveThreshold, emptyTune, memoryFactor, tuneFactor } from './pulsa.js';
import { decide, P2 } from './pulsa2.js';
import { feat } from './brain.js';
import { offline } from './net.js';
import { loadModel, markSlept, pruneModel, loadP2, loadSnap, loadBrain } from './pulsa-store.js';
import { getEco, ECO_NONE } from './eco.js';
import { armPreload } from './preload.js';
import { safeReason, loadAudioSeen } from './safe.js';
import { getPower } from './power.js';

export const DEFAULTS = {
  mode: 'auto',
  algorithm: 'pulsa2',
  pulsaLast: 'pulsa2',
  sensitivity: 'balanced',
  idleMinutes: 30,
  duplicates: 'manual',
  protectedSites: [],
  history: true,
  favorites: [],
  offlineGuard: true,
  adaptMemory: true,
  autoTune: true,
  brain: true,
  adaptiveInterval: true,
  safe: true,
  bswpPending: false,
  bswp: false,
  onePwWindowOnly: false,
  ecoOptimizer: false,
  lang: '',
  updateCheck: true,
  theme: 'auto',
  accent: '',
  radius: 'round'
};
const THEMES = ['auto', 'light', 'dark', 'blue', 'graphite', 'green', 'pink'];
export const MIN_IDLE = 5;
export const isPulsa = (s) => s.algorithm !== 'classic';

export async function getSettings() {
  const { settings } = await chrome.storage.local.get('settings');
  const s = { ...DEFAULTS, ...(settings || {}) };
  s.idleMinutes = Math.max(MIN_IDLE, Number(s.idleMinutes) || DEFAULTS.idleMinutes);
  if (!Array.isArray(s.protectedSites)) s.protectedSites = [];
  if (!Array.isArray(s.favorites)) s.favorites = [];
  s.history = s.history !== false;
  ['adaptMemory', 'autoTune', 'adaptiveInterval', 'updateCheck', 'safe', 'offlineGuard'].forEach((k) => { s[k] = s[k] !== false; });
  s.brain = s.brain !== false;
  s.bswp = s.bswp === true;
  s.bswpPending = s.bswpPending === true;
  s.ecoOptimizer = s.ecoOptimizer === true;
  s.onePwWindowOnly = s.onePwWindowOnly === true;
  if (!['pulsa2', 'pulsa', 'classic'].includes(s.algorithm)) s.algorithm = DEFAULTS.algorithm;
  if (!['pulsa2', 'pulsa'].includes(s.pulsaLast)) s.pulsaLast = DEFAULTS.pulsaLast;
  if (!(s.sensitivity in SENSITIVITY)) s.sensitivity = DEFAULTS.sensitivity;
  if (!THEMES.includes(s.theme)) s.theme = DEFAULTS.theme;
  if (!/^#[0-9a-fA-F]{6}$/.test(s.accent || '')) s.accent = '';
  s.radius = s.radius === 'sharp' ? 'sharp' : 'round';
  return s;
}

export async function saveSettings(patch) {
  const next = { ...(await getSettings()), ...patch };
  await chrome.storage.local.set({ settings: next });
  return next;
}

export async function getStats() {
  const { stats } = await chrome.storage.local.get('stats');
  return { slept: 0, closed: 0, runs: 0, lastRun: 0, ...(stats || {}) };
}

export async function resetStats() {
  await chrome.storage.local.remove('stats');
}

export function hostOf(url) {
  try { return new URL(url).hostname.toLowerCase().replace(/^www\./, ''); }
  catch { return ''; }
}

export function normalizeSites(text) {
  const out = [];
  String(text || '').split(/[\s,;]+/).forEach((raw) => {
    let d = raw.trim().toLowerCase().replace(/^[a-z][a-z0-9+.-]*:\/\//, '').split(/[/?#]/)[0].replace(/^www\./, '');
    if (d && !out.includes(d)) out.push(d);
  });
  return out;
}

export function isProtectedSite(url, sites) {
  const h = hostOf(url);
  return !!h && sites.some((d) => h === d || h.endsWith('.' + d));
}

const TRACKING = /^(utm_|fbclid$|gclid$|msclkid$|mc_eid$|igshid$|yclid$)/i;

export function normalizeUrl(raw) {
  try {
    const u = new URL(raw);
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return null;
    if (!/^#[!/]/.test(u.hash)) u.hash = '';
    [...u.searchParams.keys()].forEach((k) => { if (TRACKING.test(k)) u.searchParams.delete(k); });
    if (u.pathname.length > 1 && u.pathname.endsWith('/')) u.pathname = u.pathname.slice(0, -1);
    return u.toString();
  } catch { return null; }
}

export function analyze(tabs, settings, now = Date.now(), model = null, ctx = {}) {
  const idleMs = settings.idleMinutes * 60000;
  const web = (t) => /^https?:/i.test(t.url || '');
  const safe = (t) => settings.safe && !!safeReason(t, ctx.audioSeen, now);
  const guarded = (t) => t.active || t.pinned || t.autoDiscardable === false || isProtectedSite(t.url, settings.protectedSites) || safe(t);
  const touchable = (t) => web(t) && !guarded(t);
  const rank = (t) => (t.active ? 4 : 0) + (t.pinned ? 2 : 0) + (t.audible ? 1 : 0) + (isProtectedSite(t.url, settings.protectedSites) ? 3 : 0);

  const close = new Set();
  if (settings.duplicates !== 'off') {
    const groups = new Map();
    for (const t of tabs) {
      const key = normalizeUrl(t.url);
      if (!key) continue;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(t);
    }
    for (const group of groups.values()) {
      if (group.length < 2) continue;
      group.sort((a, b) => rank(b) - rank(a) || (b.lastAccessed || 0) - (a.lastAccessed || 0));
      group.slice(1).forEach((t) => { if (touchable(t)) close.add(t.id); });
    }
  }

  const sleep = [];
  const scores = {};
  const usePulsa = isPulsa(settings), v2 = settings.algorithm === 'pulsa2';
  const wake = {};
  const m = model || { hosts: {}, glob: { iv: [], fp: 0, ok: 0 } };
  const threshold = effectiveThreshold(SENSITIVITY[settings.sensitivity], {
    usedFrac: ctx.usedFrac, tune: ctx.tune, useMemory: settings.adaptMemory, useTune: settings.autoTune
  });
  for (const t of tabs) {
    if (close.has(t.id) || t.discarded || t.status === 'loading' || !touchable(t)) continue;
    if (!t.lastAccessed) continue;
    const idle = now - t.lastAccessed;
    const pre = (ctx.pre || {})[t.id];
    if (v2 && pre > 0 && now - pre < P2.hold * 60000) continue;
    if (idle < (v2 ? P2.floorMin * 60000 : idleMs)) continue;
    if (!usePulsa) { sleep.push(t.id); continue; }
    if (v2) {
      const rec = m.hosts[hostOf(t.url)], c = ctx.snap && ctx.snap.ctx[t.id];
      const bf = settings.brain && c && ctx.brain ? { model: ctx.brain, ...feat(c, rec, m.glob) } : null;
      const d = decide(rec, m.glob, idle / 60000, {
        brain: bf,
        sens: settings.sensitivity, p2: ctx.p2, preloaded: !!pre, canPreload: settings.mode === 'auto',
        factor: (settings.adaptMemory ? memoryFactor(ctx.usedFrac) : 1) * (settings.autoTune ? tuneFactor(ctx.tune) : 1)
      });
      if (d.act !== 'legacy') {
        scores[t.id] = Math.round(d.pRet * 100);
        if (d.act === 'sleep') { sleep.push(t.id); if (d.wake != null) wake[t.id] = d.wake; }
        continue;
      }
      if (idle < idleMs) continue;
    }
    const r = pulsaScore(m.hosts[hostOf(t.url)], m.glob, idle / 60000);
    scores[t.id] = r.score;
    if (r.score < threshold) sleep.push(t.id);
  }
  if (ctx.offline) { sleep.length = 0; for (const k of Object.keys(wake)) delete wake[k]; }
  return { sleep, close: [...close], scores, threshold, wake, offline: !!ctx.offline };
}

export async function loadTune() {
  const { pulsaTune } = await chrome.storage.local.get('pulsaTune');
  return pulsaTune || emptyTune();
}

export async function getContext(settings) {
  const ctx = {};
  if (settings.safe) ctx.audioSeen = await loadAudioSeen();
  if (settings.offlineGuard && offline()) ctx.offline = true;
  if (!isPulsa(settings)) return ctx;
  if (settings.algorithm === 'pulsa2') {
    ctx.p2 = await loadP2(); ctx.snap = await loadSnap(); ctx.pre = ctx.snap.pre;
    if (settings.brain) ctx.brain = await loadBrain();
  }
  if (settings.ecoOptimizer && (await getEco()).shed >= 2) return ctx;
  if (settings.adaptMemory) {
    try { const m = await chrome.system.memory.getInfo(); ctx.usedFrac = 1 - m.availableCapacity / m.capacity; } catch { }
  }
  if (settings.autoTune) ctx.tune = await loadTune();
  return ctx;
}

export async function optimize({ manual = false } = {}) {
  if (!(await getPower())) return { slept: 0, closed: 0 };
  const settings = await getSettings();
  const tabs = await chrome.tabs.query({});
  const model = isPulsa(settings) ? await loadModel() : null;
  const plan = analyze(tabs, settings, Date.now(), model, await getContext(settings));
  let closed = 0, slept = 0;

  if (plan.close.length && (manual || settings.duplicates === 'auto')) {
    try { await chrome.tabs.remove(plan.close); closed = plan.close.length; }
    catch { }
  }
  const done = [];
  for (const id of plan.sleep) {
    try { if (await chrome.tabs.discard(id)) { slept++; done.push(id); } } catch { }
  }
  if (done.length && isPulsa(settings)) {
    const w = {}; done.forEach((id) => { if (plan.wake[id] != null) w[id] = plan.wake[id]; });
    await markSlept(done, w); await pruneModel();
    if (Object.keys(w).length) await armPreload();
  }

  if (slept || closed || manual) {
    const st = await getStats();
    await chrome.storage.local.set({
      stats: { slept: st.slept + slept, closed: st.closed + closed, runs: st.runs + 1, lastRun: Date.now() }
    });
  }
  return { slept, closed };
}
