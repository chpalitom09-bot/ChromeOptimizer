const REPO = 'chpalitom09-bot/ChromeOptimizer';
export const REPO_URL = `https://github.com/${REPO}`;
export const PAGE_URL = 'https://chpalitom09-bot.github.io/ChromeOptimizer/#versions';
const RAW = `https://raw.githubusercontent.com/${REPO}/main/`;
const VERSION_URL = RAW + 'version.json';
const MANIFEST_URL = RAW + 'manifest.json';
const DAY = 24 * 60 * 60 * 1000;

export function isNewer(a, b) {
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const x = pa[i] || 0, y = pb[i] || 0;
    if (x !== y) return x > y;
  }
  return false;
}

export function shownVersion(version, name) {
  const rev = Number(String(version).split('.')[3] || 0);
  const base = name || String(version).split('.').slice(0, 2).join('.');
  return rev ? `${base} r${rev}` : base;
}
export function currentLabel() {
  const m = chrome.runtime.getManifest();
  return shownVersion(m.version, m.version_name);
}

const safe = (u, fallback) => (/^https:\/\/(github\.com|raw\.githubusercontent\.com)\/chpalitom09-bot\/ChromeOptimizer\//.test(u) ||
  /^https:\/\/chpalitom09-bot\.github\.io\/ChromeOptimizer\//.test(u)) ? u : fallback;

export async function getUpdateInfo() {
  const { update } = await chrome.storage.local.get('update');
  return update || null;
}

async function setBadge(on) {
  const { onePw } = await chrome.storage.session.get('onePw');
  if (onePw) return;
  chrome.action.setBadgeText({ text: on ? '↑' : '' });
  if (on) chrome.action.setBadgeBackgroundColor({ color: '#2f6fed' });
}

async function getJson(url) {
  const res = await fetch(url, { cache: 'no-store', credentials: 'omit', referrerPolicy: 'no-referrer' });
  return res.ok ? res.json() : null;
}

export async function checkForUpdate({ force = false } = {}) {
  const current = chrome.runtime.getManifest().version;
  const prev = await getUpdateInfo();
  if (!force && prev && Date.now() - prev.checkedAt < DAY - 60000) return prev;

  try {
    const r = await chrome.runtime.requestUpdateCheck();
    if (r && r.status === 'update_available') {
      const info = { status: 'store', latest: r.version || '', checkedAt: Date.now() };
      await chrome.storage.local.set({ update: info }); setBadge(true);
      return info;
    }
  } catch { }

  let info = { status: 'error', latest: '', checkedAt: Date.now() };
  try {
    let j = null;
    try { j = await getJson(VERSION_URL); } catch { }
    if (!j || !j.version) j = await getJson(MANIFEST_URL);
    if (j && j.version) {
      const latest = String(j.version);
      info = {
        status: isNewer(latest, current) ? 'available' : 'current',
        latest,
        label: shownVersion(latest, j.version_name || j.name),
        notes: j.notes && typeof j.notes === 'object' ? j.notes : null,
        page: safe(j.page, PAGE_URL),
        download: safe(j.download, ''),
        checkedAt: Date.now()
      };
    }
  } catch { }
  await chrome.storage.local.set({ update: info });
  setBadge(info.status === 'available');
  return info;
}

export async function clearBadgeIfCurrent() {
  const u = await getUpdateInfo();
  if (u && u.status === 'available' && !isNewer(u.latest, chrome.runtime.getManifest().version)) {
    await chrome.storage.local.set({ update: { ...u, status: 'current' } });
    setBadge(false);
  }
}
