export const PULSA_DEFAULTS = {
  halfLifeMin: 45,
  priorWeight: 4,
  recency: 0.92,
  maxIntervals: 24,
  horizonMin: 60,
  fpWindowMin: 60,
  fpStrength: 1.5,
  fpCap: 0.6,
  fbDecay: 0.85
};

export const SENSITIVITY = { prudent: 15, balanced: 30, aggressive: 50 };

export function emptyRecord() {
  return { iv: [], fp: 0, ok: 0, last: 0 };
}

export function recordReturn(rec, minutes, now = Date.now(), cfg = PULSA_DEFAULTS) {
  return push(rec, Math.max(0.1, minutes), now, cfg);
}

export function recordCensored(rec, minutes, now = Date.now(), cfg = PULSA_DEFAULTS) {
  return push(rec, -Math.max(0.1, minutes), now, cfg);
}

function push(rec, v, now, cfg) {
  rec.iv.push(Math.round(v * 10) / 10);
  if (rec.iv.length > cfg.maxIntervals) rec.iv.splice(0, rec.iv.length - cfg.maxIntervals);
  rec.last = now;
  return rec;
}

export function recordSleepOutcome(rec, minutesAsleep, now = Date.now(), cfg = PULSA_DEFAULTS) {
  rec.fp *= cfg.fbDecay; rec.ok *= cfg.fbDecay;
  if (minutesAsleep < cfg.fpWindowMin) rec.fp++; else rec.ok++;
  rec.last = now;
  return rec;
}

export function recordSleepKept(rec, now = Date.now(), cfg = PULSA_DEFAULTS) {
  rec.fp *= cfg.fbDecay; rec.ok *= cfg.fbDecay;
  rec.ok++;
  rec.last = now;
  return rec;
}

export function priorP(t, H, cfg = PULSA_DEFAULTS) {
  const p60 = Math.exp((-Math.LN2 * t) / cfg.halfLifeMin);
  return 1 - Math.pow(1 - p60, H / 60);
}

function empirical(iv, t, H, cfg) {
  let k = 0, m = 0;
  const n = iv.length;
  for (let i = 0; i < n; i++) {
    const w = Math.pow(cfg.recency, n - 1 - i);
    const x = iv[i];
    if (x > 0) {
      if (x > t) { k += w; if (x <= t + H) m += w; }
    } else if (-x >= t + H) {
      k += w;
    }
  }
  return { k, m };
}

function shrink(iv, t, H, base, cfg) {
  const { k, m } = empirical(iv, t, H, cfg);
  return (m + cfg.priorWeight * base) / (k + cfg.priorWeight);
}

export function reuseProbability(rec, glob, t, H, cfg = PULSA_DEFAULTS) {
  const p0 = priorP(t, H, cfg);
  const pG = glob && glob.iv.length ? shrink(glob.iv, t, H, p0, cfg) : p0;
  let p = rec && rec.iv.length ? shrink(rec.iv, t, H, pG, cfg) : pG;
  if (rec) {
    const fpRate = rec.fp / (rec.fp + rec.ok + 3);
    const fade = Math.exp((-Math.LN2 * t) / (2 * cfg.halfLifeMin));
    const caution = Math.min(cfg.fpCap, fpRate * cfg.fpStrength) * fade;
    p = 1 - (1 - p) * (1 - caution);
  }
  return Math.min(1, Math.max(0, p));
}

export function pulsaScore(rec, glob, idleMin, cfg = PULSA_DEFAULTS) {
  const p10 = reuseProbability(rec, glob, idleMin, 10, cfg);
  const p60 = reuseProbability(rec, glob, idleMin, cfg.horizonMin, cfg);
  const p360 = reuseProbability(rec, glob, idleMin, 360, cfg);
  return { score: Math.round(p60 * 100), p10, p60, p360 };
}

export function priority(score) {
  if (score > 80) return 'keep';
  if (score > 60) return 'monitor';
  if (score > 40) return 'low';
  if (score > 20) return 'high';
  return 'strong';
}

export function memoryFactor(usedFrac) {
  if (typeof usedFrac !== 'number' || Number.isNaN(usedFrac)) return 1;
  const u = Math.min(1, Math.max(0, usedFrac));
  if (u <= 0.5) return 0.5;
  if (u <= 0.85) return 0.5 + 0.5 * ((u - 0.5) / 0.35);
  if (u <= 0.95) return 1 + 0.6 * ((u - 0.85) / 0.10);
  return 1.6;
}

export const TUNE = { alpha: 0.1, target: 0.05, gain: 3, min: 0.5, max: 1.5, warmup: 5, regretFast: 1, regretSlow: 5 };

export function emptyTune() { return { rate: 0, n: 0 }; }

export function updateTune(state, minutesAsleep, cfg = TUNE) {
  const regret = minutesAsleep < cfg.regretFast ? 1 : minutesAsleep < cfg.regretSlow ? 0.6 : minutesAsleep < 15 ? 0.3 : minutesAsleep < 60 ? 0.15 : 0;
  state.rate = state.n === 0 ? regret : (1 - cfg.alpha) * state.rate + cfg.alpha * regret;
  state.n++;
  return state;
}

export function tuneFactor(state, cfg = TUNE) {
  if (!state || state.n < cfg.warmup) return 1;
  return Math.min(cfg.max, Math.max(cfg.min, 1 + cfg.gain * (cfg.target - state.rate)));
}

export function effectiveThreshold(base, { usedFrac, tune, useMemory = true, useTune = true } = {}) {
  return base * (useMemory ? memoryFactor(usedFrac) : 1) * (useTune ? tuneFactor(tune) : 1);
}

export const CYCLE_STEPS = [1, 2, 5, 10];
export const nextStage = (stage, didSomething) => (didSomething ? 0 : Math.min(stage + 1, CYCLE_STEPS.length - 1));
