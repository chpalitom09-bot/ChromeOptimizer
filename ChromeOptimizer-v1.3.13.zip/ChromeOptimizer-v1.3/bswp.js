(() => {
  if (window.__bswp) return;
  window.__bswp = true;
  const stats = { img: 0, frame: 0, video: 0 };
  const far = (el) => el.getBoundingClientRect().top > innerHeight * 2;

  function scan(root) {
    root.querySelectorAll('img:not([loading])').forEach((el) => {
      if (el.complete || !far(el)) return;
      el.loading = 'lazy'; el.decoding = 'async'; stats.img++;
    });
    root.querySelectorAll('iframe:not([loading])').forEach((el) => {
      if (!far(el) || /^(about|javascript|data):/i.test(el.getAttribute('src') || 'about:')) return;
      el.loading = 'lazy'; stats.frame++;
    });
    root.querySelectorAll('video:not([autoplay])').forEach((el) => {
      if (el.preload === 'metadata' || el.preload === 'none' || !far(el)) return;
      el.preload = 'metadata'; stats.video++;
    });
  }

  scan(document);

  let queued = false;
  const idle = window.requestIdleCallback || ((f) => setTimeout(f, 200));
  const mo = new MutationObserver(() => {
    if (queued) return;
    queued = true;
    idle(() => { queued = false; scan(document); });
  });
  mo.observe(document.documentElement, { childList: true, subtree: true });
  setTimeout(() => mo.disconnect(), 8000);

  chrome.runtime.onMessage.addListener((msg, _s, reply) => {
    if (msg && msg.type === 'bswp-stats') reply(stats);
  });
})();
